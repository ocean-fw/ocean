import xt from '/xterm-bundle.js';
const { Terminal, FitAddon } = xt;

const q = new URLSearchParams(location.search);
const nodeId = Number(q.get('node')) || 0;
const $ = (id) => document.getElementById(id);
const setSt = (t, c) => { $('st').textContent = t; $('st').className = 'st ' + (c || ''); };

const term = new Terminal({ cursorBlink: true, fontSize: 14, scrollback: 5000, convertEol: false, theme: { background: '#1e1e1e' } });
const fit = new FitAddon();
term.loadAddon(fit);
term.open($('t'));
fit.fit();

let ws = null;
const b64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));

async function connect() {
  if (ws) { try { ws.close(); } catch { /* 忽略 */ } }
  term.reset();
  setSt('连接中…');
  let token = '';
  try { token = localStorage.getItem('fw_token') || ''; } catch { /* 忽略 */ }
  if (!token) { setSt('请先在面板里登录', 'bad'); return; }
  let r;
  try {
    const resp = await fetch(`/api/v1/nodes/${nodeId}/terminal_ticket`, { method: 'POST', headers: { Authorization: 'Bearer ' + token } });
    r = await resp.json();
    if (!resp.ok) { setSt(r.error || '失败', 'bad'); return; }
  } catch (e) { setSt('请求失败：' + e.message, 'bad'); return; }
  $('title').textContent = '终端：' + (r.node || '#' + nodeId);
  document.title = '终端 - ' + (r.node || nodeId);
  ws = new WebSocket((location.protocol === 'https:' ? 'wss://' : 'ws://') + location.host + '/api/v1/terminal/ws?ticket=' + encodeURIComponent(r.ticket));
  ws.onopen = () => { setSt('已连接', 'ok'); fit.fit(); ws.send(JSON.stringify({ t: 'resize', cols: term.cols, rows: term.rows })); term.focus(); };
  ws.onmessage = (ev) => {
    let m; try { m = JSON.parse(ev.data); } catch { return; }
    if (m.t === 'out') term.write(b64(m.b));
    else if (m.t === 'exit') setSt('会话已结束', 'bad');
  };
  ws.onclose = () => setSt('已断开', 'bad');
  ws.onerror = () => setSt('连接出错', 'bad');
}

term.onData((d) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'in', d })); });
term.onResize(({ cols, rows }) => { if (ws && ws.readyState === 1) ws.send(JSON.stringify({ t: 'resize', cols, rows })); });
window.addEventListener('resize', () => fit.fit());
$('re').onclick = connect;
if (!nodeId) setSt('缺少节点参数', 'bad'); else connect();
