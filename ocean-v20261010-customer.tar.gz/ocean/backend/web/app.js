(() => {
'use strict';

// ------------------------------------------------------------ 小工具
// h() 用 textContent 创建节点，数据里即使带 <script> 也不会被当成代码执行（防 XSS）
function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  let pendingValue;
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === null || v === undefined || v === false) continue;
      if (k === 'class') el.className = v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (k === 'value') pendingValue = v;
      else if (k === 'checked' || k === 'disabled' || k === 'selected') el[k] = true;
      else el.setAttribute(k, v === true ? '' : v);
    }
  }
  for (const kid of kids.flat(Infinity)) {
    if (kid === null || kid === undefined || kid === false) continue;
    el.append(kid.nodeType ? kid : document.createTextNode(String(kid)));
  }
  if (pendingValue !== undefined) el.value = pendingValue; // select 要等 option 加完再设值
  return el;
}

function fill(el, ...kids) { el.replaceChildren(...kids.flat(Infinity).filter((k) => k !== null && k !== undefined && k !== false)); }

const store = {
  get token() { try { return localStorage.getItem('fw_token') || ''; } catch { return ''; } },
  set token(v) { try { v ? localStorage.setItem('fw_token', v) : localStorage.removeItem('fw_token'); } catch { /* 忽略 */ } },
};

async function api(method, path, body, asText) {
  const opt = { method, headers: {} };
  if (store.token) opt.headers.Authorization = 'Bearer ' + store.token;
  if (body !== undefined) { opt.headers['Content-Type'] = 'application/json'; opt.body = JSON.stringify(body); }
  const res = await fetch('/api/v1' + path, opt);
  if (res.status === 401 && path !== '/login') {
    store.token = '';
    showLogin();
    throw new Error('登录已失效，请重新登录');
  }
  const text = await res.text();
  if (!res.ok) {
    let msg = res.statusText || '请求失败';
    try { const j = JSON.parse(text); msg = j.error || msg; if (j.code === 'license_locked' && state.render && state.page !== 'license' && state.me && state.me.role === 'admin') setTimeout(() => state.render('license'), 0); } catch { /* 不是 JSON */ }
    throw new Error(msg);
  }
  if (asText) return text;
  return text ? JSON.parse(text) : null;
}

function toast(msg, isErr) {
  const t = h('div', { class: 'toast' + (isErr ? ' err' : '') }, msg);
  document.getElementById('toasts').append(t);
  setTimeout(() => t.remove(), isErr ? 6000 : 2600);
}
const fail = (e) => toast(e.message || String(e), true);

function fmtBytes(n) {
  n = Number(n) || 0;
  const u = ['B', 'KB', 'MB', 'GB', 'TB', 'PB'];
  let i = 0;
  while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
  return (i === 0 ? n.toFixed(0) : n.toFixed(2)) + ' ' + u[i];
}
function fmtTime(iso) {
  if (!iso) return '—';
  const d = new Date(iso);
  if (isNaN(d)) return '—';
  const p = (x) => String(x).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}
function ago(iso) {
  if (!iso) return '从未';
  const s = Math.max(0, (Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return Math.floor(s) + ' 秒前';
  if (s < 3600) return Math.floor(s / 60) + ' 分钟前';
  if (s < 86400) return Math.floor(s / 3600) + ' 小时前';
  return Math.floor(s / 86400) + ' 天前';
}
const TYPE_LABEL = { entry: '入口', exit: '出口', both: '入口+出口', monitor: '仅监控', chain: '链式出口' };
const DIRECT_LABEL = ['可选直接转发', '禁止直接转发', '强制直接转发'];

function modal(title, content, makeActions, wide) {
  const dlg = h('dialog', { class: 'modal' + (wide ? ' wide' : '') });
  const api_ = { close: () => dlg.close(), el: dlg };
  dlg.append(h('div', { class: 'modal-head' }, title), h('div', { class: 'modal-body' }, content),
    h('div', { class: 'modal-foot' }, makeActions(api_)));
  dlg.addEventListener('close', () => dlg.remove());
  document.body.append(dlg);
  dlg.showModal();
  return api_;
}
function confirmBox(title, text, onOk, danger) {
  modal(title, h('p', null, text), (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn ' + (danger ? 'danger' : 'primary'), onclick: async () => { m.close(); await onOk(); } }, '确定'),
  ]);
}
// 深色 / 浅色：手动切换，和节点状态页共用同一个记忆（没选过就跟随系统）
(function () { try { const t = localStorage.getItem('fw_tz_theme'); if (t) document.documentElement.setAttribute('data-theme', t); } catch (e) { /* 读不到就跟随系统 */ } })();
function toggleTheme() {
  const root = document.documentElement, cur = root.getAttribute('data-theme');
  const dark = cur === 'dark' || (!cur && matchMedia('(prefers-color-scheme: dark)').matches);
  const next = dark ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  try { localStorage.setItem('fw_tz_theme', next); } catch (e) { /* 忽略 */ }
}
async function copyText(text, node) {
  try { await navigator.clipboard.writeText(text); toast('已复制'); return; } catch { /* http 页面没有剪贴板接口，用下面的老办法 */ }
  try { // 老办法：临时文本框 + execCommand（必须放进当前打开的弹窗里，否则弹窗外的元素拿不到焦点）
    const ta = document.createElement('textarea');
    ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0;opacity:0';
    (document.querySelector('dialog[open]') || document.body).appendChild(ta);
    ta.select(); ta.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    ta.remove();
    if (ok) { toast('已复制'); return; }
  } catch { /* 继续走手动 */ }
  if (node) {
    const r = document.createRange(); r.selectNodeContents(node);
    const s = getSelection(); s.removeAllRanges(); s.addRange(r);
  }
  toast('浏览器不允许自动复制，已选中，请按 Ctrl+C', true);
}
function field(label, input, hint) {
  return h('div', { class: 'field' }, h('label', null, label), input, hint ? h('div', { class: 'hint' }, hint) : null);
}

// ------------------------------------------------------------ 全局状态
const state = { me: null, page: 'home', timer: null, site: null };
const app = document.getElementById('app');

async function showLogin() {
  clearInterval(state.timer);
  let site = { site_name: 'ocean', allow_register: false, invite_required: false, topup_notice: '' };
  try { site = await api('GET', '/site'); } catch { /* 取不到就用默认 */ }
  state.site = site;
  document.title = site.site_name || 'ocean';
  const inv0 = new URLSearchParams(location.search).get('invite') || '';
  let mode = inv0 && site.allow_register ? 'register' : 'login';
  const draw = () => {
    const user = h('input', { type: 'text', autocomplete: 'username', placeholder: '用户名' });
    const pass = h('input', { type: 'password', autocomplete: mode === 'login' ? 'current-password' : 'new-password', placeholder: mode === 'login' ? '密码' : '密码（至少 8 位）' });
    const capQ = h('span', { class: 'muted' }); const capA = h('input', { type: 'text', inputmode: 'numeric', placeholder: '答案' }); let capId = '';
    const loadCap = async () => { try { const c = await api('GET', '/captcha'); capId = c.id; capQ.textContent = c.question; capA.value = ''; } catch { /* 忽略 */ } };
    if (mode === 'register' && site.captcha) loadCap();
    const inv = h('input', { type: 'text', value: inv0, placeholder: site.invite_required ? '邀请码（必填）' : '邀请码（选填）' });
    const btn = h('button', { class: 'btn primary', style: 'width:100%', type: 'submit' }, mode === 'login' ? '登录' : '注册');
    const form = h('form', { onsubmit: async (e) => {
      e.preventDefault();
      btn.disabled = true;
      try {
        const r = mode === 'login'
          ? await api('POST', '/login', { username: user.value.trim(), password: pass.value })
          : await api('POST', '/register', { username: user.value.trim(), password: pass.value, invite_code: inv.value.trim(), captcha_id: capId, captcha_answer: capA.value.trim() });
        store.token = r.token; state.me = await api('GET', '/me'); showApp();
      } catch (err) { fail(err); if (mode === 'register' && site.captcha) loadCap(); } finally { btn.disabled = false; }
    } }, field('用户名', user), field('密码', pass), mode === 'register' ? field('邀请码', inv) : null,
    mode === 'register' && site.captcha ? h('div', { class: 'field' }, h('label', null, '验证码：', capQ, ' ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); loadCap(); } }, '换一题')), capA) : null, btn);
    const switcher = site.allow_register
      ? h('p', { class: 'muted small', style: 'margin:14px 0 0;text-align:center' }, mode === 'login' ? '没有账号？' : '已有账号？',
        h('a', { href: '#', onclick: (e) => { e.preventDefault(); mode = mode === 'login' ? 'register' : 'login'; draw(); } }, mode === 'login' ? '注册' : '去登录'))
      : null;
    fill(app, h('div', { class: 'login-wrap' },
      h('div', { class: 'login-card' }, h('h1', null, site.site_name || 'ocean'), h('p', { class: 'muted' }, mode === 'login' ? '管理面板' : '创建新账号'), form, switcher)));
    user.focus();
  };
  draw();
}

const PAGES = []; // [key, 标签, 渲染函数, 角色 admin|user]
const reg = (key, label, fn, role, cond) => PAGES.push([key, label, fn, role, cond]);

function showApp() {
  const isAdm = state.me && state.me.role === 'admin';
  const pages = PAGES.filter((p) => p[3] === (isAdm ? 'admin' : 'user') && (!p[4] || p[4](state.site || {})));
  { // 地址栏：#页面名，?affect=用户ID 表示“只看该用户的规则”
    const hk = decodeURIComponent((location.hash || '').replace(/^#/, ''));
    if (hk && pages.find((p) => p[0] === hk)) state.page = hk;
    const af = Number(new URLSearchParams(location.search).get('affect')) || 0;
    if (isAdm && af && state.page === 'rules') { window.fwR.uid = af; state.standalone = true; } // 单独页面：没有左侧菜单
  }
  if (!pages.find((p) => p[0] === state.page)) state.page = pages[0][0];
  document.title = (state.site && state.site.site_name) || 'ocean';
  const main = h('div', { class: 'content' });
  const nav = h('div', { class: 'nav' });
  const render = async (key) => {
    state.page = key;
    try { history.replaceState(null, '', (key === 'rules' && isAdm && window.fwR.uid ? '/?affect=' + window.fwR.uid : '/') + '#' + key); } catch { /* 忽略 */ }
    clearInterval(state.timer);
    nav.querySelectorAll('button[data-key]').forEach((b) => b.classList.toggle('active', b.dataset.key === key));
    fill(main, h('p', { class: 'muted' }, '加载中…'));
    const page = pages.find((p) => p[0] === key);
    try { await page[2](main); } catch (e) { fill(main, h('p', { class: 'muted' }, '加载失败：' + e.message)); }
  };
  state.render = render;
  const goto = (key) => { if (key === 'rules') { R.uid = 0; R.page = 0; } render(key); };
  const navBtn = ([key, label], lab) => h('button', { 'data-key': key, onclick: () => goto(key) }, lab || label);
  const tzBtn = () => h('button', { onclick: () => window.open('/tz.html', '_blank', 'noopener') }, '节点状态 ↗'); // 节点管理已合并进这个单独页面
  if (!isAdm) {
    pages.forEach((p) => nav.append(navBtn(p)));
    nav.append(tzBtn());
  } else {
    // 管理员：上面是“用户功能”，下面是可以收起来的“管理”分组（和 ny 一样）
    const MANAGE = ['dashboard', 'settings', 'push', 'users', 'usergroups', 'orders', 'plans', 'redeems', 'groups', 'announcements', 'invitelog', 'license', 'logs'];
    const MLABEL = { dashboard: '仪表盘', settings: '站点设置', push: '推送通知', users: '用户管理', usergroups: '用户组管理', orders: '订单管理', plans: '套餐管理', redeems: '兑换码管理', groups: '设备组管理', announcements: '公告管理', invitelog: '邀请记录', license: '授权', logs: '运行日志' };
    pages.filter((p) => !MANAGE.includes(p[0])).forEach((p) => nav.append(navBtn(p)));
    nav.append(tzBtn());
    let open = true;
    try { open = localStorage.getItem('fw_nav_manage') !== '0'; } catch { /* 忽略 */ }
    if (MANAGE.includes(state.page)) open = true;
    const sub = h('div', { class: 'nav-sub' });
    MANAGE.map((k) => pages.find((p) => p[0] === k)).filter(Boolean).forEach((p) => sub.append(navBtn(p, MLABEL[p[0]])));
    const head = h('button', { class: 'nav-head' });
    const paint = () => { head.textContent = (open ? '▾ ' : '▸ ') + '管理'; sub.hidden = !open; };
    head.addEventListener('click', () => { open = !open; try { localStorage.setItem('fw_nav_manage', open ? '1' : '0'); } catch { /* 忽略 */ } paint(); });
    paint();
    nav.append(head, sub);
  }
  const who = h('span', { class: 'muted', id: 'who' });
  state.refreshWho = () => fill(who, state.me ? state.me.username : '', !isAdm && state.me && !(state.site && state.site.balance_off) ? h('span', { class: 'chip', style: 'margin-left:8px' }, '余额 ¥' + (state.me.balance / 100).toFixed(2)) : null);
  state.refreshWho();
  fill(app, h('div', { class: 'layout' + (state.standalone ? ' standalone' : '') },
    state.standalone ? null : h('aside', { class: 'side' }, h('div', { class: 'brand' }, (state.site && state.site.site_name) || 'ocean'), nav),
    h('div', { class: 'main' },
      h('div', { class: 'top' }, state.standalone ? h('b', { style: 'margin-right:auto;font-size:18px' }, (state.site && state.site.site_name) || 'ocean') : null, who,
        h('button', { class: 'btn sm', title: '切换深色 / 浅色', onclick: toggleTheme }, '◐ 深色/浅色'),
        h('button', { class: 'btn sm', onclick: passwordDialog }, '修改密码'),
        h('button', { class: 'btn sm', onclick: async () => { try { await api('POST', '/logout'); } catch { /* 忽略 */ } store.token = ''; showLogin(); } }, '退出')),
      main)));
  render(state.page);
}

function passwordDialog() {
  const o = h('input', { type: 'password', autocomplete: 'current-password' });
  const n = h('input', { type: 'password', autocomplete: 'new-password' });
  const n2 = h('input', { type: 'password', autocomplete: 'new-password' });
  modal('修改密码', [field('当前密码', o), field('新密码（至少 8 位）', n), field('重复新密码', n2)], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      if (n.value !== n2.value) return fail(new Error('两次输入的新密码不一致'));
      try { await api('POST', '/me/password', { old_password: o.value, new_password: n.value }); toast('密码已修改'); m.close(); } catch (e) { fail(e); }
    } }, '确定'),
  ]);
}

function autoRefresh(fn, ms) {
  clearInterval(state.timer);
  state.timer = setInterval(() => { if (!document.hidden && !document.querySelector('dialog[open]')) fn().catch(() => {}); }, ms);
}

// ------------------------------------------------------------ 仪表盘
function rankTable(title, head, rows, empty) {
  return h('div', { class: 'card' }, h('h2', null, title),
    rows.length ? h('div', { class: 'table-wrap flat' }, h('table', null, h('thead', null, h('tr', null, head.map((t) => h('th', null, t)))), h('tbody', null, rows))) : h('div', { class: 'muted small' }, empty));
}

async function pageDashboard(main) {
  const draw = async () => {
    const d = await api('GET', '/dashboard');
    const stat = (k, v, s) => h('div', { class: 'stat' }, h('div', { class: 'k' }, k), h('div', { class: 'v' }, v), h('div', { class: 's' }, s || ' '));
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '仪表盘')),
      h('div', { class: 'stats' },
        stat('设备组', d.groups),
        stat('节点在线', `${d.nodes_online} / ${d.nodes}`, d.nodes === 0 ? '还没有节点，去"设备组"点"对接"' : ''),
        stat('规则启用', `${d.rules_enabled} / ${d.rules}`),
        stat('用户', `${d.users_active} / ${d.users}`, `有效 / 全部（共 ${d.users} 个）`),
        stat('今日流量', fmtBytes(d.today_in + d.today_out), `↑ ${fmtBytes(d.today_in)}  ↓ ${fmtBytes(d.today_out)}`),
        stat('累计流量', fmtBytes(d.total_in + d.total_out), `↑ ${fmtBytes(d.total_in)}  ↓ ${fmtBytes(d.total_out)}`),
        stat('套餐销售额', '¥' + (d.income / 100).toFixed(2), `今日 ¥${(d.spend_today / 100).toFixed(2)} · 本月 ¥${(d.spend_month / 100).toFixed(2)}`),
        stat('今日充值', '¥' + (d.recharge_today / 100).toFixed(2), `昨日 ¥${(d.recharge_yesterday / 100).toFixed(2)}`),
        stat('本月充值', '¥' + (d.recharge_month / 100).toFixed(2), `上月 ¥${(d.recharge_last_month / 100).toFixed(2)}`),
        stat('昨日流量', fmtBytes(d.yesterday_in + d.yesterday_out), `↑ ${fmtBytes(d.yesterday_in)}  ↓ ${fmtBytes(d.yesterday_out)}`),
        stat('面板版本', 'v' + d.version, '节点程序最新 v' + d.agent_version + (d.nodes_outdated ? ` · ${d.nodes_outdated} 个节点可升级，去“节点状态”` : ' · 节点均为最新')),
        stat('配置版本', d.revision, '每次改规则 +1')),
      h('div', { class: 'grid2' },
        rankTable('规则流量排行 Top 10', ['规则', '所属用户', '流量'],
          (d.top_rules || []).map((r) => h('tr', null, h('td', null, r.name), h('td', { class: 'muted' }, r.username || '管理员'), h('td', null, fmtBytes(r.total)))), '还没有流量'),
        rankTable('用户流量排行 Top 10', ['用户', '已用', '额度'],
          (d.top_users || []).map((u) => h('tr', null, h('td', null, u.username), h('td', null, fmtBytes(u.used)), h('td', { class: 'muted' }, u.limit ? fmtBytes(u.limit) : '不限'))), '还没有用户流量')),
      h('div', { class: 'grid2' },
        rankTable('节点流量排行 Top 10（网卡累计，节点重启后清零）', ['节点', '设备组', '流量'], (d.top_nodes || []).map((n) => h('tr', null, h('td', null, n.name), h('td', { class: 'muted' }, n.group), h('td', null, fmtBytes(n.total)))), '还没有节点流量'), h('div')),
      h('div', { class: 'grid2' },
        rankTable('今日用户流量排行', ['用户', '流量'], (d.top_users_today || []).map((u) => h('tr', null, h('td', null, u.username), h('td', null, fmtBytes(u.total)))), '今天还没有流量'),
        rankTable('昨日用户流量排行', ['用户', '流量'], (d.top_users_yesterday || []).map((u) => h('tr', null, h('td', null, u.username), h('td', null, fmtBytes(u.total)))), '昨天没有流量')));
  };
  await draw();
  autoRefresh(draw, 10000);
}

// ------------------------------------------------------------ 设备组（入口 / 出口 分开两个页面）
const LB_LABEL = { random: '随机', roundrobin: '轮询', iphash: 'IP Hash', leastconn: '最小连接数', failover: '故障转移（按顺序）' };
const PROTO_LABEL = { tls_mux: 'tls_mux（TLS 多路复用：长连接 + 多条流，短连接多时更快）', tls_simple: 'tls_simple（TLS 1.3 加密，推荐）', http: 'http（HTTP 伪装，明文，仅认证）', ws: 'ws（WebSocket，明文，仅认证）', wss: 'wss（WebSocket + TLS，旧版）' };
const protoName = (p) => (p === 'tls' || !p ? 'tls_simple' : p);

async function pageGroups(main) {
  const sel = new Set();
  let dragId = 0;
  const draw = async () => {
    const [all, ugs] = await Promise.all([api('GET', '/device_groups'), api('GET', '/user_groups')]);
    const ugn = Object.fromEntries(ugs.map((g) => [String(g.id), g.name]));
    const names = Object.fromEntries(all.map((g) => [g.id, g.name]));
    const dash = h('span', { class: 'muted' }, '—');
    const nodeCell = (g) => (g.node_count === 0 ? h('span', { class: 'chip bad' }, '无设备') : h('span', { class: g.online_count ? 'chip ok' : 'chip bad' }, `${g.online_count} 在线 / ${g.node_count}`));
    const mult = (g) => (g.multiplier === 0 ? h('span', { class: 'chip warn' }, '不计流量') : '× ' + g.multiplier);
    const rows = all.map((g) => {
      const isIn = g.type === 'entry' || g.type === 'both', isOut = g.type === 'exit' || g.type === 'both' || g.type === 'chain';
      const tr = h('tr', { draggable: 'true' },
        h('td', null, h('input', { type: 'checkbox', checked: sel.has(g.id), onchange: (e) => { e.target.checked ? sel.add(g.id) : sel.delete(g.id); draw(); } })),
        h('td', { style: 'cursor:grab;color:var(--muted,#888)', title: '按住拖动调整顺序' }, '⋮⋮'),
        h('td', null, g.id), h('td', null, g.name, g.owner_user_id ? h('span', { class: 'chip warn', style: 'margin-left:6px' }, '用户自带 #' + g.owner_user_id) : null),
        h('td', null, h('span', { class: 'chip' }, TYPE_LABEL[g.type] || g.type)),
        h('td', null, mult(g)),
        h('td', { class: 'mono' }, isIn ? g.port_range : dash),
        h('td', null, isOut ? h('span', null, h('span', { class: 'chip' }, protoName(g.protocol)), h('span', { class: 'mono small' }, ' :' + (g.tunnel_port || '—'))) : dash),
        h('td', null, g.connect_host || dash),
        h('td', null, isIn ? h('span', { class: 'chip' }, DIRECT_LABEL[g.direct_policy || 0]) : dash),
        h('td', null, isIn && g.failover_group_id ? (names[g.failover_group_id] || '（已删除）') : dash),
        h('td', { class: 'small' }, g.allow_groups ? g.allow_groups.split(',').map((x) => h('span', { class: 'chip' }, ugn[x] || '#' + x)) : h('span', { class: 'muted' }, '所有人')),
        h('td', { class: 'small nowrap' }, g.traffic_in + g.traffic_out ? fmtBytes(g.traffic_in + g.traffic_out) : dash),
        h('td', null, nodeCell(g)),
        h('td', { class: 'muted small' }, (g.hide_probe === 2 ? '[探针：全部隐藏] ' : g.hide_probe === 1 ? '[探针：对用户隐藏] ' : '') + (g.remark || '')),
        h('td', { class: 'actions' },
          h('button', { class: 'btn sm primary', onclick: () => joinDialog(g) }, '对接'),
          h('button', { class: 'btn sm', onclick: () => groupDialog(g, draw) }, '编辑'),
          h('button', { class: 'btn sm', onclick: () => advancedDialog(g, draw) }, '高级'),
          h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除设备组', `删除「${g.name}」会同时删除它下面的 ${g.node_count} 个节点记录。确定吗？`, async () => {
            try { await api('DELETE', '/device_groups/' + g.id); toast('已删除'); draw(); } catch (e) { fail(e); }
          }, true) }, '删除')));
      tr.addEventListener('dragstart', (e) => { dragId = g.id; e.dataTransfer.effectAllowed = 'move'; });
      tr.addEventListener('dragover', (e) => { e.preventDefault(); e.dataTransfer.dropEffect = 'move'; });
      tr.addEventListener('drop', async (e) => {
        e.preventDefault();
        if (!dragId || dragId === g.id) return;
        const ids = all.map((x) => x.id).filter((x) => x !== dragId);
        ids.splice(ids.indexOf(g.id), 0, dragId);
        try { await api('POST', '/device_groups/reorder', { ids }); draw(); } catch (err) { fail(err); }
      });
      return tr;
    });
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '设备组管理'),
        h('button', { class: 'btn primary', onclick: () => groupDialog(null, draw) }, '添加设备组'),
        h('button', { class: 'btn', disabled: !sel.size, onclick: () => confirmBox('清空流量', `清空选中的 ${sel.size} 个设备组下所有规则的累计流量？`, async () => {
          try { await api('POST', '/device_groups/clear_traffic', { ids: [...sel] }); toast('已清空'); sel.clear(); draw(); } catch (e) { fail(e); }
        }) }, '清空流量' + (sel.size ? `(${sel.size})` : ''))),
      h('p', { class: 'muted small', style: 'margin-top:-6px' }, '新建时选类型：入口 = 用户连接的服务器；出口 = 隧道落地端；入口+出口 = 同一批服务器两种身份都当。规则里再选用哪个入口、哪个出口。'),
      all.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('thead', null, h('tr', null, [h('th', null, h('input', { type: 'checkbox', checked: all.length > 0 && all.every((g) => sel.has(g.id)), onchange: (e) => { all.forEach((g) => (e.target.checked ? sel.add(g.id) : sel.delete(g.id))); draw(); } })), ...['排序', 'ID', '名称', '类型', '流量倍率', '可用端口', '隧道（协议:端口）', '对外域名', '直连策略', '故障转移组', '可用用户组', '累计流量', '节点', '备注', '操作'].map((t) => h('th', null, t))].map((x) => (x.tagName ? x : h('th', null, x))))),
        h('tbody', null, rows))) : h('div', { class: 'card empty' }, '还没有设备组。点右上角"添加设备组"，再点"对接"把服务器接进来。'));
  };
  await draw();
  autoRefresh(draw, 10000);
}

async function groupDialog(g, done) {
  const editing = !!g;
  let others = [], ugs = [], exitsAll = [], entriesAll = [], allGroups = [];
  try {
    const allG = await api('GET', '/device_groups');
    allGroups = allG;
    others = allG.filter((x) => (x.type === 'entry' || x.type === 'both') && (!g || x.id !== g.id));
    exitsAll = allG.filter((x) => (x.type === 'exit' || x.type === 'both') && !x.owner_user_id && (!g || x.id !== g.id));
    entriesAll = allG.filter((x) => (x.type === 'entry' || x.type === 'both') && (!g || x.id !== g.id));
    ugs = await api('GET', '/user_groups');
  } catch (e) { return fail(e); }
  const allowBox = h('input', { type: 'text', placeholder: '例如 1,2,3（留空 = 所有用户都能用）', value: g && g.allow_groups ? g.allow_groups : '' });
  const type = h('select', { value: g ? g.type : 'entry', disabled: editing },
    h('option', { value: 'monitor' }, '仅监控'), h('option', { value: 'entry' }, '入口'), h('option', { value: 'exit' }, '出口'), h('option', { value: 'chain' }, '链式出口（只能作多跳的后续跳点）'), h('option', { value: 'both' }, '入口+出口'));
  const name = h('input', { type: 'text', value: g ? g.name : '', maxlength: 64 });
  const mult = h('input', { type: 'number', step: '0.1', min: '0', value: g ? g.multiplier : 1 });
  const host = h('textarea', { rows: 3, placeholder: '可选，一行一个，例如：\nin.example.com\nnode2.example.com:20443（可带端口）' });
  host.value = g ? g.connect_host : '';
  const range = h('input', { type: 'text', value: g ? g.port_range : '10000-60000' });
  const offline = h('input', { type: 'number', min: 10, max: 86400, value: g ? g.offline_seconds : 60 });
  const retention = h('input', { type: 'number', min: 0, max: 3650, value: g ? g.retention_days || 0 : 0 });
  const remark = h('input', { type: 'text', value: g ? g.remark : '', maxlength: 255, placeholder: '可选，仅管理员可见' });
  const failover = h('select', { value: g && g.failover_group_id ? String(g.failover_group_id) : '0' },
    h('option', { value: '0' }, '不设置'), others.map((x) => h('option', { value: String(x.id) }, x.name)));
  const exitFb = h('select', { value: g && g.exit_failover_id ? String(g.exit_failover_id) : '0' },
    h('option', { value: '0' }, '不设置'), allGroups.filter((x) => (x.type === 'exit' || x.type === 'both') && (!g || x.id !== g.id)).map((x) => h('option', { value: String(x.id) }, x.name)));
  const protoList = ['tls_simple', 'tls_mux', 'wss', 'ws', 'http'];
  const proto = h('select', { value: g && g.protocol ? protoName(g.protocol) : 'tls_simple' }, protoList.map((p) => h('option', { value: p }, PROTO_LABEL[p])));
  const direct = h('select', { value: String(g ? g.direct_policy || 0 : 0) }, DIRECT_LABEL.map((t, i) => h('option', { value: String(i) }, t)));
  const udpBind = h('input', { type: 'checkbox', checked: !!(g && g.udp_smart_bind) });
  const grace = h('input', { type: 'number', min: 0, max: 86400, value: g ? g.grace_seconds || 0 : 0 });
  const hideProbe = h('select', { value: String(g ? g.hide_probe || 0 : 0) }, h('option', { value: '0' }, '不隐藏'), h('option', { value: '1' }, '对非管理员用户隐藏'), h('option', { value: '2' }, '对所有用户隐藏'));
  const idText = (cur) => h('input', { type: 'text', placeholder: '例如 1,2,3（留空 = 不限制）', value: cur || '' });
  const idList = (list) => (list.length ? list.map((x) => x.id + '=' + x.name).join('，') : '暂无');
  const exitsBox = idText(g && g.allow_exits);
  const entriesBox = idText(g && g.allow_entries);
  const pickIDs = (box) => box.value.replace(/[，、\s]+/g, ',').replace(/^,+|,+$/g, '');
  const ipmode = h('select', { value: g && g.ip_mode ? g.ip_mode : '' },
    [['', '自动（有 IPv4 用 IPv4，没有才用 IPv6）'], ['p4', '优先 IPv4（连不上自动回退 IPv6）'], ['p6', '优先 IPv6（连不上自动回退 IPv4）'], ['v4', '强制 IPv4（不回退）'], ['v6', '强制 IPv6（不回退）']].map(([v, t]) => h('option', { value: v }, t)));
  // 入口组：哪些出口优先走 IPv6（对应 ny 的 ipv6_group）
  const v6cur = ((g && g.ipv6_group) || '').split(',').map((x) => x.trim()).filter(Boolean);
  const v6mode = h('select', { value: v6cur.includes('0') ? 'all' : v6cur.length ? 'some' : 'none' },
    [['none', '不设置（由各出口组自己的“连接 IP 版本”决定）'], ['some', '只对勾选的出口生效'], ['all', '对全部出口生效（下面勾选的除外）']].map(([v, t]) => h('option', { value: v }, t)));
  const emode = h('select', { value: (g && g.entry_ip_mode) || 'p6' },
    [['p6', '优先 IPv6（连不上自动回退 IPv4）'], ['p4', '优先 IPv4（连不上自动回退 IPv6）'], ['v6', '强制 IPv6（不回退）'], ['v4', '强制 IPv4（不回退）']].map(([v, t]) => h('option', { value: v }, t)));
  const v6boxes = exitsAll.map((x) => ({ x, cb: h('input', { type: 'checkbox', checked: v6cur.includes(String(x.id)) }) }));
  const v6list = h('div', { class: 'checks' }, v6boxes.map(({ x, cb }) => h('label', { class: 'check', style: 'display:inline-flex;margin-right:14px' }, cb, ' ' + x.name + ' (#' + x.id + ')')));
  const v6hint = h('div', { class: 'hint' });
  const v6show = () => { v6list.style.display = v6mode.value === 'none' ? 'none' : ''; emode.style.display = v6mode.value === 'none' ? 'none' : ''; v6hint.textContent = v6mode.value === 'all' ? '勾选的出口是例外：不用上面这条，仍按它自己设备组里的“连接 IP 版本”。出口组自己选了“强制”时，以出口组的强制为准。' : '勾选哪些出口使用上面选的 IP 版本。出口组自己选了“强制”时，以出口组的强制为准。'; };
  v6mode.addEventListener('change', v6show); v6show();
  const v6value = () => {
    const ids = v6boxes.filter(({ cb }) => cb.checked).map(({ x }) => x.id);
    return v6mode.value === 'none' ? '' : (v6mode.value === 'all' ? ['0', ...ids] : ids).join(',');
  };
  const tport = h('input', { type: 'number', min: 1, max: 65535, value: g && g.tunnel_port ? g.tunnel_port : '', placeholder: '留空自动分配' });
  const sni = h('input', { type: 'text', maxlength: 120, value: g ? g.tunnel_sni || '' : '', placeholder: '留空 = 不伪装；例如 www.microsoft.com' });
  const fpSel = h('select', { value: g ? g.tunnel_fp || '' : '' }, [['', '默认（Go 标准握手）'], ['chrome', '伪装成 Chrome 浏览器'], ['firefox', '伪装成 Firefox'], ['safari', '伪装成 Safari'], ['ios', '伪装成 iPhone Safari'], ['edge', '伪装成 Edge']].map(([v, t]) => h('option', { value: v }, t)));
  const protoHint = h('div', { class: 'hint' });
  const upd = () => { protoHint.textContent = proto.value === 'tls_mux' ? 'tls_mux：入口到出口只保持一条 TLS 1.3 长连接，所有转发连接是里面的多条流，省掉每次握手，网页/API 这类短连接多的场景明显更快；缺点是同一条连接上的流在丢包时会互相拖慢（队头阻塞），大流量长连接（下载、视频）建议用 tls_simple。' : proto.value === 'ws' ? '⚠ ws 不加密：入口到出口之间的内容，路径上的运营商或防火墙都能看到，只适合你确定转发的内容本身已经加密（例如 https、加密代理）、或者前面套了 CDN 的场景。一般线路请用 tls_simple 或 wss。' : proto.value === 'http' ? '⚠ http 不加密：只是把握手伪装成 HTTP 请求，内容明文可见。一般线路请用 tls_simple 或 wss。' : proto.value === 'wss' ? 'wss：WebSocket + TLS，加密，并且外面看起来像普通网页（WebSocket）流量，入口校验出口证书指纹。比 tls_simple 多一层伪装，开销略大。' : 'tls_simple：TLS 1.3 加密，入口校验出口证书指纹，开销最小，推荐。'; };
  proto.addEventListener('change', upd); upd();

  const inOnly = [
    field('可用监听端口范围', range, '规则只能使用这个范围内的端口，避免占用 22 等重要端口'),
    field('直接转发 / 入口直出策略', direct, '可选：规则里可选"直连"或某个出口；禁止：规则必须选出口；强制：只能直连（入口机器本身能访问目标时使用）。'),
    h('div', { class: 'field' }, h('label', null, '限制出口'), exitsBox, h('div', { class: 'hint' }, '选填：允许使用的“出口”设备组 ID，英文逗号分隔。设置后，用户选择本入口时，未允许的出口不会出现在出口选项里。格式填错会导致无法创建规则。可填：' + idList(exitsAll) + '。')),
    h('div', { class: 'field' }, h('label', { class: 'check' }, udpBind, ' UDP 智能绑定（源进源出）'), h('div', { class: 'hint' }, '入口机器有多个 IP（双 IP）且转发 UDP 时建议打开：在每个本机 IP 上各监听一次，回包从收到请求的那个 IP 发出，避免源地址对不上客户端收不到。')),
    h('div', { class: 'field' }, h('label', null, '连接出口时使用的 IP 版本'), v6mode, emode, v6list, v6hint),
    field('故障转移组', failover, '本组整组离线超过"负载下线时间"后，由所选入口组的服务器接手本组的全部规则（本组恢复后自动交还）。'),
  ];
  const outOnly = [
    h('div', { class: 'field' }, h('label', null, '隧道协议'), proto, protoHint),
    field('伪装域名（SNI）', sni, '入口连本出口时握手里带的域名，选一个常见大站的域名（出口不会真的去连它，只是让握手看起来像在访问这个站）。只对 tls_simple / tls_mux / wss 有效；入口节点需 0.6.21 以上，旧节点会忽略。'),
    field('TLS 指纹', fpSel, '让入口的握手报文和真实浏览器一模一样，防火墙更难把它和普通网页流量区分开。不增加延迟。'),
    field('连接 IP 版本', ipmode, '入口用哪种 IP 去连本出口组的服务器。“优先”= 先用这个版本，连不上自动换另一个（比强制更稳）；“强制”= 只用这个版本，没有就不通。用 IPv6 要求出口服务器有 IPv6 地址（节点状态里能看到），入口服务器也要能走 IPv6。设置了“对外域名”时这项不生效。优先级：对外域名 > 本项选了强制 > 入口组的“IPv6 优先出口” > 本项选了优先 > 自动。'),
    field('故障转移组', exitFb, '本出口组的服务器全部不可用时，新连接自动改走所选出口组（用它自己的协议和密钥）。建议两组允许相同的用户使用；本组恢复后自动换回。'),
    field('隧道端口', tport, '出口服务器要放行这个 TCP 端口；同一出口组的服务器用相同端口。'),
    h('div', { class: 'field' }, h('label', null, '限制入口'), entriesBox, h('div', { class: 'hint' }, '选填：允许把流量送到本出口的“入口”设备组 ID，英文逗号分隔，留空 = 不限制。可填：' + idList(entriesAll) + '。')),
  ];
  const show = () => {
    const t = type.value;
    inOnly.forEach((el) => { el.style.display = t === 'entry' || t === 'both' ? '' : 'none'; });
    outOnly.forEach((el) => { el.style.display = t === 'exit' || t === 'both' || t === 'chain' ? '' : 'none'; });
  };
  type.addEventListener('change', show);
  const fields = [field('名称', name),
    h('div', { class: 'field' }, h('label', null, '用户组 ID'), allowBox, h('div', { class: 'hint' }, '逗号分隔，留空 = 所有用户都能用；填了之后只有这些用户组的用户（包括管理员）能在规则里选它。现有用户组：' + (ugs.length ? ugs.map((u) => u.id + '=' + u.name).join('，') : '还没有，先到“用户组管理”创建') + '。')),
    field('流量倍率', mult, '0 表示不计流量；2 表示实际流量算两倍'),
    field('类型', type, editing ? '类型创建后不能修改' : '入口：用户连接的服务器；出口：隧道落地端；入口+出口：同一组服务器两种身份都当。'),
    field('对外域名', host, '一行一个。入口：用户可 CNAME 到它；出口：填了则入口节点改用这些地址连接出口（每行可写 域名:端口，不写端口就用隧道端口；多个地址都会被用上，连不上自动换下一个）。'),
    ...outOnly, ...inOnly,
    field('负载下线时间（秒）', offline, '整组离线超过这个时间，视为故障（用于故障转移）。'),
    field('离线通知宽限期（秒）', grace, '节点掉线超过这个时间才发“离线”通知；0 = 用全局默认（在“推送通知”页设置）。'),
    field('离线保留天数', retention, '节点离线超过这么多天，自动从面板移除（记录删除，不会卸载服务器上的程序）；0 = 用“站点设置”里的全局值，全局也是 0 就永不自动移除。'),
    field('在探针中隐藏', hideProbe, '节点状态页（含 /tz.html）里是否显示这个设备组：“对非管理员用户隐藏”= 只有管理员看得到；“对所有用户隐藏”= 连管理员的状态页也不显示。'),
    field('备注', remark)];
  show();
  modal(editing ? '编辑设备组' : '添加设备组', fields, (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      const t = editing ? g.type : type.value;
      const body = { name: name.value.trim(), multiplier: Number(mult.value), connect_host: host.value.trim(), remark: remark.value.trim(), offline_seconds: Number(offline.value) || 60,
        allow_groups: allowBox.value.replace(/[，\s]+/g, ',').replace(/^,+|,+$/g, ''), hide_probe: Number(hideProbe.value), grace_seconds: Number(grace.value) || 0, retention_days: Number(retention.value) || 0 };
      if (t === 'exit' || t === 'both' || t === 'chain') { body.protocol = proto.value; body.tunnel_sni = sni.value.trim(); body.tunnel_fp = fpSel.value; body.ip_mode = ipmode.value; body.exit_failover_id = Number(exitFb.value) || 0; if (tport.value) body.tunnel_port = Number(tport.value); body.allow_entries = pickIDs(entriesBox); }
      if (t === 'entry' || t === 'both') { body.ipv6_group = v6value(); body.entry_ip_mode = v6mode.value === 'none' ? '' : emode.value; body.port_range = range.value.trim(); body.failover_group_id = Number(failover.value) || 0; body.direct_policy = Number(direct.value); body.udp_smart_bind = udpBind.checked ? 1 : 0; body.allow_exits = pickIDs(exitsBox); }
      try {
        if (editing) await api('PUT', '/device_groups/' + g.id, body);
        else {
          const r = await api('POST', '/device_groups', { ...body, type: t, failover_group_id: body.failover_group_id || undefined });
          m.close(); await done(); showJoinCommand(r.group, r.join_key); return;
        }
        toast('已保存'); m.close(); done();
      } catch (e) { fail(e); }
    } }, editing ? '保存' : '创建'),
  ]);
}

async function showJoinCommand(g, key, opts) {
  let mir = { global: [], cn: [] };
  try { mir = await api('GET', '/node_mirrors'); } catch (e) { /* 取不到镜像就只显示面板直连 */ }
  const o = mir.panel || location.origin;
  if (/^https?:\/\/(\[[0-9a-fA-F:]+\]|[0-9.]+)(:\d+)?$/.test(o)) {
    return modal('需要先设置面板域名', [h('p', null, '节点对接不能使用纯 IP 地址（容易被识别，也不安全）。'), h('p', null, '请先给面板绑定一个域名，再到“站点设置 → 面板对接域名”填上（http:// 或 https:// 开头），然后回来复制命令。')], (m) => [h('button', { class: 'btn', onclick: m.close }, '知道了')]);
  }
  const mk = (list) => `bash <(${list.map((m) => `curl -fLSs --connect-timeout 8 --max-time 20 ${m}/install.sh`).join(' || ')}) -p ${o} -k ${key} -m "${list.join(' ')}"`;
  const direct = `bash <(curl -fLSs ${o}/agent/install.sh) -k ${key}`;
  const bundleURL = `${o}/agent/bundle.tar.gz?key=${key}`;
  const bundleCmd = `curl -fsSL "${bundleURL}" -o ocean-bundle.tar.gz && tar xzf ocean-bundle.tar.gz && bash ocean-bundle/install.sh`;
  const blocks = [];
  const cmds = [];
  const optBBR = h('input', { type: 'checkbox' }), optTools = h('input', { type: 'checkbox' });
  const prefix = () => (optBBR.checked ? 'OPTIMIZE=1 ' : '') + (optTools.checked ? 'INSTALL_TOOLS=1 ' : '');
  const repaint = () => cmds.forEach(({ box, cmd, env }) => { box.textContent = (env ? prefix() : '') + cmd; });
  optBBR.addEventListener('change', repaint); optTools.addEventListener('change', repaint);
  blocks.push(h('div', { class: 'toolbar', style: 'margin:0 0 4px' },
    h('label', { class: 'check' }, optBBR, ' 安装时优化系统参数（开启 BBR、调大缓冲区）'),
    h('label', { class: 'check', style: 'margin-left:14px' }, optTools, ' 安装常用工具（htop / mtr / iperf3 等）')));
  const add = (title, desc, cmd, env = true) => { const box = h('div', { class: 'cmd mono' }, cmd); cmds.push({ box, cmd, env }); blocks.push(h('p', { style: 'margin:12px 0 4px' }, h('b', null, title), desc ? '  ' + desc : ''), box, h('div', { style: 'margin-top:6px' }, h('button', { class: 'btn sm', onclick: () => copyText(box.textContent, box) }, '复制'))); };
  if (mir.global.length) add('境外服务器', '（镜像依次尝试，失败自动换下一个）', mk(mir.global));
  if (mir.cn.length) add('境内服务器', '（镜像依次尝试，失败自动换下一个）', mk(mir.cn));
  if (mir.global.length && !mir.cn.length) blocks.push(h('p', { class: 'muted small' }, '境内服务器还没有配置境内镜像：先用上面这条（GitHub），下载不了会自动改从面板下载。')); 
  if (!mir.global.length && !mir.cn.length) blocks.push(h('p', { class: 'muted small' }, '还没有配置安装包镜像，下面用面板直连。到“站点设置 → 节点安装镜像”填上你放节点程序的地址（境外 / 境内各一组），这里就会出现带自动换源的命令。'));
  add('面板直连', '（节点能访问面板时）', direct);
  add('离线部署包', '（节点连不上面板下载时；包里自带 amd64 / arm64 程序）', bundleCmd);
  modal(`对接设备组「${g.name}」`, [...blocks,
    h('p', { class: 'muted small', style: 'margin-top:12px' }, '命令里带有对接密钥，请勿公开。每次打开这里看到的都是同一条，只有点“重置密钥”才会变。同组多台服务器可用同一条命令；每台服务器会自动用主机名作为节点名，想指定名字在命令后加 -n 名称。')], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '关闭'),
    h('button', { class: 'btn', onclick: () => { m.close(); (opts && opts.reset) ? opts.reset() : resetGroupKey(g); } }, '重置密钥'),
    h('a', { class: 'btn', style: 'text-decoration:none', href: bundleURL, download: 'ocean-bundle.tar.gz' }, '下载离线包'),
  ], true);
}

// 高级编辑：直接改设备组的 JSON 配置（对应 ny 的"高级编辑"）
function advancedDialog(g, done) {
  const keys = ['protocol', 'tunnel_sni', 'tunnel_fp', 'ip_mode', 'exit_failover_id', 'tunnel_port', 'udp_smart_bind', 'grace_seconds', 'direct_policy', 'allow_exits', 'allow_entries', 'hide_probe', 'offline_seconds', 'port_range', 'connect_host', 'multiplier', 'allow_groups', 'ipv6_group', 'entry_ip_mode', 'blocked_protocol', 'allowed_host', 'blocked_host', 'blocked_path', 'disable_udp'];
  const cur = {};
  keys.forEach((k) => { if (g[k] !== undefined && g[k] !== null && g[k] !== '') cur[k] = k === 'ipv6_group' ? String(g[k]).split(',').map(Number).filter((n) => !Number.isNaN(n)) : g[k]; });
  const ta = h('textarea', { class: 'mono', style: 'min-height:260px' });
  ta.value = JSON.stringify(cur, null, 2);
  modal(`${g.name} (#${g.id}) 高级编辑`, [
    h('p', { class: 'muted small' }, '直接编辑 JSON。可用字段：' + keys.join('、') + '。字段含义同编辑弹窗；direct_policy：0 可选 / 1 禁止 / 2 强制直接转发；ip_mode：空 = 自动 / "v4" = 仅 IPv4 / "v6" = 仅 IPv6（入口连出口用的 IP 版本）。entry_ip_mode：入口组里填 p6 / p4 / v6 / v4，决定 ipv6_group 里这些出口用哪种 IP 版本（不填 = p6 优先 IPv6）。ipv6_group：入口组里填 [3,4] = 这些出口优先 IPv6，[0] = 全部出口优先 IPv6，[0,1,2] = 全部优先 IPv6 但 1、2 优先 IPv4；ip_mode 可填 p4 / p6（优先，失败自动回退）或 v4 / v6（强制）；connect_host 用换行 \\n 隔开多个地址。入口屏蔽（只对入口设备组有效，节点需 0.6.14）：blocked_protocol 填 socks,http,tls,fet 中的几个（fet = 全加密流量，如 SS 类）；allowed_host / blocked_host 是域名白名单 / 黑名单（后缀匹配，逗号或换行分隔；设了白名单后，识别不出域名的连接也会被拒）；blocked_path 屏蔽 HTTP 请求路径（前缀匹配）；disable_udp 填 1 = 本组不转发 UDP。'),
    ta,
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      let o;
      try { o = JSON.parse(ta.value); if (!o || typeof o !== 'object' || Array.isArray(o)) throw new Error(); } catch { return fail(new Error('不是合法的 JSON 对象')); }
      const body = {};
      for (const k of Object.keys(o)) { if (!keys.includes(k)) return fail(new Error('不支持的字段：' + k)); body[k] = o[k]; }
      try { await api('PUT', '/device_groups/' + g.id, body); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '确定'),
  ], true);
}

async function joinDialog(g) {
  try { const r = await api('GET', `/device_groups/${g.id}/join_key`); showJoinCommand(g, r.join_key); } catch (e) { fail(e); }
}
function resetGroupKey(g) {
  confirmBox('重置对接密钥', `重置设备组「${g.name}」的对接密钥后，旧的安装命令 / 离线包链接将失效。已经接入的服务器不受影响。继续吗？`, async () => {
    try { const r = await api('POST', `/device_groups/${g.id}/rotate_key`); toast('已重置'); showJoinCommand(g, r.join_key); } catch (e) { fail(e); }
  });
}

// ------------------------------------------------------------ 节点
const fmtSpeed = (bps) => fmtBytes(bps) + '/s';
const fmtUp = (sec) => (sec >= 86400 ? Math.floor(sec / 86400) + ' 天' : sec >= 3600 ? Math.floor(sec / 3600) + ' 小时' : Math.floor(sec / 60) + ' 分钟');
function meter(pct, label) {
  pct = Math.max(0, Math.min(100, pct || 0));
  return h('div', { class: 'meter', title: label }, h('div', { class: 'bar' + (pct > 90 ? ' hot' : pct > 70 ? ' warm' : ''), style: `width:${pct}%` }), h('span', null, label));
}

function nodeDialog(n, done) {
  const name = h('input', { type: 'text', value: n.name, maxlength: 64 });
  const weight = h('input', { type: 'number', min: '0', max: '1000', value: String(n.weight === undefined ? 1 : n.weight) });
  modal(`编辑节点「${n.name}」`, [
    field('名称', name),
    field('权重', weight, '出口组里有多台节点时，入口按权重比例分配新连接（权重 2 的节点接到的连接约是权重 1 的两倍）。0 = 暂时不接入口来的连接（已有连接不受影响，节点仍在线可用来排障/升级）。只对作为出口的设备组有效。'),
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      try { await api('PUT', '/nodes/' + n.id, { name: name.value.trim(), weight: Number(weight.value) }); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '保存'),
  ]);
}

// 线路质量：入口节点到各出口的 TCP 探测（每 5 秒一次，30 秒汇总），最近 1 小时
async function linkqDialog(n) {
  const body = h('div', null, h('div', { class: 'muted' }, '加载中…'));
  const m = modal(`线路质量「${n.name}」`, [body], (mm) => [h('button', { class: 'btn', onclick: mm.close }, '关闭')], true);
  const draw = async () => {
    let r;
    try { r = await api('GET', '/nodes/' + n.id + '/linkq'); } catch (e) { fill(body, h('div', { class: 'muted' }, String(e.message || e))); return; }
    const eps = r.endpoints || [];
    if (!eps.length) { fill(body, h('div', { class: 'muted' }, '还没有数据。只有作为入口、且规则用到出口节点的节点才会探测；节点需升级到 0.6.14，等 30 秒后刷新。')); return; }
    fill(body, h('div', { class: 'small muted', style: 'margin-bottom:8px' }, '每 5 秒对出口做一次 TCP 连接探测。丢包 = 3 秒内没连上。线条是 30 秒平均延迟，红点表示该时段有失败。'),
      ...eps.map((e) => {
        const bs = e.buckets || [];
        const W = 520, H = 90, mx = Math.max(50, ...bs.map((b) => b.max || b.avg || 0));
        const x = (i) => bs.length < 2 ? W / 2 : 6 + i * (W - 12) / (bs.length - 1);
        const y = (v) => H - 6 - (Math.min(v, mx) / mx) * (H - 14);
        const pts = bs.map((b, i) => b.n - b.fail > 0 ? `${x(i).toFixed(1)},${y(b.avg).toFixed(1)}` : null).filter(Boolean).join(' ');
        const mk = (t, a) => { const el = document.createElementNS('http://www.w3.org/2000/svg', t); for (const k in a) el.setAttribute(k, a[k]); return el; };
        const svg = mk('svg', { viewBox: `0 0 ${W} ${H}`, width: '100%', style: 'max-width:' + W + 'px;background:var(--bg2,#0001);border-radius:6px' });
        svg.appendChild(mk('polyline', { points: pts, fill: 'none', stroke: 'var(--primary,#4a8)', 'stroke-width': 1.5 }));
        bs.forEach((b, i) => { if (b.fail > 0) svg.appendChild(mk('circle', { cx: x(i), cy: H - 8, r: 3, fill: '#e44' })); });
        const loss = e.n ? (e.fail * 100 / e.n).toFixed(1) : '0';
        return h('div', { class: 'card', style: 'margin-bottom:10px;padding:10px' },
          h('div', null, h('b', null, e.name || e.endpoint), e.name ? h('span', { class: 'muted small mono' }, '  ' + e.endpoint) : null),
          h('div', { class: 'small', style: 'margin:4px 0' }, `平均 ${e.avg} ms · 最高 ${e.max} ms · 丢包 ${loss}%（${e.fail}/${e.n}）`), svg);
      }));
  };
  await draw();
  const t = setInterval(() => { if (!document.body.contains(body)) return clearInterval(t); draw().catch(() => {}); }, 15000);
  return m;
}

async function pageNodes(main) {
  const draw = async () => {
    const [nodes, groups] = await Promise.all([api('GET', '/nodes'), api('GET', '/device_groups')]);
    const gname = Object.fromEntries(groups.map((g) => [g.id, g.name]));
    const outdated = nodes.filter((n) => n.online && n.outdated);
    const rows = nodes.map((n) => {
      const st = n.stats;
      return h('tr', null,
        h('td', null, n.id),
        h('td', null, h('div', null, n.name), h('div', { class: 'muted small' }, gname[n.group_id] || '—')),
        h('td', { class: 'mono' }, n.public_ip || '—'),
        h('td', null, n.weight === 0 ? h('span', { class: 'chip warn' }, '0 暂停接入') : n.weight),
        h('td', null, n.online ? h('span', { class: 'chip ok' }, '在线') : h('span', { class: 'chip bad' }, '离线'), h('div', { class: 'muted small' }, n.online && st ? '已运行 ' + fmtUp(st.agent_uptime) : ago(n.last_seen))),
        h('td', { class: 'meters' }, n.online && st ? [meter(st.cpu, 'CPU ' + st.cpu.toFixed(0) + '%'), meter(st.mem_total ? st.mem_used / st.mem_total * 100 : 0, `内存 ${fmtBytes(st.mem_used)} / ${fmtBytes(st.mem_total)}`), st.disk_total ? meter(st.disk_used / st.disk_total * 100, `存储 ${fmtBytes(st.disk_used)} / ${fmtBytes(st.disk_total)}`) : null] : h('span', { class: 'muted' }, '—')),
        h('td', { class: 'nowrap small' }, n.online && st ? [h('div', null, '↓ ' + fmtSpeed(st.net_in_bps)), h('div', null, '↑ ' + fmtSpeed(st.net_out_bps))] : '—'),
        h('td', null, n.online && st ? [h('div', null, st.conns + ' 条'), h('div', { class: 'muted small' }, '负载 ' + st.load1.toFixed(2))] : '—'),
        h('td', null, h('div', null, n.version || '—', n.outdated ? h('span', { class: 'chip warn', style: 'margin-left:4px' }, '可升级') : null),
          st && st.upgrade_msg ? h('div', { class: 'muted small' }, st.upgrade_msg) : null),
        h('td', null,
          n.apply_status === 'ok' ? h('span', { class: 'chip ok' }, '已生效') : n.apply_status === 'error' ? h('span', { class: 'chip bad' }, '失败') : h('span', { class: 'chip' }, '—'),
          h('span', { class: 'muted small' }, ' v' + n.applied_revision),
          n.apply_error ? h('div', { class: 'small', style: 'color:var(--danger);max-width:300px;word-break:break-all' }, n.apply_error) : null),
        h('td', { class: 'actions' },
          n.online ? h('button', { class: 'btn sm', onclick: () => window.open('/term.html?node=' + n.id, '_blank') }, '终端') : null,
          n.online ? h('button', { class: 'btn sm', onclick: () => linkqDialog(n) }, '线路') : null,
          h('button', { class: 'btn sm', onclick: () => nodeDialog(n, draw) }, '编辑'),
          n.online && n.outdated ? h('button', { class: 'btn sm primary', onclick: () => upgrade([n.id]) }, '升级') : null,
          h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除节点', `删除节点「${n.name}」后，它会被断开并停止所有转发。确定吗？`, async () => {
            try { await api('DELETE', '/nodes/' + n.id); toast('已删除'); draw(); } catch (e) { fail(e); }
          }, true) }, '删除')));
    });
    async function upgrade(ids) {
      try {
        const r = await api('POST', '/nodes/upgrade', { ids });
        toast(`已向 ${r.sent} 个节点发出升级指令，它们会下载新版本并自动重启`);
        (r.notes || []).forEach((t) => toast(t, true));
        setTimeout(() => draw().catch(() => {}), 6000);
      } catch (e) { fail(e); }
    }
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '节点状态'), h('button', { class: 'btn', onclick: () => draw().catch(fail) }, '刷新'),
        outdated.length ? h('button', { class: 'btn primary', onclick: () => confirmBox('升级节点', `把 ${outdated.length} 个在线且版本落后的节点升级到最新节点程序？节点会短暂重启（几秒），已有连接会断开一次。`, () => upgrade([])) }, `一键升级落后节点（${outdated.length}）`) : null),
      nodes.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('thead', null, h('tr', null, ['ID', '节点 / 设备组', '公网 IP', '权重', '状态', '资源', '网速', '连接 / 负载', '版本', '规则应用', '操作'].map((t) => h('th', null, t)))),
        h('tbody', null, rows))) : h('div', { class: 'card empty' }, '还没有节点。到"设备组"页点"对接"，在服务器上运行安装命令。'));
  };
  await draw();
  autoRefresh(draw, 5000);
}

// ------------------------------------------------------------ 转发规则
const R = { rules: [], groups: [], users: [], selected: new Set(), q: '', f: { name: '', entry: '', exit: '', port: '', target: '' }, gid: '', gname: '', st: '', sort: '', dir: 1, uid: 0, page: 0, size: 100 }; window.fwR = R;

async function pageRules(main) {
  const isAdm = state.me.role === 'admin';
  const load = async () => {
    [R.rules, R.groups] = await Promise.all([api('GET', '/rules'), api('GET', isAdm ? '/device_groups' : '/groups/available')]);
    if (isAdm) R.users = await api('GET', '/users');
    else { state.me = await api('GET', '/me'); state.refreshWho && state.refreshWho(); }
    const ids = new Set(R.rules.map((r) => r.id));
    R.selected = new Set([...R.selected].filter((id) => ids.has(id)));
  };
  const entryGroups = () => R.groups.filter((g) => g.type === 'entry' || g.type === 'both');
  const gname = () => Object.fromEntries(R.groups.map((g) => [g.id, g.name]));
  // 同步状态由面板根据节点上报算出：ok 正常 / pending 未同步 / fail 同步失败（含原因）/ paused / blocked
  const syncFail = (r) => r.sync === 'fail';
  const sortVal = {
    name: (r) => r.name.toLowerCase(), entry: (r) => (gname()[r.entry_group_id] || ''), exit: (r) => (r.exit_group_id ? (gname()[r.exit_group_id] || '') : ''),
    used: (r) => r.total_in + r.total_out, status: (r) => ({ fail: 0, blocked: 1, pending: 2, ok: 3, paused: 4 }[r.sync] ?? 5),
  };
  const sorted = (a) => {
    if (!R.sort) return a;
    const f = sortVal[R.sort];
    return [...a].sort((x, y) => { const p = f(x), q = f(y); return (p < q ? -1 : p > q ? 1 : 0) * R.dir; });
  };
  const filtered = () => sorted(R.rules.filter((r) =>
    (!R.f.name || r.name.toLowerCase().includes(R.f.name.toLowerCase())) &&
    (!R.f.entry || String(r.entry_group_id) === R.f.entry) &&
    (!R.f.exit || (R.f.exit === '0' ? !r.exit_group_id : String(r.exit_group_id) === R.f.exit)) &&
    (!R.f.port || String(r.listen_port) === R.f.port.trim()) &&
    (!R.f.target || (r.targets && r.targets.length ? r.targets : [`${r.target_host}:${r.target_port}`]).join(' ').toLowerCase().includes(R.f.target.toLowerCase())) &&
    (!R.st || (R.st === 'fail' ? syncFail(r) : R.st === 'pending' ? r.sync === 'pending' : R.st === 'paused' ? !r.enabled : r.enabled)) &&
    (!R.uid || r.user_id === R.uid) &&
    (!R.gid || String(r.entry_group_id) === R.gid) &&
    (!R.gname || (R.gname === '\u0000' ? !r.group_name : r.group_name === R.gname)) &&
    (!R.q || [r.name, r.remark, r.username || '', r.target_host, String(r.listen_port), String(r.target_port)].join(' ').toLowerCase().includes(R.q.toLowerCase()))));

  const reload = async () => { await load(); draw(); };
  const batch = async (action, extra) => {
    const ids = [...R.selected];
    if (!ids.length) return toast('请先勾选规则', true);
    try { await api('POST', '/rules/batch', { action, ids, ...extra }); R.selected.clear(); await reload(); toast('操作完成'); } catch (e) { fail(e); }
  };

  function draw() {
    const list = filtered();
    const pages = Math.max(1, Math.ceil(list.length / R.size));
    if (R.page >= pages) R.page = pages - 1;
    const shown = list.slice(R.page * R.size, (R.page + 1) * R.size);
    const names = gname();
    const allChecked = shown.length > 0 && shown.every((r) => R.selected.has(r.id));
    const scope = R.uid ? R.rules.filter((r) => r.user_id === R.uid) : R.rules;
    const groupNames = [...new Set(scope.map((r) => r.group_name).filter(Boolean))].sort();
    const cnt = (n) => scope.filter((r) => (n === '\u0000' ? !r.group_name : r.group_name === n)).length;
    const tag = (label, val, n) => h('button', { class: 'chip' + (R.gname === val ? ' ok' : ''), style: 'cursor:pointer;border:0', onclick: () => { R.gname = val; R.page = 0; draw(); } }, label + (n === undefined ? '' : ' (' + n + ')'));

    const rows = shown.map((r) => h('tr', null,
      h('td', null, h('input', { type: 'checkbox', checked: R.selected.has(r.id), onchange: (e) => { e.target.checked ? R.selected.add(r.id) : R.selected.delete(r.id); draw(); } })),
      h('td', null, h('div', null, r.name, h('span', { class: 'muted small', style: 'margin-left:4px' }, `(#${r.id})`), r.group_name ? h('span', { class: 'chip', style: 'margin-left:6px' }, r.group_name) : null),
        isAdm && r.user_id && r.user_id !== state.me.id ? h('div', { class: 'small' }, h('span', { class: 'chip warn' }, '用户 ' + (r.username || r.user_id))) : null,
        r.remark ? h('div', { class: 'muted small' }, r.remark) : null),
      h('td', null, h('div', null, names[r.entry_group_id] || '（已删除）'), h('div', { class: 'mono muted small' }, ':' + r.listen_port)),
      h('td', null, r.exit_group_id ? h('span', { class: 'chip ok' }, [r.exit_group_id].concat((r.exit_chain || '').split(',').filter(Boolean).map(Number)).map((id) => names[id] || '（已删除）').join(' → ')) : h('span', { class: 'muted small' }, '直连')),
      h('td', { class: 'mono' }, (r.targets && r.targets[0]) || `${r.target_host}:${r.target_port}`,
        r.targets && r.targets.length > 1 ? h('div', { class: 'muted small' }, `共 ${r.targets.length} 个目标 · ${LB_LABEL[r.lb_mode] || r.lb_mode}`) : null),
      h('td', { class: 'nowrap', title: `↑ ${fmtBytes(r.total_in)}  ↓ ${fmtBytes(r.total_out)}` }, h('div', null, gib(r.total_in + r.total_out)), h('div', { class: 'muted small' }, `↑ ${gib(r.total_in)}  ↓ ${gib(r.total_out)}`)),
      h('td', null, h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: r.enabled, onchange: async (e) => {
        try { await api('POST', '/rules/batch', { action: e.target.checked ? 'enable' : 'disable', ids: [r.id] }); r.enabled = e.target.checked; } catch (err) { e.target.checked = !e.target.checked; fail(err); }
      } }), h('span')), ({
          ok: () => h('div', { class: 'small', style: 'margin-top:2px' }, h('span', { class: 'chip ok' }, '正常')),
          pending: () => h('div', { class: 'small', style: 'margin-top:2px' }, h('span', { class: 'chip', title: r.sync_msg || '' }, '未同步')),
          fail: () => h('div', { class: 'small', style: 'margin-top:2px;max-width:220px' }, h('span', { class: 'chip bad', title: r.sync_msg }, '同步失败'), h('div', { class: 'muted small' }, (r.sync_msg || '').replace(/^规则 #\d+ /, ''))),
          blocked: () => h('div', { class: 'small', style: 'margin-top:2px' }, h('span', { class: 'chip warn', title: r.sync_msg }, '账号受限')),
        }[r.sync] || (() => null))()),
      h('td', { class: 'actions' },
        h('button', { class: 'btn sm', onclick: () => diagnoseDialog(r) }, '诊断'),
        h('button', { class: 'btn sm', onclick: () => trafficDialog(r) }, '流量'),
        h('button', { class: 'btn sm', onclick: () => ruleDialog(r, entryGroups(), reload) }, '编辑'),
        h('button', { class: 'btn sm', title: '复制这条规则（监听端口自动分配）', onclick: async () => {
          try { const res = await api('POST', '/rules', { ...ruleBody(r), name: (r.name + ' 副本').slice(0, 64), listen_port: 0 }); toast(`已复制，新规则监听端口 ${res.listen_port}`); reload(); } catch (e) { fail(e); }
        } }, '复制'),
        h('button', { class: 'btn sm', onclick: () => ruleAdvDialog(r, reload) }, '高级编辑'),
        h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除规则', `删除规则「${r.name}」(:${r.listen_port})？`, async () => {
          try { await api('POST', '/rules/batch', { action: 'delete', ids: [r.id] }); toast('已删除'); reload(); } catch (e) { fail(e); }
        }, true) }, '删除'))));

    const search = h('input', { type: 'text', placeholder: '搜索 名称/备注/目标/端口', value: R.q, oninput: (e) => { R.q = e.target.value; R.page = 0; draw(); setTimeout(() => { const el = document.getElementById('rule-q'); if (el) { el.focus(); el.setSelectionRange(R.q.length, R.q.length); } }); } });
    search.id = 'rule-q';
    const selCount = R.selected.size;
    fill(main, 
      h('div', { class: 'page-title' }, h('h2', null, !isAdm ? '我的规则' : R.uid ? `用户转发规则 (${((R.users.find((u) => u.id === R.uid) || {}).username) || ''} · UID=${R.uid})` : '转发规则'),
        isAdm && R.uid ? h('button', { class: 'btn sm', onclick: () => { if (state.standalone) { location.href = '/#rules'; return; } R.uid = 0; R.page = 0; R.selected.clear(); state.render('rules'); } }, '显示全部规则') : null,
        isAdm && R.uid ? h('button', { class: 'btn sm', onclick: () => { if (state.standalone) { location.href = '/#users'; return; } R.uid = 0; state.render('users'); } }, '返回用户列表') : null,
        h('span', { class: 'muted' }, `共 ${R.rules.length} 条${!isAdm && state.me.rule_limit ? ' / 上限 ' + state.me.rule_limit : ''}，当前显示 ${list.length} 条`)),
      (() => {
        const ou = isAdm && R.uid ? (R.users.find((u) => u.id === R.uid) || null) : (!isAdm ? state.me : null);
        if (!ou) return null;
        const n = scope.length, rlim = ou.rule_limit;
        return h('div', { class: 'toolbar' },
          h('span', { class: 'chip' }, '流量 ' + fmtBytes(ou.traffic_used) + ' / ' + (ou.traffic_limit ? fmtBytes(ou.traffic_limit) : '不限')),
          h('span', { class: 'chip' }, '到期 ' + (ou.expire_at ? fmtTime(ou.expire_at).slice(0, 10) : '永久')),
          h('span', { class: 'chip' }, '规则 ' + n + ' / ' + (rlim ? rlim : '不限')));
      })(),
      !isAdm && state.me.blocked ? h('div', { class: 'banner bad' }, state.me.blocked_msg, ' ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); state.render('store'); } }, '去商店')) : null,
      h('div', { class: 'toolbar' },
        h('button', { class: 'btn primary', onclick: () => ruleDialog(null, entryGroups(), reload) }, '添加规则'),
        h('button', { class: 'btn' + (Object.values(R.f).some(Boolean) ? ' primary' : ''), onclick: () => searchDialog(entryGroups(), () => { R.page = 0; draw(); }) }, Object.values(R.f).some(Boolean) ? '搜索规则（已筛选）' : '搜索规则'),
        h('button', { class: 'btn', onclick: () => importDialog(entryGroups(), groupNames, reload) }, '批量导入'),
        h('button', { class: 'btn', onclick: () => exportDialog([...R.selected], list) }, selCount ? `导出选中(${selCount})` : '导出当前列表'),
        h('button', { class: 'btn', onclick: () => reload().catch(fail) }, '刷新'),
        h('button', { class: 'btn', onclick: () => ruleGroupsDialog(reload) }, '管理分组'),
        h('button', { class: 'btn', onclick: () => statsDialog() }, '统计数据'),
        h('span', { class: 'grow' }), search),
      h('div', { class: 'toolbar' }, h('span', { class: 'muted small' }, '分组：'), tag('全部', ''), groupNames.map((n) => tag(n, n, cnt(n))), tag('未分组', '\u0000', cnt('\u0000')),
        h('select', { value: R.gid, onchange: (e) => { R.gid = e.target.value; R.page = 0; draw(); } }, h('option', { value: '' }, '全部入口'), entryGroups().map((g) => h('option', { value: String(g.id) }, g.name))),

        h('select', { value: R.st, onchange: (e) => { R.st = e.target.value; R.page = 0; draw(); } }, [['', '全部状态'], ['fail', '同步失败'], ['pending', '未同步'], ['paused', '已暂停'], ['running', '未暂停']].map(([v, t]) => h('option', { value: v }, t))),
        h('span', { class: 'muted small' }, selCount ? `已选 ${selCount} 条：` : '勾选规则后可批量操作：'),
        h('button', { class: 'btn sm', disabled: !selCount, onclick: () => batch('enable') }, '启用'),
        h('button', { class: 'btn sm', disabled: !selCount, onclick: () => batch('disable') }, '停用'),
        isAdm ? h('button', { class: 'btn sm', disabled: !selCount, onclick: () => confirmBox('清空流量', `清空选中的 ${selCount} 条规则的累计流量？`, () => batch('clear_traffic')) }, '清空流量') : null,
        h('button', { class: 'btn sm', disabled: !selCount, onclick: () => switchDialog([...R.selected], entryGroups(), reload) }, '批量切换'),
        h('button', { class: 'btn sm', disabled: !selCount, onclick: () => setGroupDialog(groupNames, (g) => batch('set_group', { group_name: g })) }, '设置分组'),
        h('button', { class: 'btn sm danger', disabled: !selCount, onclick: () => confirmBox('删除规则', `删除选中的 ${selCount} 条规则？此操作不能撤销。`, () => batch('delete'), true) }, '删除')),
      shown.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('thead', null, h('tr', null,
          h('th', null, h('input', { type: 'checkbox', checked: allChecked, onchange: (e) => { shown.forEach((r) => (e.target.checked ? R.selected.add(r.id) : R.selected.delete(r.id))); draw(); } })),
          [['规则名', 'name'], ['入口', 'entry'], ['出口', 'exit'], ['目标地址', ''], ['已用流量', 'used'], ['状态', 'status'], ['操作', '']].map(([t, k]) => k
            ? h('th', { class: 'sortable', style: 'cursor:pointer;user-select:none;white-space:nowrap', title: '点击排序', onclick: () => { if (R.sort === k) { if (R.dir === 1) R.dir = -1; else { R.sort = ''; R.dir = 1; } } else { R.sort = k; R.dir = 1; } draw(); } },
              t, h('span', { class: R.sort === k ? '' : 'muted', style: 'margin-left:4px;font-size:11px' }, R.sort === k ? (R.dir === 1 ? '▲' : '▼') : '⇅'))
            : h('th', null, t)))),
        h('tbody', null, rows))) : h('div', { class: 'card empty' }, R.rules.length ? '没有符合条件的规则' : '还没有规则，点"添加规则"或"批量导入"。'),
      pages > 1 ? h('div', { class: 'pager' },
        h('button', { class: 'btn sm', disabled: R.page === 0, onclick: () => { R.page--; draw(); } }, '上一页'),
        h('span', { class: 'muted' }, `${R.page + 1} / ${pages}`),
        h('button', { class: 'btn sm', disabled: R.page >= pages - 1, onclick: () => { R.page++; draw(); } }, '下一页')) : null);
  }

  await load();
  draw();
  autoRefresh(async () => { await load(); draw(); }, 10000);
  // 有"未同步"的规则（刚创建 / 刚改动）时每 2 秒刷新一次，同步好立刻变"正常"，不用手动点刷新
  let fast = 0;
  const fastTick = setInterval(async () => {
    if (!document.body.contains(main)) return clearInterval(fastTick);
    if (document.hidden || document.querySelector('dialog[open]')) return;
    if (!R.rules.some((r) => r.sync === 'pending' && r.enabled)) { fast = 0; return; }
    if (++fast > 30) return; // 最多追 1 分钟，再没好就交给 10 秒一次的普通刷新
    try { await load(); draw(); } catch { /* 下次再试 */ }
  }, 2000);
}

// 搜索规则（同 ny）：名称模糊、入口、出口、监听端口精确、目标地址或端口模糊
function searchDialog(entryGroups, done) {
  const f = R.f;
  const name = h('input', { type: 'text', value: f.name });
  const sel = (v, opts) => h('select', { value: v }, h('option', { value: '' }, '全部'), opts);
  const entry = sel(f.entry, entryGroups.map((g) => h('option', { value: String(g.id) }, g.name)));
  const exit = sel(f.exit, [h('option', { value: '0' }, '直连（无出口）')].concat(R.groups.filter((g) => g.type === 'exit' || g.type === 'both').map((g) => h('option', { value: String(g.id) }, g.name))));
  entry.value = f.entry; exit.value = f.exit;
  const port = h('input', { type: 'number', min: 1, max: 65535, value: f.port });
  const target = h('input', { type: 'text', value: f.target });
  const apply = (m, o) => { Object.assign(R.f, o); m.close(); done(); };
  modal('搜索规则', [field('规则名称 (模糊)', name), field('入口', entry), field('出口', exit), field('监听端口 (精确)', port), field('目标地址或端口 (模糊)', target)], (m) => [
    h('button', { class: 'btn', onclick: () => apply(m, { name: '', entry: '', exit: '', port: '', target: '' }) }, '重置'),
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: () => apply(m, { name: name.value.trim(), entry: entry.value, exit: exit.value, port: port.value.trim(), target: target.value.trim() }) }, '确定'),
  ], true);
}

function groupOptionLabel(g) {
  const cnt = g.node_count === undefined ? '' : g.node_count === 0 ? ' · 无设备' : ` · ${g.online_count}/${g.node_count} 在线`;
  return `${g.name} · 倍率 ${g.multiplier}${cnt}`;
}
const gib = (n) => ((n || 0) / 1073741824).toFixed(2) + ' GiB';
const PROTO_RULE = { tcp: 'TCP', udp: 'UDP', both: 'TCP+UDP' };

// 按入口组的直连策略 / 限制出口，以及出口组的限制入口，给出可选项
function exitOptions(eg) {
  const dp = eg ? eg.direct_policy || 0 : 0;
  const lim = eg && eg.allow_exits ? eg.allow_exits.split(',') : null;
  const exits = dp === 2 ? [] : R.groups.filter((g) => (g.type === 'exit' || g.type === 'both') && (!lim || lim.includes(String(g.id))) &&
    !(g.allow_entries && eg && !g.allow_entries.split(',').includes(String(eg.id))));
  return [dp === 1 ? null : h('option', { value: '0' }, '直连（不经过出口）'),
    exits.map((g) => h('option', { value: String(g.id) }, `${g.name} · ${protoName(g.protocol)}${g.node_count === undefined ? '' : ` · ${g.online_count}/${g.node_count} 在线`}`))];
}
const lbOptions = () => Object.entries(LB_LABEL).map(([k, v]) => h('option', { value: k }, v));

function ruleDialog(r, entryGroups, done) {
  const editing = !!r;
  if (!entryGroups.length) return fail(new Error('请先到"设备组"页创建一个入口设备组'));
  const name = h('input', { type: 'text', value: r ? r.name : '', maxlength: 64, placeholder: '留空则自动用第一个目标地址' });
  const entry = h('select', { value: r ? String(r.entry_group_id) : String(entryGroups[0].id) }, entryGroups.map((g) => h('option', { value: String(g.id) }, groupOptionLabel(g))));
  const exit = h('select', null);
  const curEntry = () => entryGroups.find((x) => String(x.id) === entry.value);
  const fillExit = (want) => { fill(exit, exitOptions(curEntry())); exit.value = want; if (exit.value !== want) exit.selectedIndex = 0; };
  fillExit(r && r.exit_group_id ? String(r.exit_group_id) : '0');
  const chainBox = h('div', null);
  let chain = r && r.exit_chain ? r.exit_chain.split(',').filter(Boolean) : [];
  const chainOpts = (cur) => R.groups.filter((g) => g.type === 'exit' || g.type === 'both' || g.type === 'chain').map((g) => h('option', { value: String(g.id), selected: String(g.id) === cur }, `${g.name} · ${protoName(g.protocol)}`));
  const drawChain = () => {
    const hasExit = exit.value !== '0';
    fill(chainBox, hasExit ? [
      ...chain.map((cid, i) => h('div', { class: 'row-inline' }, h('span', { class: 'muted small' }, `第 ${i + 2} 跳`), h('select', { onchange: (e) => { chain[i] = e.target.value; } }, chainOpts(cid)),
        h('button', { class: 'btn sm', type: 'button', onclick: () => { chain.splice(i, 1); drawChain(); } }, '移除'))),
      chain.length < 4 ? h('button', { class: 'btn sm', type: 'button', onclick: () => { const o = chainOpts(''); chain.push(o.length ? o[0].value : ''); drawChain(); } }, '+ 增加一跳（链式出口）') : null,
      chain.length ? h('div', { class: 'hint' }, '流量路径：入口 → 出口 → ' + chain.map((_, i) => `第 ${i + 2} 跳`).join(' → ') + ' → 目标。') : null,
    ] : null);
  };
  exit.addEventListener('change', () => { if (exit.value === '0') chain = []; drawChain(); });
  drawChain();
  const info = h('div', { class: 'conninfo' });
  const updateInfo = () => {
    const g = R.groups.find((x) => String(x.id) === exit.value);
    info.textContent = g ? `协议: ${protoName(g.protocol)} / 延迟优化: 开启（预建连接 + 并发抢连）` : '协议: 直连（不经过出口，没有隧道） / 延迟优化: 不适用';
  };
  exit.addEventListener('change', updateInfo); entry.addEventListener('change', () => setTimeout(updateInfo, 0));
  updateInfo();
  const hint = h('div', { class: 'hint' });
  const updateHint = () => { const g = entryGroups.find((x) => String(x.id) === entry.value); hint.textContent = g ? `可用端口范围 ${g.port_range}，留空则随机分配` : ''; };
  entry.addEventListener('change', () => { updateHint(); fillExit(exit.value); });
  const listen = h('input', { type: 'number', min: 1, max: 65535, value: r ? r.listen_port : '', placeholder: '留空则随机' });
  const targets = h('textarea', { style: 'min-height:90px', class: 'mono', placeholder: '一行一个：地址:端口\n例如：\n1.2.3.4:443\nexample.com:8443\n[2001:db8::1]:443' });
  targets.value = r ? (r.targets && r.targets.length ? r.targets.join('\n') : `${r.target_host}:${r.target_port}`) : '';
  const lb = h('select', { value: r ? r.lb_mode : 'random' }, lbOptions());
  const isAdm = state.me.role === 'admin';
  const group = h('input', { type: 'text', value: r ? r.group_name : '', maxlength: 64, placeholder: '可选，用于归类，例如 香港' });
  const remark = h('input', { type: 'text', value: r ? r.remark : '', maxlength: 255, placeholder: '可选' });
  const num = (v) => h('input', { type: 'number', min: 0, max: 1000000, value: v || 0 });
  const speed = num(r && r.speed_limit), ipl = num(r && r.ip_limit), connl = num(r && r.conn_limit);
  const tip = (text) => h('span', { class: 'qm', title: text, tabindex: 0 }, '?');
  const lab = (text, tp) => h('label', null, text, tp ? [' ', tip(tp)] : null);
  const adv = h('details', { class: 'adv' }, h('summary', null, '高级选项'),
    h('div', { class: 'field' }, lab('负载均衡策略', '填了多个目标时才有用。随机 / 轮询 / IP Hash（同一客户端 IP 固定到同一目标）/ 最小连接数 / 故障转移（按行顺序，前面的可用就一直用前面的）。任何方式下，连不上的目标都会自动换下一个。'), lb),
    h('div', { class: 'field' }, lab('规则限速', '0 表示不限速。本条规则的限速和用户本身的限速同时生效，取较小的那个。'), h('div', { class: 'row-inline' }, speed, h('span', { class: 'muted small' }, 'Mbps'))),
    h('div', { class: 'field' }, lab('IP 限制', '0 表示不限。本条规则同时最多允许多少个不同的客户端 IP 连接。'), ipl),
    h('div', { class: 'field' }, lab('连接数限制', '0 表示不限。本条规则同时最多允许多少个连接。'), connl),
    field('分组', group), field('备注', remark));
  if ((r && (r.speed_limit || r.ip_limit || r.conn_limit || r.group_name || r.remark || r.lb_mode !== 'random'))) adv.open = true;
  updateHint();
  modal(editing ? '编辑规则 (#' + r.id + ')' : '添加规则', [
    field('名称', name),
    h('div', { class: 'field' }, h('label', null, '入口'), entry, hint),
    field('出口', exit, '选出口设备组：入口到出口之间走隧道，由出口去连目标。'),
    h('div', { class: 'field' }, chainBox),
    h('div', { class: 'field' }, h('label', null, '连接信息'), info),
    field('监听端口', listen),
    field('目标地址', targets, '填多个目标时按负载均衡策略分配（在下面“高级选项”里改）。'),
    adv,
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      const body = {
        name: name.value.trim(), entry_group_id: Number(entry.value), exit_group_id: Number(exit.value) || 0, exit_chain: chain.filter(Boolean).join(','), listen_port: Number(listen.value) || 0,
        targets: targets.value.split('\n').map((x) => x.trim()).filter(Boolean), lb_mode: lb.value,
        group_name: group.value.trim(), remark: remark.value.trim(), protocol: editing ? (r.protocol || 'both') : 'both',
        speed_limit: Number(speed.value) || 0, ip_limit: Number(ipl.value) || 0, conn_limit: Number(connl.value) || 0,
      };
      if (isAdm) body.user_id = editing ? (r.user_id || 0) : (R.uid || state.me.id); // 谁创建就是谁的；管理员在某个用户的规则页里添加时归该用户
      try {
        const res = editing ? await api('PUT', '/rules/' + r.id, body) : await api('POST', '/rules', body);
        toast(editing ? '已保存' : `已创建，监听端口 ${res.listen_port}`); m.close(); done();
      } catch (e) { fail(e); }
    } }, editing ? '保存' : '确定'),
  ], true);
}

// 规则的可编辑字段（复制、高级编辑共用）
function ruleBody(r) {
  const b = {
    name: r.name, entry_group_id: r.entry_group_id, exit_group_id: r.exit_group_id || 0, exit_chain: r.exit_chain || '', listen_port: r.listen_port,
    targets: (r.targets && r.targets.length ? r.targets : [`${r.target_host}:${r.target_port}`]).slice(),
    lb_mode: r.lb_mode || 'random', protocol: r.protocol || 'tcp', group_name: r.group_name || '', remark: r.remark || '',
    speed_limit: r.speed_limit || 0, conn_limit: r.conn_limit || 0, ip_limit: r.ip_limit || 0,
  };
  if (state.me && state.me.role === 'admin') b.user_id = r.user_id || 0;
  return b;
}

// 高级编辑：直接改规则的 JSON（对应 ny 的"高级编辑"）。dest 是 targets 的别名。
function ruleAdvDialog(r, done) {
  const cur = ruleBody(r); delete cur.user_id;
  const keys = Object.keys(cur).concat(['dest']);
  const ta = h('textarea', { class: 'mono', style: 'min-height:300px' });
  ta.value = JSON.stringify(cur, null, 2);
  modal(`${r.name} (#${r.id}) 高级编辑`, [
    h('p', { class: 'muted small' }, '直接编辑 JSON，只需保留要修改的字段。可用字段：' + keys.join('、') + '。dest 等同于 targets（目标地址数组）；protocol：tcp / udp / both；限制类 0 = 不限。'),
    ta,
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      let o;
      try { o = JSON.parse(ta.value); if (!o || typeof o !== 'object' || Array.isArray(o)) throw new Error(); } catch { return fail(new Error('不是合法的 JSON 对象')); }
      const body = ruleBody(r);
      for (const k of Object.keys(o)) {
        if (!keys.includes(k)) return fail(new Error('不支持的字段：' + k));
        body[k === 'dest' ? 'targets' : k] = o[k];
      }
      if (typeof body.targets === 'string') body.targets = [body.targets];
      try { await api('PUT', '/rules/' + r.id, body); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '确定'),
  ], true);
}

async function diagnoseDialog(r) {
  const out = h('div', null, h('p', { class: 'muted' }, '正在让节点测试，最多等 45 秒…'));
  modal(`诊断：${r.name} (#${r.id})`, out, (m) => [h('button', { class: 'btn', onclick: m.close }, '关闭')], true);
  try {
    const res = await api('POST', `/rules/${r.id}/diagnose`);
    const ms = (v) => h('span', { class: 'muted small' }, `  ${v} ms`);
    const nodeBlock = (n) => h('div', { class: 'diag-node' },
      h('div', null, h('b', null, n.node), ' ', n.done ? (n.result.running ? h('span', { class: 'chip ok' }, '规则运行中 · ' + (n.result.via || '')) : h('span', { class: 'chip bad' }, '规则未运行')) : h('span', { class: 'chip bad' }, '45 秒内没有回复')),
      !n.done ? h('div', { class: 'muted small' }, '节点没回话：可能节点程序太旧（到“节点状态”页看版本并升级）、节点到目标的网络非常慢，或节点刚好掉线。') : null,
      n.done && n.result.error ? h('div', { class: 'small', style: 'color:var(--danger)' }, n.result.error) : null,
      n.done && n.result.note ? h('div', { class: 'muted small' }, n.result.note) : null,
      n.done ? (n.result.targets || []).map((t) => {
        const smp = t.samples || [];
        const ee = smp.length ? Math.min(...smp.map((x) => (x.pooled || x.mux ? x.hs : x.tcp))) : 0; // 入口→出口一个来回
        const row = (k, v, hot) => h('div', { style: 'display:flex;gap:10px;padding:2px 0' }, h('span', { class: 'muted', style: 'min-width:92px' }, k), h('b', { style: hot ? 'color:var(--danger)' : '' }, v));
        return h('div', { style: 'margin:8px 0 4px' },
          h('div', { class: 'result-line' }, h('span', { class: 'chip ' + (t.ok ? 'ok' : 'bad') }, t.ok ? '可达' : '不通'), h('span', { class: 'mono' }, t.target)),
          t.split && t.ok ? h('div', { style: 'margin:4px 0 0 4px' },
            row('入口 → 出口', `${ee} ms`), row('出口 → 目标', `${t.exit_ms || 0} ms`), row('合计（新连接）', `${t.ms} ms`),
            smp.length > 1 ? h('details', { class: 'muted small', style: 'margin-top:4px' }, h('summary', { style: 'cursor:pointer' }, `连测 ${smp.length} 次明细`),
              smp.map((s, i) => h('div', null, `第 ${i + 1} 次：合计 ${s.total} ms ＝ ` + (s.pooled ? '预建连接' : s.mux ? `复用会话 ${s.layer} ms` : `TCP ${s.tcp} ms + 加密握手 ${s.layer} ms`) + ` + 认证往返 ${s.hs} ms + 出口连目标 ${s.exit} ms`)),
              smp.some((s) => !s.pooled && !s.mux) ? h('div', null, '注：没标"预建连接"的是冷启动，会比后面几次慢；实际使用时大多走预建连接。') : null) : null)
            : (t.ok ? h('div', { style: 'margin:4px 0 0 4px' }, row(n.result.via === '经出口' ? '全链路' : '入口 → 目标', `${t.ms} ms`)) : null),
          !t.ok && t.error ? h('div', { class: 'small', style: 'color:var(--danger)' }, (t.stage === 'target' ? '出口连不上目标：' : '') + t.error) : null);
      }) : null);
    const sec = (title, ...kids) => h('div', { style: 'margin-bottom:14px' }, h('div', { style: 'font-weight:600;margin-bottom:6px' }, title), ...kids);
    const none = h('div', { class: 'muted small' }, '无数据');
    const exitRows = [];
    res.nodes.forEach((n) => { if (n.done) (n.result.exits || []).forEach((e) => exitRows.push(h('div', { class: 'result-line' }, h('span', { class: 'chip ' + (e.ok ? 'ok' : 'bad') }, e.ok ? '可达' : '不通'), h('span', { class: 'mono' }, e.endpoint), e.ok ? h('span', { class: 'muted small' }, `  入口 → 出口 TCP 连接 ${e.ms} ms` + (e.ms >= 500 ? '（偏高：这次连接可能遇到丢包重传，线路不稳）' : '')) : h('div', { class: 'small', style: 'color:var(--danger)' }, e.error)))); });
    const exitNodeRows = (res.exit_nodes || []).map((n) => h('div', { class: 'diag-node', style: 'margin-top:6px' },
      h('div', null, h('b', null, '出口节点自检：' + n.node), ' ', n.done ? null : h('span', { class: 'chip bad' }, '45 秒内没有回复（节点程序可能太旧，请升级节点）')),
      n.done ? (n.result.exits || []).map((e) => h('div', { class: 'result-line' }, h('span', { class: 'chip ' + (e.ok ? 'ok' : 'bad') }, e.ok ? '本机在监听' : '没在监听'), h('span', { class: 'mono' }, e.endpoint), e.ok ? null : h('div', { class: 'small', style: 'color:var(--danger)' }, e.error))) : null,
      n.done ? (n.result.targets || []).map((t) => h('div', { class: 'result-line' }, h('span', { class: 'chip ' + (t.ok ? 'ok' : 'bad') }, t.ok ? '出口 → 目标 可达' : '出口 → 目标 不通'), h('span', { class: 'mono' }, t.target), t.ok ? h('span', { class: 'muted small' }, `  ${t.ms} ms`) : h('div', { class: 'small', style: 'color:var(--danger)' }, t.error))) : null));
    const fb = res.feedback || {};
    fill(out,
      sec(`入口诊断 (Inbound)`, h('div', { class: 'muted small', style: 'margin-bottom:4px' }, `${res.entry ? res.entry.name : ''}　GID: ${res.entry ? res.entry.gid : ''}`), res.nodes.length ? res.nodes.map(nodeBlock) : none),
      sec(`出口诊断 (Outbounds)`, (res.exit_groups || []).length ? res.exit_groups.map((g, i) => h('div', { style: 'margin-bottom:6px' },
        h('div', { class: 'muted small', style: 'margin-bottom:4px' }, `${g.name}　GID: ${g.gid}`), i === 0 && exitRows.length ? exitRows : none, i === 0 ? exitNodeRows : null)) : h('div', { class: 'muted small' }, '直连，没有出口')),
      sec('面板反馈 (Backend)', h('pre', { class: 'mono small', style: 'margin:0;white-space:pre-wrap' }, `发出任务 ${fb.sent || 0}\n发出失败 ${fb.send_failed || 0}\n回收任务 ${fb.received || 0}`)));
  } catch (e) { fill(out, h('p', { style: 'color:var(--danger)' }, e.message)); }
}

async function trafficDialog(r) {
  const out = h('div', null, h('p', { class: 'muted' }, '加载中…'));
  modal(`流量：${r.name} (#${r.id})`, out, (m) => [h('button', { class: 'btn', onclick: m.close }, '关闭')], true);
  try {
    const rows = await api('GET', `/rules/${r.id}/traffic`);
    if (!rows.length) return fill(out, h('p', { class: 'muted' }, '最近 30 天没有流量记录'));
    const max = Math.max(...rows.map((x) => x.in + x.out), 1);
    fill(out, h('p', { class: 'muted small' }, '最近 30 天，每天的原始流量（未乘倍率）'),
      h('div', { class: 'daybars' }, rows.map((x) => h('div', { class: 'daybar', title: `${x.day}  ↑ ${fmtBytes(x.in)}  ↓ ${fmtBytes(x.out)}` }, h('div', { style: `height:${Math.max(2, (x.in + x.out) / max * 100)}%` }), h('span', null, x.day.slice(5))))),
      h('div', { class: 'table-wrap flat', style: 'margin-top:12px' }, h('table', null, h('thead', null, h('tr', null, ['日期', '上行', '下行', '合计'].map((t) => h('th', null, t)))),
        h('tbody', null, [...rows].reverse().map((x) => h('tr', null, h('td', null, x.day), h('td', null, fmtBytes(x.in)), h('td', null, fmtBytes(x.out)), h('td', null, fmtBytes(x.in + x.out))))))));
  } catch (e) { fill(out, h('p', { style: 'color:var(--danger)' }, e.message)); }
}

function importDialog(entryGroups, groupNames, done) {
  if (!entryGroups.length) return fail(new Error('请先创建入口设备组'));
  const entry = h('select', null, entryGroups.map((g) => h('option', { value: String(g.id) }, groupOptionLabel(g))));
  const gl = h('datalist', { id: 'gn-list' }, groupNames.map((n) => h('option', { value: n })));
  const group = h('input', { type: 'text', list: 'gn-list', maxlength: 64, placeholder: '可选，导入的规则统一放进这个分组' });
  const exit = h('select', null, exitOptions());
  const lb = h('select', null, lbOptions());
  const text = h('textarea', { placeholder: '一行一条，支持四种写法：\n④ {"dest":["1.2.3.4:443"],"listen_port":20001,"name":"香港"}   （一行一个 JSON，和 nyanpass 导出的一样）\n① 目标地址|目标端口|监听端口 #备注#\n② 名称#监听端口#目标地址#目标端口     （和 nyanpass 的批量格式一样，监听端口可留空）\n③ 名称#监听端口#地址:端口,地址:端口   （多个目标）\n\n例如：\n1.2.3.4|443|20001 #香港#\n日本#20002#5.6.7.8#443\n负载#20003#1.1.1.1:443,2.2.2.2:443\n\n监听端口可省略（自动分配）；以 // 开头的行会被忽略。\n\n也可以直接粘贴"导出 JSON"得到的内容（带全部设置，listen_port 为 0 表示自动分配）。' });
  const result = h('div');
  const adv = h('textarea', { class: 'mono', style: 'min-height:70px', placeholder: '可选。一个 JSON 对象，里面的设置会套用到每一条导入的规则（规则行里自己写了的以规则行为准）。\n例：{"lb_mode":"round","speed_limit":0,"conn_limit":0,"protocol":"tcp"}' });
  const advBox = h('details', { class: 'advbox' }, h('summary', null, 'JSON 设置'), adv);
  modal('批量导入规则', [field('入口', entry), field('出口', exit), field('负载均衡（多目标时生效）', lb), gl, field('分组', group), field('规则列表', text), advBox, result], (m) => [
    h('button', { class: 'btn', onclick: () => { m.close(); done(); } }, '关闭'),
    h('button', { class: 'btn primary', onclick: async (e) => {
      e.target.disabled = true;
      try {
        const tv = text.value.trim();
        let defs = {};
        if (adv.value.trim()) { try { defs = JSON.parse(adv.value); } catch (_) { throw new Error('"JSON 设置"不是合法的 JSON'); } }
        let jr = null;
        if (tv[0] === '[' || tv[0] === '{') {
          try { jr = [].concat(JSON.parse(tv)); } catch (_) { // 整段不是一个 JSON：当作"一行一个 JSON"
            jr = tv.split('\n').map((x) => x.trim()).filter((x) => x && !x.startsWith('//')).map((x, i) => { try { return JSON.parse(x); } catch (_) { throw new Error(`第 ${i + 1} 条不是合法的 JSON：${x.slice(0, 40)}`); } });
          }
          jr = jr.map((x) => Object.assign({}, defs, x));
        }
        const r = jr ? await api('POST', '/rules/import_json', { rules: jr, entry_group_id: Number(entry.value), exit_group_id: Number(exit.value) || null }) : await api('POST', '/rules/import', { entry_group_id: Number(entry.value), exit_group_id: Number(exit.value) || 0, lb_mode: lb.value, group_name: group.value.trim(), text: text.value });
        fill(result, h('p', null, `成功 ${r.ok_count} 条，失败 ${r.fail_count} 条`),
          ...r.results.filter((x) => !x.ok).map((x) => h('div', { class: 'result-line err' }, `第 ${x.line} 行：${x.error}  （${x.text}）`)));
        if (r.ok_count) toast(`已导入 ${r.ok_count} 条`);
      } catch (err) { fail(err); } finally { e.target.disabled = false; }
    } }, '导入'),
  ], true);
}

async function exportDialog(ids, list) {
  let q = '';
  if (ids.length) q = '?ids=' + ids.join(',');
  else if (R.gid) q = '?entry_group_id=' + encodeURIComponent(R.gid);
  let txt = '';
  try { txt = await api('GET', '/rules/export' + q, undefined, true); } catch (e) { return fail(e); }
  const box = h('textarea', { readonly: true, style: 'min-height:220px', class: 'mono' });
  box.value = txt;
  modal('导出规则', [h('p', { class: 'muted small' }, `共 ${txt.split('\n').filter(Boolean).length} 条。格式与"批量导入"相同，可直接粘贴到另一个面板导入。`), box], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '关闭'),
    h('button', { class: 'btn', onclick: () => {
      const a = h('a', { href: URL.createObjectURL(new Blob([txt], { type: 'text/plain' })), download: 'rules.txt' });
      document.body.append(a); a.click(); a.remove();
    } }, '下载'),
    h('button', { class: 'btn', onclick: async () => {
      try { const j = JSON.stringify(await api('GET', '/rules/export_json' + q), null, 2); txt = j; box.value = j; } catch (e) { fail(e); }
    } }, '改为 JSON（含全部设置）'),
    h('button', { class: 'btn primary', onclick: () => { box.select(); copyText(txt, box); } }, '复制'),
  ], true);
}

function setGroupDialog(groupNames, onOk) {
  const gl = h('datalist', { id: 'gn-list2' }, groupNames.map((n) => h('option', { value: n })));
  const input = h('input', { type: 'text', list: 'gn-list2', maxlength: 64, placeholder: '分组名；留空表示移出分组' });
  modal('设置分组', [gl, field('分组名', input)], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: () => { m.close(); onOk(input.value.trim()); } }, '确定'),
  ]);
}

// ------------------------------------------------------------ 规则：管理分组 / 批量切换 / 统计
async function ruleGroupsDialog(done) {
  let rows;
  try { rows = await api('GET', '/rules/groups' + (R.uid ? '?uid=' + R.uid : '')); } catch (e) { return fail(e); }
  const named = rows.filter((x) => x.name);
  const un = rows.find((x) => !x.name);
  const body = h('div', null,
    named.length ? named.map((g) => h('div', { class: 'row-inline' },
      h('span', { class: 'chip' }, g.name), h('span', { class: 'muted small' }, g.count + ' 条规则'), h('span', { class: 'grow' }),
      h('button', { class: 'btn sm', onclick: () => {
        const input = h('input', { type: 'text', value: g.name, maxlength: 64, placeholder: '新名称；留空 = 取消该分组' });
        modal('重命名分组「' + g.name + '」', [field('新名称', input, '改成已有分组的名字就是合并两个分组；留空则这些规则变为未分组。')], (m2) => [
          h('button', { class: 'btn', onclick: m2.close }, '取消'),
          h('button', { class: 'btn primary', onclick: async () => { try { await api('POST', '/rules/groups/rename', { from: g.name, to: input.value.trim(), uid: R.uid || 0 }); toast('已修改'); m2.close(); document.querySelector('dialog[open]')?.close(); done(); } catch (e) { fail(e); } } }, '确定')]);
      } }, '重命名 / 合并'),
      h('button', { class: 'btn sm danger', onclick: () => confirmBox('取消分组', `把分组「${g.name}」下的 ${g.count} 条规则移出分组？规则本身不会被删除。`, async () => {
        try { await api('POST', '/rules/groups/rename', { from: g.name, to: '', uid: R.uid || 0 }); toast('已取消该分组'); document.querySelector('dialog[open]')?.close(); done(); } catch (e) { fail(e); }
      }) }, '取消分组'))) : h('p', { class: 'muted' }, '还没有分组。在规则列表里勾选规则，点“设置分组”即可创建。'),
    un ? h('p', { class: 'muted small' }, `未分组：${un.count} 条`) : null);
  modal('管理分组', body, (m) => [h('button', { class: 'btn', onclick: m.close }, '关闭')], true);
}

function switchDialog(ids, entryGroups, done) {
  const chEntry = h('input', { type: 'checkbox' });
  const chExit = h('input', { type: 'checkbox' });
  const entry = h('select', null, entryGroups.map((g) => h('option', { value: String(g.id) }, g.name)));
  const exit = h('select', null);
  const refreshExit = () => fill(exit, exitOptions(entryGroups.find((x) => String(x.id) === entry.value)));
  refreshExit(); entry.addEventListener('change', refreshExit);
  modal(`批量切换（${ids.length} 条规则）`, [
    h('p', { class: 'muted small', style: 'margin-top:0' }, '勾选要修改的项；每条规则会逐一校验（端口范围、权限、直连策略），失败的会列出原因，成功的立即生效。监听端口保持不变。'),
    h('div', { class: 'field' }, h('label', { class: 'check' }, chEntry, ' 切换入口设备组'), entry),
    h('div', { class: 'field' }, h('label', { class: 'check' }, chExit, ' 切换出口（链式后续跳会被清空）'), exit),
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      if (!chEntry.checked && !chExit.checked) return fail(new Error('请至少勾选一项'));
      try {
        const r = await api('POST', '/rules/batch_switch', { ids, change_entry: chEntry.checked, entry_group_id: Number(entry.value), change_exit: chExit.checked, exit_group_id: Number(exit.value) || 0, exit_chain: '' });
        m.close(); R.selected.clear();
        if (r.fails.length) modal('部分规则切换失败', [h('p', null, `成功 ${r.ok_count} 条，失败 ${r.fails.length} 条：`), r.fails.map((f) => h('div', { class: 'small' }, h('b', null, f.name || '#' + f.id), '：', f.error))], (m2) => [h('button', { class: 'btn primary', onclick: m2.close }, '知道了')], true);
        else toast(`已切换 ${r.ok_count} 条规则`);
        done();
      } catch (e) { fail(e); }
    } }, '确定'),
  ]);
}

async function statsDialog() {
  const out = h('div', null, h('p', { class: 'muted' }, '加载中…'));
  modal('统计数据', out, (m) => [h('button', { class: 'btn', onclick: m.close }, '关闭')], true);
  try {
    const d = await api('GET', '/my/stats');
    const max = Math.max(1, ...d.days.map((x) => x.in + x.out));
    const tot = d.days.reduce((a, x) => a + x.in + x.out, 0);
    fill(out,
      h('p', null, '最近 30 天合计 ', h('b', null, fmtBytes(tot))),
      d.days.length ? h('div', { class: 'bars' }, d.days.map((x) => h('div', { class: 'bar-col', title: `${x.day}  ↑${fmtBytes(x.in)}  ↓${fmtBytes(x.out)}` },
        h('div', { class: 'bar-fill', style: `height:${Math.max(2, (x.in + x.out) / max * 100)}%` }), h('div', { class: 'bar-lab' }, x.day.slice(5))))) : h('p', { class: 'muted' }, '最近 30 天没有流量记录'),
      h('h3', { style: 'margin:16px 0 6px' }, '规则累计流量 Top 10'),
      d.top.length ? h('div', { class: 'table-wrap flat' }, h('table', null, h('thead', null, h('tr', null, ['规则', '上行', '下行'].map((t) => h('th', null, t)))),
        h('tbody', null, d.top.map((x) => h('tr', null, h('td', null, x.name), h('td', null, fmtBytes(x.in)), h('td', null, fmtBytes(x.out))))))) : h('p', { class: 'muted' }, '暂无'));
  } catch (e) { fill(out, h('p', { style: 'color:var(--danger)' }, e.message)); }
}

reg('dashboard', '仪表盘', pageDashboard, 'admin');
reg('rules', '转发规则', pageRules, 'admin');
reg('groups', '设备组', pageGroups, 'admin');
reg('rules', '我的规则', pageRules, 'user');

// 给 app-ext.js 用的公共工具
window.FW = { h, fill, api, toast, fail, fmtBytes, fmtTime, ago, modal, confirmBox, copyText, field, state, autoRefresh, reg, showApp, PAGES, showJoinCommand };

// ------------------------------------------------------------ 启动
async function boot() {
  try { state.site = await api('GET', '/site'); } catch { /* 忽略 */ }
  if (!store.token) return showLogin();
  try { state.me = await api('GET', '/me'); } catch { return showLogin(); }
  showApp();
}
document.addEventListener('DOMContentLoaded', boot);
})();
