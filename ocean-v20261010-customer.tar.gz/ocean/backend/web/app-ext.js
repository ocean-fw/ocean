// v0.4 新增页面：用户前台（概览 / 商店 / 订单）和管理员的用户、套餐、兑换码、订单、公告、设置。
// 公共工具来自 app.js 暴露的 window.FW。
(() => {
'use strict';
const { h, fill, api, toast, fail, fmtBytes, fmtTime, modal, confirmBox, copyText, field, state, autoRefresh, reg } = window.FW;

const yuan = (c) => '¥' + ((Number(c) || 0) / 100).toFixed(2);
const lim = (n, unit) => (n ? n + (unit || '') : '不限');
const dayStr = (iso) => { if (!iso) return ''; const d = new Date(iso); const p = (x) => String(x).padStart(2, '0'); return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`; };
const REASON = { disabled: '已封禁', expired: '已过期', quota: '流量用尽' };

function dataTable(heads, rows, empty) {
  return rows.length
    ? h('div', { class: 'table-wrap' }, h('table', null, h('thead', null, h('tr', null, heads.map((t) => h('th', null, t)))), h('tbody', null, rows)))
    : h('div', { class: 'card empty' }, empty);
}
function usage(used, limit) {
  const pct = limit ? Math.min(100, used / limit * 100) : 0;
  return h('div', { class: 'usage' }, h('div', { class: 'meter' }, h('div', { class: 'bar' + (pct >= 100 ? ' hot' : pct > 80 ? ' warm' : ''), style: `width:${limit ? pct : 0}%` }), h('span', null, `${fmtBytes(used)} / ${limit ? fmtBytes(limit) : '不限'}`)));
}
const num = (label, hint, value, attrs) => field(label, h('input', { type: 'number', min: '0', step: 'any', value, ...attrs }), hint);

// ============================================================ 用户前台
async function tgBindDialog(done) {
  let r;
  try { r = await api('POST', '/me/tg/code'); } catch (e) { return fail(e); }
  const cmd = `/bind ${r.code}`;
  const box = h('div', { class: 'cmd mono' }, cmd);
  modal('关联 Telegram', [
    h('p', null, '1. 在 Telegram 里打开机器人 ', h('b', null, '@' + r.bot), '（点“开始”）'),
    h('p', null, '2. 给它发送下面这条消息（10 分钟内有效）：'), box,
    h('p', { class: 'muted small' }, '发送成功后机器人会回复“绑定成功”。然后点下面的“我已绑定”刷新。'),
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '关闭'),
    h('button', { class: 'btn', onclick: () => copyText(cmd, box) }, '复制'),
    h('button', { class: 'btn primary', onclick: async () => { m.close(); done(); } }, '我已绑定'),
  ], true);
}

async function pageOverview(main) {
  const draw = async () => {
    const me = await api('GET', '/me');
    state.me = me; state.refreshWho && state.refreshWho();
    const row = (k, v) => h('div', { class: 'kv' }, h('span', { class: 'muted' }, k), h('span', null, v));
    const inviteLink = `${location.origin}/?invite=${me.invite_code}`;
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '个人中心')),
      me.blocked ? h('div', { class: 'banner bad' }, me.blocked_msg, ' ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); state.render('store'); } }, '去商店')) : null,
      h('div', { class: 'grid2' },
        h('div', { class: 'card' }, h('h2', null, '我的账号'),
          row('套餐', me.plan_name ? h('b', null, me.plan_name) : h('span', { class: 'muted' }, '未开通')),
          row('状态', me.blocked ? h('span', { class: 'chip bad' }, REASON[me.blocked]) : h('span', { class: 'chip ok' }, '正常')),
          row('到期时间', me.expire_at ? fmtTime(me.expire_at) : '永久'),
          row('用户组', me.group_name || '—'),
          (state.site && state.site.balance_off) ? null : row('余额', yuan(me.balance)),
          me.plan_id ? row('续费价格', h('span', null, yuan(me.renew_price), ' ', h('button', { class: 'btn sm', onclick: () => confirmBox('立即续费', `用当前套餐「${me.plan_name}」续费，扣除 ${yuan(me.renew_price)}（当前余额 ${yuan(me.balance)}），到期时间顺延，流量清零。确定吗？`, async () => {
            try { state.me = await api('POST', '/me/renew'); state.refreshWho && state.refreshWho(); toast('续费成功'); draw(); } catch (e) { fail(e); }
          }) }, '立即续费'))) : null,
          me.plan_id ? row('自动续费', h('label', { class: 'check' }, h('input', { type: 'checkbox', checked: me.auto_renew, onchange: async (e) => {
            try { state.me = await api('POST', '/me/auto_renew', { enabled: e.target.checked }); toast(e.target.checked ? '已开启自动续费' : '已关闭自动续费'); draw(); } catch (err) { e.target.checked = !e.target.checked; fail(err); }
          } }), ' 临近到期或流量用完时自动用余额续费')) : null),
        h('div', { class: 'card' }, h('h2', null, '用量与限制'),
          h('div', { class: 'kv' }, h('span', { class: 'muted' }, '流量'), usage(me.traffic_used, me.traffic_limit)),
          row('规则数量', `${me.rule_count} / ${lim(me.rule_limit)}`),
          row('单规则限速', lim(me.speed_limit, ' Mbps')),
          row('单规则连接数', lim(me.conn_limit)),
          row('单规则来源 IP 数', lim(me.ip_limit)))),
      h('div', { class: 'card' }, h('h2', null, '邀请好友'),
        h('p', { class: 'muted small', style: 'margin-top:0' }, '好友通过你的链接注册后，你会获得站点设置的邀请奖励（如果开启）。'),
        h('div', { class: 'cmd mono' }, inviteLink),
        h('div', { style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: () => copyText(inviteLink, document.querySelector('.cmd')) }, '复制邀请链接'))),
      h('div', { class: 'card' }, h('h2', null, 'Telegram 与推送'),
        h('div', { class: 'kv' }, h('span', { class: 'muted' }, 'Telegram 关联'), me.tg_bound
          ? h('span', null, h('span', { class: 'chip ok' }, '已关联'), ' ', h('button', { class: 'btn sm danger', onclick: async () => { try { await api('POST', '/me/tg/unbind'); toast('已取消关联'); draw(); } catch (e) { fail(e); } } }, '取消关联'))
          : h('span', null, h('span', { class: 'chip' }, '未关联'), ' ', h('button', { class: 'btn sm', onclick: () => tgBindDialog(draw) }, '关联'))),
        me.tg_bound ? h('div', { class: 'kv' }, h('span', { class: 'muted' }, '推送信息'), h('span', null, ...[['expire', '套餐即将到期'], ['traffic', '流量用尽'], ['renew', '自动续费结果']].map(([k, t]) =>
          h('label', { class: 'check', style: 'margin-right:14px' }, h('input', { type: 'checkbox', checked: (me.push_opts || '').split(',').includes(k), onchange: async (e) => {
            const cur = new Set((state.me.push_opts || '').split(',').filter(Boolean)); e.target.checked ? cur.add(k) : cur.delete(k);
            try { await api('POST', '/me/push', { opts: [...cur] }); state.me.push_opts = [...cur].join(','); toast('已保存'); } catch (err) { e.target.checked = !e.target.checked; fail(err); }
          } }), ' ' + t)))) : h('p', { class: 'muted small', style: 'margin:6px 0 0' }, '关联 Telegram 后，可以收到套餐到期、流量用尽、自动续费结果的提醒，也可以在机器人里发 /me 查看用量。')));
  };
  await draw();
  autoRefresh(draw, 30000);
}

// 主页：欢迎 + 面板版本 + 站点公告（和 ny 一样放在第一个）
// 诊断信息折叠块：出问题时把这里的内容复制给站长 / 客服，一眼能看出版本、开关、时间对不对
function diag(title, obj) {
  const text = JSON.stringify(obj, null, 2);
  const pre = h('pre', { class: 'mono', style: 'margin:8px 0;white-space:pre-wrap;word-break:break-all' }, text);
  return h('details', { class: 'card', style: 'margin-top:12px' }, h('summary', { style: 'cursor:pointer;font-weight:600' }, title), pre,
    h('button', { class: 'btn sm', onclick: () => copyText(text, pre.parentNode) }, '复制'));
}

async function pageHome(main) {
  const draw = async () => {
    const [anns, site] = await Promise.all([api('GET', '/announcements'), api('GET', '/site')]);
    fill(main,
      h('div', { class: 'card' }, h('h2', null, '欢迎使用'),
        h('div', { class: 'kv' }, h('span', { class: 'muted' }, '面板'), h('span', null, (site.site_name || 'ocean'))),
        h('div', { class: 'kv' }, h('span', { class: 'muted' }, '面板版本'), h('span', null, 'v' + (site.version || ''))),
        h('div', { class: 'kv' }, h('span', { class: 'muted' }, '节点程序最新版本'), h('span', null, 'v' + (site.agent_version || '')))),
      h('div', { class: 'card' }, h('h2', null, '站点公告'),
        anns.length ? anns.map((a) => h('div', { class: 'ann' }, h('div', null, a.pinned ? h('span', { class: 'chip warn' }, '置顶') : null, h('b', null, a.title), h('span', { class: 'muted small', style: 'margin-left:8px' }, fmtTime(a.created_at))), h('div', { class: 'ann-body' }, a.content))) : h('div', { class: 'muted' }, '暂无公告')),
      diag('站点信息', { title: site.site_name, allow_register: site.allow_register, invite_required: site.invite_required, allow_single_tunnel: site.allow_user_exit, allow_looking_glass: site.allow_lg, captcha: site.captcha }),
      diag('后端信息', { version: site.version, agent_version: site.agent_version, time: site.time }));
  };
  await draw();
  autoRefresh(draw, 30000);
}

async function pageStore(main) {
  const draw = async () => {
    const [plans, me, site, pay] = await Promise.all([api('GET', '/store/plans'), api('GET', '/me'), api('GET', '/site'), api('GET', '/pay/methods')]);
    state.me = me; state.site = site; state.refreshWho && state.refreshWho();
    const code = h('input', { type: 'text', placeholder: 'XXXX-XXXX-XXXX-XXXX', style: 'max-width:300px' });
    const buy = (p) => confirmBox('购买套餐', `购买「${p.name}」，价格 ${yuan(p.price)}，当前余额 ${yuan(me.balance)}。${me.plan_id === p.id ? '你正在使用这个套餐，购买会在到期时间上顺延。' : '购买后会立即切换到该套餐的限制，并且流量清零。'}确定吗？`, async () => {
      try { state.me = await api('POST', '/store/buy', { plan_id: p.id }); state.refreshWho(); toast('购买成功'); draw(); } catch (e) { fail(e); }
    });
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '商店'), h('span', { class: 'chip' }, '余额 ' + yuan(me.balance))),
      site.topup_notice ? h('div', { class: 'banner' }, site.topup_notice) : null,
      payCard(pay, draw),
      plans.length ? h('div', { class: 'plans' }, plans.map((p) => h('div', { class: 'plan-card' + (me.plan_id === p.id ? ' current' : '') },
        h('div', { class: 'plan-name' }, p.name, me.plan_id === p.id ? h('span', { class: 'chip ok', style: 'margin-left:6px' }, '当前') : null),
        h('div', { class: 'plan-price' }, yuan(p.price), h('span', { class: 'muted small' }, p.duration_days ? ` / ${p.duration_days} 天` : ' / 永久')),
        h('ul', null,
          h('li', null, '流量 ' + (p.traffic_limit ? fmtBytes(p.traffic_limit) : '不限')),
          h('li', null, '规则 ' + lim(p.rule_limit) + ' 条'),
          h('li', null, '限速 ' + lim(p.speed_limit, ' Mbps')),
          h('li', null, '连接数 ' + lim(p.conn_limit)),
          h('li', null, '来源 IP ' + lim(p.ip_limit))),
        p.remark ? h('div', { class: 'muted small' }, p.remark) : null,
        h('button', { class: 'btn primary', style: 'width:100%;margin-top:10px', disabled: me.balance < p.price, onclick: () => buy(p) }, me.balance < p.price ? '余额不足' : (me.plan_id === p.id ? '续费' : '购买'))))) : h('div', { class: 'card empty' }, '管理员还没有上架套餐'),
      h('div', { class: 'card', style: 'margin-top:16px' }, h('h2', null, '兑换码管理'),
        h('p', { class: 'muted small', style: 'margin-top:0' }, '兑换码可以充值余额，或直接开通套餐。'),
        h('div', { class: 'toolbar' }, code, h('button', { class: 'btn primary', onclick: async (e) => {
          if (!code.value.trim()) return toast('请输入兑换码', true);
          e.target.disabled = true;
          try { const r = await api('POST', '/redeem', { code: code.value.trim() }); state.me = r.me; state.refreshWho(); toast(r.message); draw(); } catch (err) { fail(err); } finally { e.target.disabled = false; }
        } }, '兑换'))));
  };
  await draw();
}

const PAY_LABEL = { alipay: '支付宝', wxpay: '微信支付', qqpay: 'QQ 钱包', usdt: 'USDT', bank: '银行卡' };
function payCard(pay, redraw) {
  if (!pay.enabled) return null;
  const amount = h('input', { type: 'number', min: '0', step: '0.01', value: '100', style: 'max-width:140px' });
  const type = h('select', null, pay.types.map((t) => h('option', { value: t }, PAY_LABEL[t] || t)));
  return h('div', { class: 'card', style: 'margin-bottom:16px' }, h('h2', null, '在线充值'),
    h('p', { class: 'muted small', style: 'margin-top:0' }, `最小充值 ${pay.min} 元。点“去支付”会打开支付页面，付款成功后余额会自动到账（几秒到一分钟）。`),
    h('div', { class: 'toolbar' }, amount, type,
      h('button', { class: 'btn primary', onclick: async (e) => {
        e.target.disabled = true;
        try {
          const r = await api('POST', '/pay/create', { amount: Number(amount.value), type: type.value });
          window.open(r.url, '_blank', 'noopener');
          toast('已打开支付页面，付款后点“刷新余额”');
        } catch (err) { fail(err); } finally { e.target.disabled = false; }
      } }, '去支付'),
      h('button', { class: 'btn', onclick: () => redraw().catch(fail) }, '刷新余额')));
}

// 用户端：邀请记录
async function pageInvites(main) {
  const d = await api('GET', '/my/invites');
  const link = `${location.origin}/?invite=${d.code}`;
  const rule = [d.reward_fixed ? `好友注册成功奖励 ${yuan(d.reward_fixed)}` : null, d.percent ? `好友${d.recurring ? '每次' : '首次'}购买套餐，你获得 ${d.percent}% 返佣` : null].filter(Boolean).join('；') || '站点暂未设置邀请奖励';
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '邀请记录')),
    h('div', { class: 'card' }, h('h2', null, '我的邀请链接'), h('div', { class: 'cmd mono' }, link),
      h('div', { style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: () => copyText(link, document.querySelector('.cmd')) }, '复制邀请链接')),
      h('p', { class: 'muted small' }, rule + (d.enabled ? '' : '（站点目前未开放注册）'))),
    h('div', { class: 'grid2' },
      h('div', { class: 'card' }, h('h2', null, '已邀请 ' + d.count + ' 人'), dataTable(['用户', '注册时间'], d.list.map((u) => h('tr', null, h('td', null, u.username), h('td', { class: 'nowrap' }, fmtTime(u.created_at)))), '还没有人通过你的链接注册')),
      h('div', { class: 'card' }, h('h2', null, '奖励记录（累计 ' + yuan(d.reward) + '）'), dataTable(['时间', '说明', '金额'], d.orders.map((o) => h('tr', null, h('td', { class: 'nowrap' }, fmtTime(o.created_at)), h('td', null, o.title), h('td', { class: 'pos' }, '+' + yuan(o.amount)))), '还没有奖励'))));
}

// 管理员：邀请记录
async function pageInviteLog(main) {
  const rows = await api('GET', '/orders?type=invite');
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '邀请记录'), h('span', { class: 'muted' }, '最近 500 条奖励 / 返佣')),
    dataTable(['时间', '获得奖励的用户', '说明', '金额'], rows.map((o) => h('tr', null, h('td', { class: 'nowrap' }, fmtTime(o.created_at)), h('td', null, o.username || '（已删除）'), h('td', null, o.title), h('td', { class: 'pos' }, '+' + yuan(o.amount)))), '还没有邀请奖励记录'));
}

async function pageMyOrders(main) {
  const rows = await api('GET', '/my/orders');
  const TYPE = { plan: '套餐', redeem: '兑换', admin: '管理员', invite: '邀请', pay: '在线充值' };
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '订单与流水')),
    dataTable(['时间', '类型', '说明', '金额', '余额'], rows.map((o) => h('tr', null,
      h('td', { class: 'nowrap' }, fmtTime(o.created_at)), h('td', null, h('span', { class: 'chip' }, TYPE[o.type] || o.type)), h('td', null, o.title),
      h('td', { class: o.amount < 0 ? '' : 'pos' }, (o.amount > 0 ? '+' : '') + yuan(o.amount)), h('td', { class: 'muted' }, yuan(o.balance_after)))), '还没有记录'));
}

// ============================================================ 管理员：用户
const USER_COLS = [
  { k: 'id', t: 'UID', r: (u) => u.id, s: (u) => u.id },
  { k: 'user', t: '用户', r: (u) => h('div', null, h('div', null, u.username, u.role === 'admin' ? h('span', { class: 'chip warn', style: 'margin-left:6px' }, '管理员') : null), u.remark ? h('div', { class: 'muted small' }, u.remark) : null), s: (u) => u.username },
  { k: 'group', t: '用户组', r: (u) => u.group_name || h('span', { class: 'muted' }, '—'), s: (u) => u.group_name || '' },
  { k: 'plan', t: '套餐', r: (u) => u.plan_name || h('span', { class: 'muted' }, '—'), s: (u) => u.plan_name || '' },
  { k: 'expire', t: '到期', cls: 'nowrap', r: (u) => (u.expire_at ? fmtTime(u.expire_at).slice(0, 10) : '永久'), s: (u) => (u.expire_at ? Date.parse(u.expire_at) : Infinity) },
  { k: 'traffic', t: '流量', r: (u) => usage(u.traffic_used, u.traffic_limit), s: (u) => u.traffic_used },
  { k: 'rules', t: '规则', r: (u) => u.rule_count + (u.rule_limit ? ' / ' + u.rule_limit : ''), s: (u) => u.rule_count },
  { k: 'limits', t: '限制（单规则）', cls: 'small nowrap', r: (u) => `${lim(u.speed_limit, 'M')} · ${lim(u.conn_limit)}连接 · ${lim(u.ip_limit)}IP`, s: (u) => u.speed_limit },
  { k: 'balance', t: '余额', r: (u) => yuan(u.balance), s: (u) => u.balance },
  { k: 'created', t: '注册时间', cls: 'nowrap', r: (u) => fmtTime(u.created_at).slice(0, 10), s: (u) => Date.parse(u.created_at) },
  { k: 'status', t: '状态', r: (u) => (u.blocked ? h('span', { class: 'chip bad' }, REASON[u.blocked]) : h('span', { class: 'chip ok' }, '正常')), s: (u) => u.blocked || '' },
];
const USER_COLS_DEFAULT = ['id', 'user', 'group', 'plan', 'expire', 'traffic', 'rules', 'limits', 'balance', 'status'];
async function pageUsers(main) {
  let q = '', page = 0;
  let view = { cols: USER_COLS_DEFAULT.slice(), sort: 'id', dir: 'asc', size: 20 };
  try { const v = JSON.parse(localStorage.getItem('fw_users_view') || 'null'); if (v && Array.isArray(v.cols)) view = { ...view, ...v, cols: v.cols.filter((k) => USER_COLS.some((c) => c.k === k)) }; } catch (e) { /* 读不到就用默认 */ }
  const saveView = () => { try { localStorage.setItem('fw_users_view', JSON.stringify(view)); } catch (e) { /* 忽略 */ } };
  const colsDialog = () => {
    const boxes = USER_COLS.map((c) => h('label', { class: 'check', style: 'display:block;margin:4px 0' }, h('input', { type: 'checkbox', value: c.k, checked: view.cols.includes(c.k) }), ' ' + c.t));
    modal('显示哪些列', boxes, (m) => [h('button', { class: 'btn', onclick: m.close }, '取消'), h('button', { class: 'btn primary', onclick: () => {
      const ks = boxes.map((b) => b.querySelector('input')).filter((i) => i.checked).map((i) => i.value);
      if (!ks.length) return toast('至少选一列');
      view.cols = ks; saveView(); m.close(); draw();
    } }, '确定')]);
  };
  const load = async () => {
    const [users, ugs] = await Promise.all([api('GET', '/users'), api('GET', '/user_groups')]);
    return { users, ugs };
  };
  const draw = async () => {
    const { users, ugs } = await load();
    const list = users.filter((u) => !q || (u.username + ' ' + (u.remark || '') + ' ' + (u.group_name || '')).toLowerCase().includes(q.toLowerCase()));
    const cols = USER_COLS.filter((c) => view.cols.includes(c.k));
    const sc = USER_COLS.find((c) => c.k === view.sort) || USER_COLS[0];
    list.sort((x, y) => { const a = sc.s(x), b = sc.s(y); const r = typeof a === 'string' ? a.localeCompare(b) : a - b; return view.dir === 'desc' ? -r : r; });
    const size = view.size || 0, pages = size ? Math.max(1, Math.ceil(list.length / size)) : 1;
    if (page >= pages) page = pages - 1;
    const shown = size ? list.slice(page * size, page * size + size) : list;
    const actionsCell = (u) => h('td', { class: 'actions' },
        [
          h('button', { class: 'btn sm', onclick: () => userDialog(u, ugs, draw) }, '编辑'),
          h('button', { class: 'btn sm', onclick: () => window.open('/?affect=' + u.id + '#rules', '_blank') }, '管理规则 (' + u.rule_count + ')'),
          h('button', { class: 'btn sm', onclick: () => topupDialog(u, draw) }, '充值'),
          h('button', { class: 'btn sm', onclick: () => confirmBox('重置流量', `把「${u.username}」的已用流量清零？`, async () => { try { await api('POST', `/users/${u.id}/reset_traffic`); toast('已清零'); draw(); } catch (e) { fail(e); } }) }, '清流量'),
          u.id === state.me.id ? null : (u.role === 'admin'
            ? h('button', { class: 'btn sm', onclick: () => confirmBox('取消管理员', `取消「${u.username}」的管理员身份？他会变成普通用户并被踢下线。`, async () => { try { await api('POST', `/users/${u.id}/role`, { role: 'user' }); toast('已取消'); draw(); } catch (e) { fail(e); } }) }, '取消管理员')
            : h('button', { class: 'btn sm', onclick: () => confirmBox('设为管理员', `把「${u.username}」设为管理员？他将拥有和你几乎相同的全部权限（含用户、节点、设置），并被踢下线重新登录。`, async () => { try { await api('POST', `/users/${u.id}/role`, { role: 'admin' }); toast('已设为管理员'); draw(); } catch (e) { fail(e); } }) }, '设为管理员')),
          u.id === state.me.id ? null : h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除用户', `删除「${u.username}」会同时删除他的 ${u.rule_count} 条规则、流量记录和登录状态。确定吗？`, async () => { try { await api('DELETE', '/users/' + u.id); toast('已删除'); draw(); } catch (e) { fail(e); } }, true) }, '删除')]);
    const rows = shown.map((u) => h('tr', null, ...cols.map((c) => h('td', c.cls ? { class: c.cls } : null, c.r(u))), actionsCell(u)));
    const heads = [...cols.map((c) => h('span', { class: 'sortable', style: 'cursor:pointer;user-select:none', onclick: () => { if (view.sort === c.k) view.dir = view.dir === 'asc' ? 'desc' : 'asc'; else { view.sort = c.k; view.dir = 'asc'; } saveView(); draw(); } }, c.t + (view.sort === c.k ? (view.dir === 'asc' ? ' ▲' : ' ▼') : ''))), '操作'];
    const pager = h('div', { class: 'toolbar' }, h('span', { class: 'muted small' }, `第 ${page + 1} / ${pages} 页，共 ${list.length} 个`),
      h('button', { class: 'btn sm', disabled: page <= 0, onclick: () => { page--; draw(); } }, '上一页'), h('button', { class: 'btn sm', disabled: page >= pages - 1, onclick: () => { page++; draw(); } }, '下一页'),
      h('span', { class: 'grow' }), h('span', { class: 'muted small' }, '每页'),
      h('select', { onchange: (e) => { view.size = Number(e.target.value); page = 0; saveView(); draw(); } }, [10, 20, 50, 100, 0].map((n) => h('option', { value: String(n), selected: view.size === n }, n ? String(n) : '全部'))));
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '用户管理'), h('span', { class: 'muted' }, `共 ${users.length} 个`)),
      h('div', { class: 'toolbar' }, h('button', { class: 'btn primary', onclick: () => userDialog(null, ugs, draw) }, '添加用户'), h('button', { class: 'btn', onclick: () => draw().catch(fail) }, '刷新'), h('button', { class: 'btn', onclick: colsDialog }, '显示列'),
        h('button', { class: 'btn', onclick: () => cleanup('用户', '/users/cleanup', { days: 30 }, '过期超过 30 天、余额为 0 的用户（连同他们的规则）', draw) }, '清理无效用户'),
        h('button', { class: 'btn', onclick: () => cleanup('规则', '/rules/cleanup', {}, '所属用户或设备组已不存在的规则', draw) }, '清理无效规则'), h('span', { class: 'grow' }),
        h('input', { type: 'text', id: 'user-q', placeholder: '搜索 用户名/备注/用户组', value: q, oninput: (e) => { q = e.target.value; page = 0; draw().then(() => { const el = document.getElementById('user-q'); el.focus(); el.setSelectionRange(q.length, q.length); }); } })),
      dataTable(heads, rows, '没有用户'), pager);
  };
  await draw();
  autoRefresh(draw, 15000);
}

async function cleanup(label, path, body, what, done) {
  try {
    const pre = await api('POST', path, { ...body, dry_run: true });
    if (!pre.count) return toast('没有需要清理的' + label);
    const names = pre.names ? '：' + pre.names.slice(0, 10).join('、') + (pre.names.length > 10 ? ' 等' : '') : '';
    confirmBox('清理无效' + label, `将删除 ${pre.count} 个${label}（${what}）${names}。这个操作不能撤销，确定吗？`, async () => {
      try { const r = await api('POST', path, body); toast(`已清理 ${r.count} 个${label}`); done(); } catch (e) { fail(e); }
    }, true);
  } catch (e) { fail(e); }
}

// 显示（一次性）生成的密码
function pwShown(username, password) {
  const box = h('div', { class: 'cmd mono' }, password);
  modal('密码已生成', [h('p', null, `用户「${username}」的新密码（只显示这一次，请马上复制发给他）：`), box,
    h('div', { style: 'margin-top:8px' }, h('button', { class: 'btn sm', onclick: () => copyText(password, box.parentNode) }, '复制'))], (m) => [h('button', { class: 'btn primary', onclick: m.close }, '好的')]);
}

function userDialog(u, ugs, done) {
  const editing = !!u;
  const name = h('input', { type: 'text', value: u ? u.username : '', disabled: editing, maxlength: 32, autocomplete: 'off' });
  const pw = h('input', { type: 'password', autocomplete: 'new-password', placeholder: editing ? '留空表示不修改' : '留空 = 随机生成（创建后显示）' });
  const enabled = h('select', { value: u && !u.enabled ? '0' : '1' }, h('option', { value: '1' }, '启用'), h('option', { value: '0' }, '封禁'));
  const group = h('select', { value: u && u.group_id ? String(u.group_id) : '0' }, h('option', { value: '0' }, '无用户组'), ugs.map((g) => h('option', { value: String(g.id) }, g.name)));
  const expire = h('input', { type: 'date', value: u ? dayStr(u.expire_at) : '' });
  const traffic = h('input', { type: 'number', min: '0', step: 'any', value: u ? +(u.traffic_limit / 2 ** 30).toFixed(3) : 0 });
  const speed = h('input', { type: 'number', min: '0', value: u ? u.speed_limit : 0 });
  const rl = h('input', { type: 'number', min: '0', value: u ? u.rule_limit : 0 });
  const ipl = h('input', { type: 'number', min: '0', value: u ? u.ip_limit : 0 });
  const cl = h('input', { type: 'number', min: '0', value: u ? u.conn_limit : 0 });
  const used = h('input', { type: 'number', min: '0', step: 'any', value: u ? +(u.traffic_used / 2 ** 30).toFixed(3) : 0 });
  const bal = h('input', { type: 'number', step: '0.01', value: u ? (u.balance / 100).toFixed(2) : '0.00' });
  const remark = h('input', { type: 'text', value: u ? u.remark : '', maxlength: 255 });
  modal(editing ? `编辑用户：${u.username}` : '添加用户', [
    field('用户名', name, editing ? '用户名不能修改' : '3-32 位字母、数字或 _ . @ -'), field(editing ? '重置密码' : '密码', pw, editing ? '想要随机密码：点下面的“随机重置密码”。' : '至少 8 位；留空则自动生成一个随机密码。'),
    h('div', { class: 'row3' }, field('状态', enabled), field('用户组', group), field('到期日', expire, '留空 = 永不过期')),
    h('div', { class: 'row3' }, field('流量额度 GB', traffic, '0 = 不限'), field('限速 Mbps', speed, '每条规则，0 = 不限'), field('规则数量上限', rl, '0 = 不限')),
    h('div', { class: 'row3' }, field('连接数上限', cl, '每条规则，0 = 不限'), field('来源 IP 数上限', ipl, '每条规则，0 = 不限'), h('div')),
    h('div', { class: 'row3' }, field('已用流量 GB', used, '可直接修改'), field('余额（元）', bal, '修改会记一笔“管理员修改余额”流水'), h('div')),
    field('备注', remark),
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    editing ? h('button', { class: 'btn', onclick: () => confirmBox('随机重置密码', `给「${u.username}」生成一个随机新密码？旧密码立即失效，他会被踢下线。`, async () => {
      try { const r = await api('PUT', '/users/' + u.id, { gen_password: true }); m.close(); done(); pwShown(u.username, r.password); } catch (e) { fail(e); }
    }) }, '随机重置密码') : null,
    h('button', { class: 'btn primary', onclick: async () => {
      const body = { enabled: enabled.value === '1', group_id: Number(group.value) || 0, expire_at: expire.value, traffic_gb: Number(traffic.value) || 0,
        speed_limit: Number(speed.value) || 0, rule_limit: Number(rl.value) || 0, ip_limit: Number(ipl.value) || 0, conn_limit: Number(cl.value) || 0, remark: remark.value.trim(), traffic_used_gb: Number(used.value) || 0, balance_yuan: Number(bal.value) || 0 };
      if (pw.value) body.password = pw.value;
      try {
        let r;
        if (editing) r = await api('PUT', '/users/' + u.id, body);
        else r = await api('POST', '/users', { ...body, username: name.value.trim() });
        toast('已保存'); m.close(); done();
        if (r && r.password) pwShown(editing ? u.username : name.value.trim(), r.password);
      } catch (e) { fail(e); }
    } }, editing ? '保存' : '创建'),
  ], true);
}

function topupDialog(u, done) {
  const amount = h('input', { type: 'number', step: '0.01', placeholder: '金额（元），负数表示扣除' });
  const remark = h('input', { type: 'text', maxlength: 100, placeholder: '备注（会出现在用户的流水里）' });
  modal(`给「${u.username}」充值`, [h('p', { class: 'muted' }, '当前余额 ' + yuan(u.balance)), field('金额（元）', amount), field('备注', remark)], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      try { await api('POST', `/users/${u.id}/topup`, { amount: Number(amount.value), remark: remark.value.trim() }); toast('已入账'); m.close(); done(); } catch (e) { fail(e); }
    } }, '确定'),
  ]);
}

// ============================================================ 管理员：用户组
async function pageUserGroups(main) {
  const draw = async () => {
    const gs = await api('GET', '/user_groups');
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '用户组管理'), h('button', { class: 'btn primary', onclick: () => ugDialog(null, draw) }, '添加用户组')),
      h('p', { class: 'muted small', style: 'margin-top:-6px' }, '用户组决定用户能用哪些设备组：在"设备组"的编辑里勾选"可用用户组"。套餐可以设置"购买后移入的用户组"，这样买了高级套餐的用户自动看到高级线路。'),
      dataTable(['ID', '名称', '备注', '用户数', '操作'], gs.map((g) => h('tr', null, h('td', null, g.id), h('td', null, g.name), h('td', { class: 'muted' }, g.remark), h('td', null, g.user_count),
        h('td', { class: 'actions' }, h('button', { class: 'btn sm', onclick: () => ugDialog(g, draw) }, '编辑'),
          h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除用户组', `删除「${g.name}」？`, async () => { try { await api('DELETE', '/user_groups/' + g.id); toast('已删除'); draw(); } catch (e) { fail(e); } }, true) }, '删除')))), '还没有用户组'));
  };
  await draw();
}
function ugDialog(g, done) {
  const name = h('input', { type: 'text', value: g ? g.name : '', maxlength: 64 });
  const remark = h('input', { type: 'text', value: g ? g.remark : '', maxlength: 255 });
  modal(g ? '编辑用户组' : '添加用户组', [field('名称', name), field('备注', remark)], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      try { const body = { name: name.value.trim(), remark: remark.value.trim() }; g ? await api('PUT', '/user_groups/' + g.id, body) : await api('POST', '/user_groups', body); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '保存'),
  ]);
}

// ============================================================ 管理员：套餐
async function pagePlans(main) {
  const draw = async () => {
    const [ps, ugs] = await Promise.all([api('GET', '/plans'), api('GET', '/user_groups')]);
    const gn = Object.fromEntries(ugs.map((g) => [g.id, g.name]));
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '套餐管理'), h('button', { class: 'btn primary', onclick: () => planDialog(null, ugs, draw) }, '添加套餐')),
      dataTable(['排序', '名称', '价格', '时长', '流量', '规则', '限速', '连接 / IP', '购买后用户组', '上架', '操作'], ps.map((p) => h('tr', null,
        h('td', null, p.sort), h('td', null, h('div', null, p.name), p.remark ? h('div', { class: 'muted small' }, p.remark) : null), h('td', null, yuan(p.price)),
        h('td', null, p.duration_days ? p.duration_days + ' 天' : '永久'), h('td', null, p.traffic_limit ? fmtBytes(p.traffic_limit) : '不限'), h('td', null, lim(p.rule_limit)), h('td', null, lim(p.speed_limit, ' Mbps')),
        h('td', { class: 'small' }, `${lim(p.conn_limit)} / ${lim(p.ip_limit)}`), h('td', null, p.group_id ? (gn[p.group_id] || '（已删除）') : h('span', { class: 'muted' }, '不变')),
        h('td', null, h('label', { class: 'switch' }, h('input', { type: 'checkbox', checked: p.enabled, onchange: async (e) => {
          try { await api('PUT', '/plans/' + p.id, planBody(p, { enabled: e.target.checked })); } catch (err) { e.target.checked = !e.target.checked; fail(err); }
        } }), h('span'))),
        h('td', { class: 'actions' }, h('button', { class: 'btn sm', onclick: () => planDialog(p, ugs, draw) }, '编辑'),
          h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除套餐', `删除「${p.name}」？已购买的用户不受影响，未使用的套餐兑换码会一并删除。`, async () => { try { await api('DELETE', '/plans/' + p.id); toast('已删除'); draw(); } catch (e) { fail(e); } }, true) }, '删除')))), '还没有套餐。添加套餐后用户才能在商店购买。'));
  };
  await draw();
}
const planBody = (p, over) => ({ name: p.name, remark: p.remark, price: p.price / 100, duration_days: p.duration_days, traffic_gb: +(p.traffic_limit / 2 ** 30).toFixed(3),
  speed_limit: p.speed_limit, rule_limit: p.rule_limit, ip_limit: p.ip_limit, conn_limit: p.conn_limit, group_id: p.group_id || 0, enabled: p.enabled, sort: p.sort, ...over });
function planDialog(p, ugs, done) {
  const v = (k, d) => (p ? p[k] : d);
  const name = h('input', { type: 'text', value: v('name', ''), maxlength: 64 });
  const remark = h('input', { type: 'text', value: v('remark', ''), maxlength: 255, placeholder: '显示在商店卡片上' });
  const price = h('input', { type: 'number', min: '0', step: '0.01', value: p ? p.price / 100 : 0 });
  const days = h('input', { type: 'number', min: '0', value: v('duration_days', 30) });
  const traffic = h('input', { type: 'number', min: '0', step: 'any', value: p ? +(p.traffic_limit / 2 ** 30).toFixed(3) : 100 });
  const speed = h('input', { type: 'number', min: '0', value: v('speed_limit', 0) });
  const rl = h('input', { type: 'number', min: '0', value: v('rule_limit', 10) });
  const cl = h('input', { type: 'number', min: '0', value: v('conn_limit', 0) });
  const ipl = h('input', { type: 'number', min: '0', value: v('ip_limit', 0) });
  const sort = h('input', { type: 'number', value: v('sort', 0) });
  const group = h('select', { value: p && p.group_id ? String(p.group_id) : '0' }, h('option', { value: '0' }, '不变'), ugs.map((g) => h('option', { value: String(g.id) }, g.name)));
  modal(p ? '编辑套餐' : '添加套餐', [
    field('名称', name), field('说明', remark),
    h('div', { class: 'row3' }, field('价格（元）', price, '0 = 免费领取'), field('时长（天）', days, '0 = 永久'), field('流量 GB', traffic, '0 = 不限')),
    h('div', { class: 'row3' }, field('规则数量', rl, '0 = 不限'), field('限速 Mbps', speed, '每条规则，0 = 不限'), field('排序', sort, '小的在前')),
    h('div', { class: 'row3' }, field('连接数上限', cl, '每条规则，0 = 不限'), field('来源 IP 数上限', ipl, '每条规则，0 = 不限'), field('购买后用户组', group, '用来开放高级线路')),
  ], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      const body = { name: name.value.trim(), remark: remark.value.trim(), price: Number(price.value) || 0, duration_days: Number(days.value) || 0, traffic_gb: Number(traffic.value) || 0,
        speed_limit: Number(speed.value) || 0, rule_limit: Number(rl.value) || 0, ip_limit: Number(ipl.value) || 0, conn_limit: Number(cl.value) || 0, group_id: Number(group.value) || 0, sort: Number(sort.value) || 0, enabled: p ? p.enabled : true };
      try { p ? await api('PUT', '/plans/' + p.id, body) : await api('POST', '/plans', body); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '保存'),
  ], true);
}

// ============================================================ 管理员：兑换码
async function pageRedeems(main) {
  const draw = async () => {
    const [rs, ps] = await Promise.all([api('GET', '/redeems'), api('GET', '/plans')]);
    const pn = Object.fromEntries(ps.map((p) => [p.id, p.name]));
    const free = rs.filter((r) => !r.max_uses || r.used < r.max_uses);
    fill(main,
      h('div', { class: 'page-title' }, h('h2', null, '兑换码'), h('button', { class: 'btn primary', onclick: () => genDialog(ps, draw) }, '生成兑换码'),
        h('button', { class: 'btn', disabled: !free.length, onclick: () => showCodes(free, '未用完的兑换码') }, `导出未用完（${free.length}）`)),
      dataTable(['兑换码', '内容', '已用 / 可用', '有效期', '备注', '创建时间', '操作'], rs.map((r) => h('tr', null,
        h('td', { class: 'mono' }, r.code), h('td', null, r.type === 'balance' ? '余额 ' + yuan(r.value) : '套餐：' + (pn[r.plan_id] || '（已删除）')),
        h('td', null, `${r.used} / ${r.max_uses || '不限'}`), h('td', { class: 'small' }, r.expires_at ? fmtTime(r.expires_at).slice(0, 10) : '长期'), h('td', { class: 'muted small' }, r.remark), h('td', { class: 'small muted' }, fmtTime(r.created_at)),
        h('td', { class: 'actions' }, h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除兑换码', `删除 ${r.code}？`, async () => { try { await api('DELETE', '/redeems/' + r.id); draw(); } catch (e) { fail(e); } }, true) }, '删除')))), '还没有兑换码'));
  };
  await draw();
}
function showCodes(list, title) {
  const box = h('textarea', { readonly: true, class: 'mono', style: 'min-height:240px' });
  box.value = list.map((r) => r.code).join('\n');
  modal(title, [h('p', { class: 'muted small' }, `共 ${list.length} 个，一行一个，可直接复制发给买家。`), box], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '关闭'),
    h('button', { class: 'btn primary', onclick: () => { box.select(); copyText(box.value, box); } }, '复制'),
  ], true);
}
function genDialog(ps, done) {
  const type = h('select', { value: 'balance' }, h('option', { value: 'balance' }, '充值余额'), h('option', { value: 'plan' }, '开通套餐'));
  const amount = h('input', { type: 'number', min: '0', step: '0.01', value: 10 });
  const plan = h('select', null, ps.map((p) => h('option', { value: String(p.id) }, `${p.name}（${yuan(p.price)}）`)));
  const count = h('input', { type: 'number', min: '1', max: '500', value: 10 });
  const uses = h('input', { type: 'number', min: '0', value: 1 });
  const exp = h('input', { type: 'date' });
  const remark = h('input', { type: 'text', maxlength: 255, placeholder: '可选，例如 发卡批次' });
  const fa = field('金额（元）', amount), fp = field('套餐', plan, ps.length ? '' : '请先添加套餐');
  const sync = () => { fa.style.display = type.value === 'balance' ? '' : 'none'; fp.style.display = type.value === 'plan' ? '' : 'none'; };
  type.addEventListener('change', sync); sync();
  modal('生成兑换码', [field('类型', type), fa, fp, h('div', { class: 'row3' }, field('数量', count), field('每码可用次数', uses, '0 = 不限；每个用户同一个码只能用一次'), field('有效期至', exp, '留空 = 长期')), field('备注', remark)], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      try {
        const codes = await api('POST', '/redeems', { type: type.value, amount: Number(amount.value), plan_id: Number(plan.value) || 0, count: Number(count.value), max_uses: Number(uses.value), expires_at: exp.value, remark: remark.value.trim() });
        m.close(); await done(); showCodes(codes, `已生成 ${codes.length} 个兑换码`);
      } catch (e) { fail(e); }
    } }, '生成'),
  ], true);
}

// ============================================================ 管理员：订单
async function pageOrders(main) {
  const draw = async () => {
    const rows = await api('GET', '/orders');
    const TYPE = { plan: '套餐', redeem: '兑换', admin: '管理员', invite: '邀请', pay: '在线充值', manual: '手动记账' };
    const sel = new Set();
    const del = h('button', { class: 'btn danger', disabled: true, onclick: () => confirmBox('删除订单记录', `删除选中的 ${sel.size} 条流水记录？只删记录，不会改动用户余额。`, async () => {
      try { await api('POST', '/orders/delete', { ids: [...sel] }); toast('已删除'); draw(); } catch (e) { fail(e); }
    }, true) }, '删除选中');
    const upd = () => { del.disabled = !sel.size; del.textContent = sel.size ? `删除选中(${sel.size})` : '删除选中'; };
    fill(main, h('div', { class: 'page-title' }, h('h2', null, '订单与流水'), h('span', { class: 'muted' }, '最近 500 条'),
      h('button', { class: 'btn primary', onclick: () => manualDialog(draw) }, '手动记账'), del),
      dataTable(['', '时间', '用户', '类型', '说明', '金额', '余额'], rows.map((o) => h('tr', null,
        h('td', null, h('input', { type: 'checkbox', onchange: (e) => { e.target.checked ? sel.add(o.id) : sel.delete(o.id); upd(); } })),
        h('td', { class: 'nowrap' }, fmtTime(o.created_at)), h('td', null, o.username || '（已删除）'), h('td', null, h('span', { class: 'chip' }, TYPE[o.type] || o.type)), h('td', null, o.title),
        h('td', { class: o.amount < 0 ? '' : 'pos' }, (o.amount > 0 ? '+' : '') + yuan(o.amount)), h('td', { class: 'muted' }, yuan(o.balance_after)))), '还没有订单'));
  };
  await draw();
}

async function manualDialog(done) {
  let us;
  try { us = (await api('GET', '/users')).filter((u) => u.role === 'user'); } catch (e) { return fail(e); }
  if (!us.length) return fail(new Error('还没有普通用户'));
  const user = h('select', null, us.map((u) => h('option', { value: String(u.id) }, `${u.username}（余额 ${yuan(u.balance)}）`)));
  const amt = h('input', { type: 'number', step: '0.01', placeholder: '元，负数表示扣减' });
  const title = h('input', { type: 'text', maxlength: 200, placeholder: '例如：线下转账收款 / 退款', value: '手动记账' });
  const credit = h('input', { type: 'checkbox', checked: true });
  modal('手动记账', [field('用户', user), field('金额（元）', amt), field('说明', title),
    h('div', { class: 'field' }, h('label', { class: 'check' }, credit, ' 同时增减用户余额'), h('div', { class: 'hint' }, '不勾选 = 只记一笔流水，不改余额（比如补记一笔已经处理过的线下收款）。'))], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      try { await api('POST', '/orders/manual', { user_id: Number(user.value), amount: Number(amt.value), title: title.value.trim(), credit: credit.checked }); toast('已记账'); m.close(); done(); } catch (e) { fail(e); }
    } }, '确定')]);
}

// ============================================================ 管理员：公告
async function pageAnnouncements(main) {
  const draw = async () => {
    const list = await api('GET', '/announcements');
    fill(main, h('div', { class: 'page-title' }, h('h2', null, '公告'), h('button', { class: 'btn primary', onclick: () => annDialog(null, draw) }, '发布公告')),
      list.length ? list.map((a) => h('div', { class: 'card' },
        h('div', { class: 'ann-head' }, h('div', null, a.pinned ? h('span', { class: 'chip warn' }, '置顶') : null, h('b', null, a.title), h('span', { class: 'muted small', style: 'margin-left:8px' }, fmtTime(a.created_at))),
          h('div', null, h('button', { class: 'btn sm', onclick: () => annDialog(a, draw) }, '编辑'), ' ',
            h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除公告', `删除「${a.title}」？`, async () => { try { await api('DELETE', '/announcements/' + a.id); draw(); } catch (e) { fail(e); } }, true) }, '删除'))),
        h('div', { class: 'ann-body' }, a.content))) : h('div', { class: 'card empty' }, '还没有公告。用户登录后会在"概览"页看到。'));
  };
  await draw();
}
function annDialog(a, done) {
  const title = h('input', { type: 'text', value: a ? a.title : '', maxlength: 128 });
  const content = h('textarea', { style: 'min-height:160px' }); content.value = a ? a.content : '';
  const pinned = h('input', { type: 'checkbox', checked: a ? a.pinned : false });
  modal(a ? '编辑公告' : '发布公告', [field('标题', title), field('内容', content, '纯文本，换行会保留'), h('label', { class: 'check' }, pinned, ' 置顶')], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      const body = { title: title.value.trim(), content: content.value.trim(), pinned: pinned.checked };
      try { a ? await api('PUT', '/announcements/' + a.id, body) : await api('POST', '/announcements', body); toast('已保存'); m.close(); done(); } catch (e) { fail(e); }
    } }, '保存'),
  ], true);
}

// ============================================================ 管理员：系统设置
async function pageSettings(main) {
  const [st, ugs] = await Promise.all([api('GET', '/settings'), api('GET', '/user_groups')]);
  const txt = (k, ph) => h('input', { type: 'text', value: st[k], placeholder: ph || '' });
  const numI = (k) => h('input', { type: 'number', min: '0', value: st[k] });
  const chk = (k, label) => { const i = h('input', { type: 'checkbox', checked: st[k] === '1' }); i.dataset.k = k; return [i, h('span', null, ' ' + label)]; };
  const f = {
    site_name: txt('site_name'), topup_notice: h('textarea', { style: 'min-height:70px', placeholder: '显示在商店页顶部，例如：充值请联系 Telegram @xxx' }),
    invite_percent: numI('invite_percent'), min_topup: h('input', { type: 'number', min: '0', step: '0.01', value: st.min_topup }),
    epay_url: txt('epay_url', 'https://pay.example.com'), epay_pid: txt('epay_pid', '商户 ID'), epay_key: h('input', { type: 'password', value: st.epay_key, placeholder: '商户密钥', autocomplete: 'off' }),
    epay_types: txt('epay_types', 'alipay,wxpay,usdt'),
    invite_reward: h('input', { type: 'number', min: '0', step: '0.01', value: (Number(st.invite_reward) / 100).toString() }),
    default_group_id: h('select', { value: st.default_group_id }, h('option', { value: '0' }, '无'), ugs.map((g) => h('option', { value: String(g.id) }, g.name))),
    trial_days: numI('trial_days'), trial_traffic_gb: numI('trial_traffic_gb'), trial_rule_limit: numI('trial_rule_limit'), trial_speed: numI('trial_speed'),
    user_exit_limit: numI('user_exit_limit'), offline_retention_days: numI('offline_retention_days'), panel_url: h('input', { placeholder: 'https://panel.example.com' }), node_mirrors_global: h('textarea', { rows: 3, placeholder: 'https://raw.githubusercontent.com/你的用户名/仓库/main' }), node_mirrors_cn: h('textarea', { rows: 3, placeholder: 'https://cdn.jsdelivr.net/gh/你的用户名/仓库@main' }), probe_warn_pct: numI('probe_warn_pct'), probe_red_pct: numI('probe_red_pct'), captcha: h('select', { value: st.captcha }, h('option', { value: '0' }, '无'), h('option', { value: 'math' }, '算术题')),
    tg_token: txt('tg_token', '123456:ABC...'), tg_chat: txt('tg_chat', '例如 123456789 或 -100123456789'),
  };
  f.topup_notice.value = st.topup_notice;
  f.panel_url.value = st.panel_url || ''; f.node_mirrors_global.value = st.node_mirrors_global || ''; f.node_mirrors_cn.value = st.node_mirrors_cn || '';
  const checks = { invite_recurring: chk('invite_recurring', '每次购买都返佣（不勾选只返第一次）'), diag_hide_ip: chk('diag_hide_ip', '普通用户的诊断结果隐藏目标 IP'), allow_register: chk('allow_register', '开放注册'), invite_required: chk('invite_required', '注册必须填写邀请码'),
    allow_user_exit: chk('allow_user_exit', '允许用户自带出口（单端隧道）'), allow_lg: chk('allow_lg', '允许普通用户使用 LookingGlass'), allow_terminal: chk('allow_terminal', '允许管理员使用节点网页终端'), geo_lookup: chk('geo_lookup', '节点 IP 前显示国旗（由面板服务器联网查询 IP 所在地）'), tg_bind_invite: chk('tg_bind_invite', '返佣需要被邀请人已绑定 Telegram（防刷）'),
    tg_notify_node: chk('tg_notify_node', '节点离线 / 恢复在线'), tg_notify_group: chk('tg_notify_group', '设备组故障转移 / 恢复'), tg_notify_user: chk('tg_notify_user', '新用户注册 / 用户流量用尽') };
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '站点设置'),
    h('button', { class: 'btn primary', onclick: async () => {
      const body = {};
      for (const [k, el] of Object.entries(f)) body[k] = k === 'invite_reward' ? String(Math.round(Number(el.value) * 100) || 0) : el.value;
      for (const [k, [i]] of Object.entries(checks)) body[k] = i.checked ? '1' : '0';
      body.user_exit_limit = String(Number(f.user_exit_limit.value) || 3);
      { const w = Math.floor(Number(f.probe_warn_pct.value) || 0), r = Math.floor(Number(f.probe_red_pct.value) || 90);
        if (r < 1 || r > 100 || w < 0 || w > 100 || (w > 0 && w >= r)) return fail(new Error('颜色阈值不对：变红 1–100；变黄 0–100 且要小于变红（变黄填 0 = 不用黄色）'));
        body.probe_warn_pct = String(w); body.probe_red_pct = String(r); }
      try { await api('PUT', '/settings', body); state.site = await api('GET', '/site'); toast('已保存'); } catch (e) { fail(e); }
    } }, '保存设置')),
    h('div', { class: 'card' }, h('h2', null, '节点'), field('节点离线保留天数', f.offline_retention_days, '节点离线超过这么多天自动从面板移除；0 = 不自动移除。单个设备组可以在设备组编辑里单独设置。'), h('div', { class: 'row3' }, field('内存 / CPU 变黄的使用率（%）', f.probe_warn_pct, '达到这个值，进度条从绿色变黄色；填 0 = 不用黄色。'), field('内存 / CPU 变红的使用率（%）', f.probe_red_pct, '达到这个值，进度条变红色。默认 90。'))),
    h('div', { class: 'card' }, h('h2', null, '面板对接域名'), h('p', { class: 'muted small', style: 'margin-top:0' }, '节点连接面板用的地址，必须是域名（http:// 或 https:// 开头，可带端口），不能是纯 IP。对接命令里的面板地址就用它；留空则用你当前访问面板的地址（若是 IP 会提示先设置）。'), field('面板对接域名', f.panel_url)),
    h('div', { class: 'card' }, h('h2', null, '节点安装镜像'), h('p', { class: 'muted small', style: 'margin-top:0' }, '境外默认指向你的 GitHub 仓库、境内默认指向阿里云 OSS（上海），不用改；想换成自己的地址就在这里填（每行一个，清空保存则恢复默认）。对接弹窗会生成“境外 / 境内”两条命令，第一个地址失败会自动换下一个。目录里需要有 install.sh、oceand-linux-amd64、oceand-linux-arm64、SHA256SUMS。'), field('境外镜像（每行一个）', f.node_mirrors_global), field('境内镜像（每行一个）', f.node_mirrors_cn)),
    h('div', { class: 'card' }, h('h2', null, '站点'), field('站点名称', f.site_name), field('充值说明', f.topup_notice, '可以同时开放在线支付（见下方），也可以只靠管理员手动充值 / 兑换码，在这里写清楚怎么联系你。')),
    h('div', { class: 'card' }, h('h2', null, '注册与试用'),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.allow_register)), h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.invite_required)),
      field('注册验证码', f.captcha, '开启后注册页要答一道算术题，可挡掉大部分批量注册脚本。'),
      h('div', { class: 'row3' }, field('邀请奖励（元）', f.invite_reward, '被邀请人注册成功后，奖励邀请人'), field('新用户默认用户组', f.default_group_id)),
      h('p', { class: 'muted small' }, '试用：天数填 0 表示不送试用，新用户注册后需要先购买套餐或兑换码才能创建规则。'),
      h('div', { class: 'row3' }, field('试用天数', f.trial_days), field('试用流量 GB', f.trial_traffic_gb), field('试用规则数', f.trial_rule_limit)), field('试用限速 Mbps（0 不限）', f.trial_speed)),
    h('div', { class: 'card' }, h('h2', null, '邀请返佣与诊断'),
      h('div', { class: 'row3' }, field('返佣比例（%）', f.invite_percent, '被邀请人购买套餐时，把消费金额的这个比例奖励给邀请人；0 = 不返佣')),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.invite_recurring)),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.tg_bind_invite)),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.diag_hide_ip))),
    h('div', { class: 'card' }, h('h2', null, '用户功能'),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.allow_user_exit), h('div', { class: 'hint' }, '用户可以在“单端隧道”页添加自己的服务器作为出口，只有他自己能用；不占用你的出口资源。')),
      field('每人最多单端隧道数', f.user_exit_limit),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.geo_lookup), h('div', { class: 'hint' }, '只由面板服务器去查（节点不会联网查），结果记下来，IP 不变就不再查。关掉就不显示国旗。')),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.allow_terminal), h('div', { class: 'hint' }, '管理员在“节点状态”点“终端”，就能在浏览器里直接操作节点服务器（root shell）。每次打开 / 关闭都会记在面板日志里；关掉后任何人都打不开。')),
      h('div', { class: 'field' }, h('label', { class: 'check' }, ...checks.allow_lg), h('div', { class: 'hint' }, '普通用户可以让各设备组的节点 ping / tcping 公网目标（禁止探测内网），有 3 秒频率限制。'))),
    h('div', { class: 'card' }, h('h2', null, '在线支付（易支付 / EPAY 兼容）'),
      h('p', { class: 'muted small', style: 'margin-top:0' }, '填你的易支付网关地址、商户 ID 和密钥，再写开放的支付方式（例如 alipay,wxpay,usdt，必须与网关的 type 一致）。支付结果通知地址是 面板地址/api/v1/pay/notify，面板会自动告诉网关。USDT 请使用支持 USDT 的易支付网关。'),
      h('div', { class: 'row3' }, field('网关地址', f.epay_url), field('商户 ID', f.epay_pid), field('商户密钥', f.epay_key, '保存后不会再显示；不修改请保持原样')),
      h('div', { class: 'row3' }, field('开放的支付方式', f.epay_types), field('最小充值（元）', f.min_topup))),
    h('div', { class: 'card' }, h('h2', null, 'Telegram 通知'),
      h('p', { class: 'muted small', style: 'margin-top:0' }, '用 @BotFather 创建机器人拿到 token，给机器人发一条消息后，用 @userinfobot 之类的方式查到你的 chat id。保存后点"发送测试"。'),
      field('机器人 token', f.tg_token), field('Chat ID', f.tg_chat),
      h('div', { class: 'field' }, h('label', null, '通知哪些事'), ...Object.entries(checks).filter(([k]) => k.startsWith('tg_notify_')).map(([, c]) => h('div', null, h('label', { class: 'check' }, ...c)))),
      h('button', { class: 'btn', onclick: async () => {
        try { await api('PUT', '/settings', { tg_token: f.tg_token.value, tg_chat: f.tg_chat.value }); await api('POST', '/settings/test_notify'); toast('测试消息已发送，请到 Telegram 查看'); } catch (e) { fail(e); }
      } }, '保存并发送测试')));
}

reg('users', '用户管理', pageUsers, 'admin');
reg('usergroups', '用户组', pageUserGroups, 'admin');
reg('plans', '套餐', pagePlans, 'admin');
reg('redeems', '兑换码', pageRedeems, 'admin', (site) => !site.balance_off);
reg('orders', '订单', pageOrders, 'admin', (site) => !site.balance_off);
reg('announcements', '公告', pageAnnouncements, 'admin');
reg('invitelog', '邀请记录', pageInviteLog, 'admin');
reg('settings', '系统设置', pageSettings, 'admin');
// 用户前台（概览放在最前面）
window.FW.PAGES.unshift(['overview', '个人中心', pageOverview, 'user']);
window.FW.PAGES.unshift(['home', '主页', pageHome, 'user']);
window.FW.PAGES.unshift(['profile', '个人中心', pageOverview, 'admin']); // 管理员也要能绑定 Telegram、看邀请链接
window.FW.PAGES.unshift(['home', '主页', pageHome, 'admin']);
reg('store', '商店', pageStore, 'user', (site) => !site.balance_off);
reg('myorders', '订单', pageMyOrders, 'user', (site) => !site.balance_off);
reg('invites', '邀请记录', pageInvites, 'user');
})();
