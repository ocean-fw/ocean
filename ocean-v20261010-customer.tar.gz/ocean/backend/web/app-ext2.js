// v0.5.2 新增页面：单端隧道（用户自带出口）、LookingGlass、推送通知（管理员）。
(() => {
'use strict';
const { h, fill, api, toast, fail, modal, confirmBox, copyText, field, state, autoRefresh, reg, showJoinCommand } = window.FW;
const PROTOS = [['tls_simple', 'tls_simple（TLS 1.3 加密，推荐）'], ['tls_mux', 'tls_mux（TLS 多路复用）'], ['ws', 'ws（明文）'], ['http', 'http（明文）']];

// ============================================================ 单端隧道
async function pageMyExits(main) {
  const draw = async () => {
    const rows = await api('GET', '/my/exits');
    fill(main, h('div', { class: 'page-title' }, h('h2', null, '单端隧道（我的出口）'),
      h('button', { class: 'btn primary', onclick: () => exitDialog(null, draw) }, '添加出口'), h('button', { class: 'btn', onclick: () => draw().catch(fail) }, '刷新')),
      h('p', { class: 'muted small', style: 'margin-top:-6px' }, '把你自己的服务器接进来当出口：在“转发规则”里选它作为出口，流量经入口 → 你的服务器 → 目标。这些出口只有你自己能用。'),
      rows.length ? h('div', { class: 'table-wrap' }, h('table', null,
        h('thead', null, h('tr', null, ['名称', '协议', '隧道端口', '在线设备', '操作'].map((t) => h('th', null, t)))),
        h('tbody', null, rows.map((g) => h('tr', null,
          h('td', null, g.name), h('td', null, h('span', { class: 'chip' }, g.protocol || 'tls_simple')), h('td', { class: 'mono' }, g.tunnel_port),
          h('td', null, g.node_count === 0 ? h('span', { class: 'chip bad' }, '无设备') : h('span', { class: g.online_count ? 'chip ok' : 'chip bad' }, `${g.online_count} / ${g.node_count}`)),
          h('td', { class: 'actions' },
            h('button', { class: 'btn sm primary', onclick: async () => { try { const r = await api('GET', `/my/exits/${g.id}/join_key`); joinDialog(g, r.join_key); } catch (e) { fail(e); } } }, '对接'),
            h('button', { class: 'btn sm', onclick: () => exitDialog(g, draw) }, '编辑'),
            h('button', { class: 'btn sm danger', onclick: () => confirmBox('删除单端隧道', `删除「${g.name}」会同时移除它下面的节点记录。确定吗？`, async () => {
              try { await api('DELETE', '/my/exits/' + g.id); toast('已删除'); draw(); } catch (e) { fail(e); } }, true) }, '删除')))))))
        : h('div', { class: 'card empty' }, '还没有单端隧道。点“添加出口”，再点“对接”，把你的服务器接进来。'));
  };
  await draw();
  autoRefresh(draw, 10000);
}

function exitDialog(g, done) {
  const name = h('input', { type: 'text', maxlength: 64, value: g ? g.name : '' });
  const proto = h('select', { value: g ? (g.protocol === 'tls' ? 'tls_simple' : g.protocol) : 'tls_simple' }, PROTOS.map(([k, t]) => h('option', { value: k }, t)));
  const port = h('input', { type: 'number', min: 1, max: 65535, value: g ? g.tunnel_port : '', placeholder: '留空自动分配' });
  modal(g ? '编辑出口' : '添加出口', [field('名称', name), field('协议', proto, 'tls_simple 加密最安全；ws / http 不加密，只做身份认证。'), field('隧道端口', port, '你的服务器需要放行这个 TCP 端口。')], (m) => [
    h('button', { class: 'btn', onclick: m.close }, '取消'),
    h('button', { class: 'btn primary', onclick: async () => {
      const body = { name: name.value.trim(), protocol: proto.value }; if (port.value) body.tunnel_port = Number(port.value);
      try {
        if (g) { await api('PUT', '/my/exits/' + g.id, body); toast('已保存'); m.close(); done(); }
        else { const r = await api('POST', '/my/exits', body); m.close(); await done(); joinDialog(r.group, r.join_key); }
      } catch (e) { fail(e); }
    } }, g ? '保存' : '创建')]);
}

function joinDialog(g, key) {
  showJoinCommand(g, key, { reset: () => confirmBox('重置对接密钥', `重置「${g.name}」的对接密钥后，旧命令失效；已接入的服务器不受影响。继续吗？`, async () => { try { const r = await api('POST', `/my/exits/${g.id}/rotate_key`); toast('已重置'); joinDialog(g, r.join_key); } catch (e) { fail(e); } }) });
}

// ============================================================ LookingGlass
async function pageLG(main) {
  const rows = await api('GET', '/lg/groups');
  const TL = { entry: '入口', exit: '出口', both: '入口+出口', chain: '链式出口', monitor: '仅监控' };
  fill(main, h('div', { class: 'page-title' }, h('h2', null, 'LookingGlass')),
    h('p', { class: 'muted small', style: 'margin-top:-6px' }, '选一个设备组，让它的节点去 ping / tcping 你指定的目标，看从那个机房出发的网络质量。'),
    rows.length ? h('div', { class: 'table-wrap' }, h('table', null,
      h('thead', null, h('tr', null, ['名称', '类型', '在线设备', '操作'].map((t) => h('th', null, t)))),
      h('tbody', null, rows.map((g) => h('tr', null, h('td', null, g.name), h('td', null, h('span', { class: 'chip' }, TL[g.type] || g.type)),
        h('td', null, h('span', { class: g.online ? 'chip ok' : 'chip bad' }, g.online)),
        h('td', { class: 'actions' }, h('button', { class: 'btn sm primary', disabled: !g.online, onclick: () => lgDialog(g) }, '测试'))))))) : h('div', { class: 'card empty' }, '暂无可用设备组'));
}

function lgDialog(g) {
  const kind = h('select', null, h('option', { value: 'ping' }, 'ping（ICMP）'), h('option', { value: 'tcping' }, 'tcping（TCP 连接耗时）'));
  const host = h('input', { type: 'text', placeholder: '域名或 IP，例如 www.google.com', maxlength: 253 });
  const port = h('input', { type: 'number', min: 1, max: 65535, value: 443 });
  const portF = field('端口（tcping）', port);
  const upd = () => { portF.style.display = kind.value === 'tcping' ? '' : 'none'; }; kind.addEventListener('change', upd); upd();
  const out = h('div', null);
  const btn = h('button', { class: 'btn primary' }, '开始测试');
  btn.onclick = async () => {
    if (!host.value.trim()) return fail(new Error('请填写目标'));
    btn.disabled = true; fill(out, h('p', { class: 'muted' }, '测试中，最多等 25 秒…'));
    try {
      const r = await api('POST', '/lg/run', { group_id: g.id, kind: kind.value, host: host.value.trim(), port: Number(port.value) || 0 });
      fill(out, r.nodes.map((n) => h('div', { class: 'diag-node' },
        h('div', null, h('b', null, n.node), ' ', !n.done ? h('span', { class: 'chip bad' }, '没有响应') : n.result.error ? h('span', { class: 'chip bad' }, '失败') : n.result.ok ? h('span', { class: 'chip ok' }, `平均 ${n.result.avg_ms.toFixed(1)} ms · 丢包 ${n.result.loss}%`) : h('span', { class: 'chip bad' }, `不通 · 丢包 ${n.result.loss}%`),
          n.done && n.result.ip ? h('span', { class: 'muted small mono', style: 'margin-left:8px' }, n.result.ip) : null),
        n.done && n.result.error ? h('div', { class: 'small', style: 'color:var(--danger)' }, n.result.error) : null,
        n.done ? h('pre', { class: 'mono small', style: 'white-space:pre-wrap;margin:6px 0' }, (n.result.lines || []).join('\n')) : null)));
    } catch (e) { fill(out, h('p', { style: 'color:var(--danger)' }, e.message)); } finally { btn.disabled = false; }
  };
  modal(`LookingGlass：${g.name}`, [field('类型', kind), field('目标', host), portF, out], (m) => [h('button', { class: 'btn', onclick: m.close }, '关闭'), btn], true);
}

// ============================================================ 推送通知（管理员）
async function pagePush(main) {
  const [st, groups] = await Promise.all([api('GET', '/settings'), api('GET', '/device_groups')]);
  const tok = h('input', { type: 'text', value: st.tg_token, placeholder: '123456:ABC...' });
  const chat = h('input', { type: 'text', value: st.tg_chat, placeholder: '管理员接收通知的 chat id' });
  const grace = h('input', { type: 'number', min: 1, value: st.node_grace_default });
  const tgn = ['tg_notify_node', 'tg_notify_group', 'tg_notify_user'].map((k, i) => { const c = h('input', { type: 'checkbox', checked: st[k] === '1' }); c.dataset.k = k; return h('label', { class: 'check', style: 'display:block' }, c, ' ' + ['节点上线 / 离线', '设备组故障转移 / 恢复', '新用户注册 / 流量用尽 / 续费'][i]); });
  const gInputs = groups.filter((g) => g.type !== 'monitor' || true).map((g) => {
    const i = h('input', { type: 'number', min: 0, max: 86400, value: g.grace_seconds || 0, style: 'width:120px' });
    return [g, i];
  });
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '推送通知')),
    h('div', { class: 'card' }, h('h2', null, 'Telegram 机器人'),
      h('p', { class: 'muted small', style: 'margin-top:0' }, '用 @BotFather 创建机器人拿到 token。同一个机器人既给管理员推送，也供用户在“概览”页绑定自己的账号（用户给机器人发 /bind 绑定码），之后到期、流量用尽等提醒会私发给用户。面板用长轮询收消息，不需要配置 webhook 或公网 HTTPS。'),
      field('机器人 token', tok), field('管理员 Chat ID', chat, '给机器人发一条消息后，可以用 @userinfobot 查到自己的 chat id。'),
      h('div', { class: 'field' }, h('label', null, '通知管理员哪些事'), tgn),
      h('div', null, h('button', { class: 'btn primary', onclick: async () => {
        const body = { tg_token: tok.value.trim(), tg_chat: chat.value.trim() }; tgn.forEach((l) => { const c = l.querySelector('input'); body[c.dataset.k] = c.checked ? '1' : '0'; });
        try { await api('PUT', '/settings', body); toast('已保存'); } catch (e) { fail(e); } } }, '保存'),
        ' ', h('button', { class: 'btn', onclick: async () => { try { await api('PUT', '/settings', { tg_token: tok.value.trim(), tg_chat: chat.value.trim() }); await api('POST', '/settings/test_notify'); toast('测试消息已发送'); } catch (e) { fail(e); } } }, '保存并发送测试'))),
    h('div', { class: 'card' }, h('h2', null, '设备离线通知'),
      h('div', { class: 'banner' }, h('div', null, '节点掉线后，等“宽限期”过了还没回来才发离线通知，避免重连、重启时刷屏。回来后会发恢复通知。'), h('div', null, '全局默认可以被每个设备组单独覆盖；设备组填 0 表示用全局默认。')),
      field('全局默认宽限期（秒）', grace),
      h('h3', { style: 'margin:14px 0 6px' }, '设备组覆盖'),
      h('div', { class: 'table-wrap flat' }, h('table', null, h('thead', null, h('tr', null, ['设备组', '宽限期（秒，0=全局）'].map((t) => h('th', null, t)))),
        h('tbody', null, gInputs.map(([g, i]) => h('tr', null, h('td', null, g.name), h('td', null, i)))))),
      h('div', { style: 'margin-top:10px' }, h('button', { class: 'btn primary', onclick: async () => {
        try {
          await api('PUT', '/settings', { node_grace_default: String(Number(grace.value) || 30) });
          for (const [g, i] of gInputs) { const v = Number(i.value) || 0; if (v !== (g.grace_seconds || 0)) await api('PUT', '/device_groups/' + g.id, { grace_seconds: v }); }
          toast('已保存');
        } catch (e) { fail(e); } } }, '保存离线通知设置'))));
}

// ============================================================ 线路测试（管理员）：任意设备组 → 任意设备组，不用建规则
async function pageLinkTest(main) {
  const groups = await api('GET', '/device_groups');
  const TYPE = { entry: '入口', exit: '出口', both: '入口/出口', monitor: '监控机', chain: '链式出口' };
  const label = (g) => `${g.name}（${TYPE[g.type] || g.type}${g.owner_user_id ? ' · 用户单端隧道' : ''} · ${g.online_count || 0} 台在线）`;
  const fromSet = new Set(), toSet = new Set();
  const firstEntry = groups.find((g) => g.type === 'entry' || g.type === 'both') || groups[0];
  if (firstEntry) fromSet.add(firstEntry.id);
  groups.forEach((g) => { if (g.id !== (firstEntry && firstEntry.id) && (g.type === 'exit' || g.type === 'both' || g.type === 'chain')) toSet.add(g.id); });
  const pickList = (set) => groups.map((g) => h('label', { class: 'check', style: 'display:block;margin:2px 0' }, h('input', { type: 'checkbox', checked: set.has(g.id), onchange: (e) => { e.target.checked ? set.add(g.id) : set.delete(g.id); } }), ' ' + label(g)));
  const quick = (set, fn) => h('span', { class: 'muted small' }, ' ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); set.clear(); groups.filter(fn).forEach((g) => set.add(g.id)); redrawLists(); } }, '全选'), ' · ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); set.clear(); redrawLists(); } }, '清空'));
  const fromBox = h('div', null), toBox = h('div', null);
  const redrawLists = () => { fill(fromBox, pickList(fromSet)); fill(toBox, pickList(toSet)); };
  redrawLists();
  const method = h('select', null, [['auto', '自动（目标有隧道端口就测隧道端口，没有就 ping）'], ['tunnel', '只测隧道端口（目标要是出口 / 单端隧道）'], ['port', '指定一个 TCP 端口（比如 22、443，测入口 / 监控机用）'], ['ping', 'ICMP ping（目标禁 ping 时不准）']].map(([v, t]) => h('option', { value: v }, t)));
  const port = h('input', { type: 'number', min: 1, max: 65535, value: 22, style: 'max-width:140px' });
  const portF = field('TCP 端口', port); portF.style.display = 'none';
  method.addEventListener('change', () => { portF.style.display = method.value === 'port' ? '' : 'none'; });
  const ipv = h('select', null, [['auto', '自动（有 IPv4 测 IPv4，没有才测 IPv6）'], ['v4', '只测 IPv4'], ['v6', '只测 IPv6'], ['both', 'IPv4 和 IPv6 都测，方便对比']].map(([v, t]) => h('option', { value: v }, t)));
  const out = h('div', null);
  const btn = h('button', { class: 'btn primary' }, '开始测试');
  const cls = (ms) => (ms < 150 ? 'ok' : ms < 300 ? 'warn' : 'bad');
  btn.onclick = async () => {
    if (!fromSet.size) return fail(new Error('请至少选一个测试起点'));
    if (!toSet.size) return fail(new Error('请至少选一个测试目标'));
    btn.disabled = true; fill(out, h('p', { class: 'muted' }, '测试中，最多等 60 秒…'));
    const body = { to_group_ids: [...toSet], ip_version: ipv.value, method: method.value, port: Number(port.value) || 0 };
    try {
      const results = await Promise.all([...fromSet].map(async (gid) => {
        try { return { gid, r: await api('POST', '/linktest', Object.assign({ from_group_id: gid }, body)) }; } catch (e) { return { gid, err: e.message }; }
      }));
      fill(out, results.map(({ gid, r, err }) => {
        const g = groups.find((x) => x.id === gid);
        if (err) return h('div', { class: 'diag-node' }, h('b', null, '起点：' + g.name), h('div', { class: 'small', style: 'color:var(--danger)' }, err));
        return r.nodes.map((n) => h('div', { class: 'diag-node' },
          h('div', null, h('b', null, `起点：${g.name} / ${n.node}`), ' ', !n.done ? h('span', { class: 'chip bad' }, '没有响应（节点程序太旧？先升级节点）') : null),
          n.done ? h('div', { class: 'table-wrap flat' }, h('table', null,
            h('thead', null, h('tr', null, ['目标设备组', '目标节点', 'IP', '地址', '方式', '最低', '每次', '结果'].map((t) => h('th', null, t)))),
            h('tbody', null, (n.result.exits || []).map((e) => h('tr', null,
              h('td', null, e.name), h('td', null, e.node || '—'), h('td', null, e.tag || '—'), h('td', { class: 'mono small' }, e.endpoint),
              h('td', null, e.method === 'ping' ? 'ping' : 'TCP'),
              h('td', null, e.ok ? h('b', { class: 'chip ' + cls(e.ms) }, e.ms + ' ms') : '—'),
              h('td', { class: 'mono small' }, e.method === 'ping' ? (e.ok ? `丢包 ${e.loss || 0}%` : '') : (e.samples || []).join(' / ')),
              h('td', null, e.ok ? (e.ms >= 500 ? h('span', { class: 'chip warn' }, '偏高，线路可能不稳') : h('span', { class: 'chip ok' }, '可达')) : h('div', { class: 'small', style: 'color:var(--danger);max-width:420px' }, '不通：' + e.error))))))) : null));
      }));
    } catch (e) { fill(out, h('p', { style: 'color:var(--danger)' }, e.message)); } finally { btn.disabled = false; }
  };
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '线路测试')),
    h('div', { class: 'card' },
      h('p', { class: 'muted small', style: 'margin-top:0' }, '不用建规则，任意搭配：左边选从哪里测（入口、出口、监控机、用户的单端隧道都行，可多选），右边选测到哪里（所有设备组都能选，可多选）。起点组里每台在线服务器都会去连目标组里的每台服务器，同一台机器不会测自己。'),
      h('div', { class: 'field' }, h('label', null, '测试起点（从这些设备组出发）', quick(fromSet, () => true)), fromBox),
      h('div', { class: 'field' }, h('label', null, '测试目标（连到这些设备组的服务器）', quick(toSet, () => true)), toBox),
      field('测试方式', method, '入口机、监控机本身没有隧道端口：选“指定 TCP 端口”（比如 22 或 443）或 ping，才能测到它们。'), portF,
      field('IP 版本', ipv, '选「只测 IPv6」前，起点和目标服务器都要有可用的 IPv6（节点状态页里能看到各自的 IPv4 / IPv6）。'),
      h('div', null, btn), out));
}

// ============================================================ 运行日志（管理员）：相当于 docker compose logs -f / journalctl -u ocean -f
async function pageLogs(main) {
  let lines = [], last = 0, paused = false;
  const level = h('select', null, [['all', '全部'], ['audit', '操作 / 登录'], ['warn', '警告'], ['error', '错误'], ['info', '一般']].map(([v, t]) => h('option', { value: v }, t)));
  const q = h('input', { type: 'text', placeholder: '搜索关键字（例如 登录失败、节点、规则）', style: 'min-width:240px' });
  const pre = h('div', { class: 'logbox mono' });
  const count = h('span', { class: 'muted small' });
  const pauseBtn = h('button', { class: 'btn', onclick: () => { paused = !paused; pauseBtn.textContent = paused ? '继续刷新' : '暂停刷新'; } }, '暂停刷新');
  const colorOf = { error: 'var(--danger, #d9363e)', warn: 'var(--warn, #d48806)', audit: 'var(--primary, #1668dc)', info: 'inherit' };
  const render = () => {
    const stick = pre.scrollTop + pre.clientHeight >= pre.scrollHeight - 40;
    fill(pre, lines.map((l) => h('div', { class: 'logl' }, h('span', { class: 'muted' }, l.time + '  '), h('span', { style: 'color:' + (colorOf[l.level] || 'inherit') }, l.text))));
    count.textContent = `显示 ${lines.length} 行（面板内存里最多留 3000 行，重启清空；要长期保留用 journalctl -u ocean）`;
    if (stick) pre.scrollTop = pre.scrollHeight;
  };
  const params = () => `level=${encodeURIComponent(level.value)}&q=${encodeURIComponent(q.value.trim())}`;
  const reloadAll = async () => { const r = await api('GET', '/logs?n=800&' + params()); lines = r.lines; last = r.last; render(); pre.scrollTop = pre.scrollHeight; };
  const more = async () => {
    if (paused) return;
    const r = await api('GET', `/logs?after=${last}&n=800&` + params());
    last = r.last;
    if (r.lines.length) { lines = lines.concat(r.lines).slice(-1500); render(); }
  };
  level.addEventListener('change', () => reloadAll().catch(fail));
  q.addEventListener('input', () => { clearTimeout(q._t); q._t = setTimeout(() => reloadAll().catch(fail), 300); });
  fill(main, h('div', { class: 'page-title' }, h('h2', null, '运行日志')),
    h('div', { class: 'card' },
      h('div', { class: 'toolbar', style: 'display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:8px' }, level, q, pauseBtn,
        h('button', { class: 'btn', onclick: () => reloadAll().catch(fail) }, '刷新'),
        h('button', { class: 'btn', onclick: () => { const a = h('a', { href: URL.createObjectURL(new Blob([lines.map((l) => l.time + ' ' + l.text).join('\n')], { type: 'text/plain' })), download: 'ocean-log.txt' }); document.body.append(a); a.click(); a.remove(); } }, '下载'), count),
      pre));
  await reloadAll();
  const t = setInterval(() => { if (!document.body.contains(main)) return clearInterval(t); if (!document.hidden) more().catch(() => {}); }, 2000);
}

reg('myexits', '单端隧道', pageMyExits, 'user', (site) => site.allow_user_exit);
reg('lg', 'LookingGlass', pageLG, 'user', (site) => site.allow_lg);
reg('lg', 'LookingGlass', pageLG, 'admin');
reg('myexits', '单端隧道', pageMyExits, 'admin');
reg('push', '推送通知', pagePush, 'admin');
reg('linktest', '线路测试', pageLinkTest, 'admin');
reg('logs', '运行日志', pageLogs, 'admin');


// ------------------------------------------------------------ 授权（发售版）
async function pageLicense(main) {
  const draw = async () => {
    const v = await api('GET', '/license');
    const ST = { ok: ['ok', '正常'], expired: ['bad', '已到期（面板暂停，转发 48 小时后停止）'], stale: ['warn', '很久没连上授权服务'], locked: ['bad', '已失效（面板和转发都已停止）'], none: ['bad', '未填写授权码'] };
    const [cls, txt] = ST[v.status] || ['', v.status];
    const code = h('input', { type: 'text', placeholder: '粘贴授权码', style: 'max-width:420px' });
    const server = h('input', { type: 'text', placeholder: 'https://授权服务地址', value: v.server || '', style: 'max-width:420px' });
    const fmt = (t) => (t ? fmtTime(new Date(t * 1000).toISOString()) : '—');
    fill(main, h('div', { class: 'page-title' }, h('h2', null, '授权')),
      h('div', { class: 'card', style: 'padding:16px;max-width:760px' },
        h('p', null, '状态：', h('span', { class: 'chip ' + cls }, txt), v.message ? h('span', { class: 'muted', style: 'margin-left:8px' }, v.message) : null),
        h('p', null, '绑定域名：', h('b', null, v.domain || '（未设置面板对接域名）')),
        h('p', null, '授权码：', v.has_code ? h('span', { class: 'mono' }, v.code) : '—', '　套餐：', v.plan || '—'),
        h('p', null, '到期时间：', fmt(v.expire), '　最近校验：', fmt(v.checked_at)),
        h('p', { class: 'muted small' }, `套餐上限：节点 ${v.max_nodes || '不限'} / 规则 ${v.max_rules || '不限'} / 用户 ${v.max_users || '不限'}`),
        v.last_err ? h('p', { style: 'color:var(--danger)' }, '最近一次校验失败：' + v.last_err) : null,
        h('hr'),
        v.bound ? h('p', { class: 'muted' }, v.status === 'ok' ? '授权码已绑定本面板，不能更换。续费请到授权网站，对同一个授权码续费，面板会自动更新到期时间。' : '请到授权网站，对上面这个授权码续费。续费成功后面板会在 1 分钟内自动恢复，也可以点下面的“立即重新校验”。') : field('授权码', code, '开户和续费请在授权网站操作；授权码绑定的域名必须和上面的“绑定域名”一致。填好后不能更换。'),
        v.bound ? null : field('授权服务地址', server, '一般不用改。'),
        h('div', { class: 'toolbar' },
          (v.bound ? null : h('button', { class: 'btn primary', onclick: async () => {
            try { const r = await api('PUT', '/license', { code: code.value.trim(), server: server.value.trim() }); if (r.check_error) toast(r.check_error, true); else toast('校验通过'); draw(); } catch (e) { fail(e); }
          } }, '保存并校验')),
          h('button', { class: 'btn', onclick: async () => {
            try { const r = await api('POST', '/license/check'); if (r.check_error) toast(r.check_error, true); else toast('校验通过'); draw(); } catch (e) { fail(e); }
          } }, '立即重新校验'))));
  };
  await draw();
}
reg('license', '授权', pageLicense, 'admin', (site) => site.license_mode === 'on');
})();
