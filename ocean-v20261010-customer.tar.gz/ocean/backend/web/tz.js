(() => {
'use strict';
// 独立节点状态页：每 2 秒向面板拉一次最新数据（页面隐藏时降到 10 秒）。
// 登录令牌沿用主界面保存的那一份，没登录就跳回主页登录。

function h(tag, attrs, ...kids) {
  const el = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs || {})) {
    if (v === null || v === undefined || v === false) continue;
    if (k === 'class') el.className = v; else if (k.startsWith('on')) el.addEventListener(k.slice(2), v); else el.setAttribute(k, v);
  }
  for (const kid of kids.flat(Infinity)) { if (kid === null || kid === undefined || kid === false) continue; el.append(kid.nodeType ? kid : document.createTextNode(String(kid))); }
  return el;
}
const lsGet = (k) => { try { return localStorage.getItem(k) || ''; } catch { return ''; } };
const lsSet = (k, v) => { try { localStorage.setItem(k, v); } catch { /* 忽略 */ } };

const fmtBytes = (n) => { n = Number(n) || 0; const u = ['B', 'KiB', 'MiB', 'GiB', 'TiB']; let i = 0; while (n >= 1024 && i < 4) { n /= 1024; i++; } return (i ? n.toFixed(n < 10 ? 2 : 1) : n) + ' ' + u[i]; };
const fmtSpeed = (bps) => { let b = (Number(bps) || 0) * 8; const u = ['bps', 'Kbps', 'Mbps', 'Gbps']; let i = 0; while (b >= 1000 && i < 3) { b /= 1000; i++; } return (i ? b.toFixed(b < 10 ? 2 : 1) : Math.round(b)) + ' ' + u[i]; };
const fmtUp = (s) => { s = Number(s) || 0; const d = Math.floor(s / 86400), hh = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60); return d ? `${d}天${hh}时` : hh ? `${hh}时${m}分` : `${m}分`; };
const ago = (t) => { if (!t) return '从未上线'; const s = Math.max(0, (Date.now() - new Date(t).getTime()) / 1000); return s < 90 ? '刚刚' : s < 3600 ? Math.floor(s / 60) + ' 分钟前' : s < 86400 ? Math.floor(s / 3600) + ' 小时前' : Math.floor(s / 86400) + ' 天前'; };
const TYPE = { entry: '入口', exit: '出口', both: '入口/出口' };

// ---- 深色模式、视角
const root = document.documentElement;
const applyTheme = (t) => { if (t) root.setAttribute('data-theme', t); else root.removeAttribute('data-theme'); };
applyTheme(lsGet('fw_tz_theme'));
document.getElementById('theme').addEventListener('click', () => {
  const dark = root.getAttribute('data-theme') === 'dark' || (!root.getAttribute('data-theme') && matchMedia('(prefers-color-scheme: dark)').matches);
  const next = dark ? 'light' : 'dark'; lsSet('fw_tz_theme', next); applyTheme(next);
});
let view = lsGet('fw_tz_view') === 'table' ? 'table' : 'card';
let asUser = lsGet('fw_tz_as') === 'user';
const roleBtn = document.getElementById('role');
roleBtn.addEventListener('click', () => {
  asUser = !asUser; lsSet('fw_tz_as', asUser ? 'user' : '');
  toast('正在切换视角至 ' + (asUser ? '普通用户' : '管理员') + '…');
  clearTimeout(timer); last = null; tick();
});
document.getElementById('view').addEventListener('click', () => { view = view === 'card' ? 'table' : 'card'; lsSet('fw_tz_view', view); if (last) draw(last); });

// ---- 提示条
const toastEl = document.getElementById('toast'); let toastTimer;
function toast(t) { toastEl.textContent = t; toastEl.hidden = false; clearTimeout(toastTimer); toastTimer = setTimeout(() => { toastEl.hidden = true; }, 2500); }

// ---- 管理员操作（节点管理已合并进本页）
async function api(method, path, body) {
  const res = await fetch('/api/v1' + path, { method, headers: { Authorization: 'Bearer ' + lsGet('fw_token'), 'Content-Type': 'application/json' }, body: body ? JSON.stringify(body) : undefined });
  if (res.status === 401) { location.replace('/'); throw new Error('登录已失效'); }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || ('失败 ' + res.status));
  return data;
}
const refreshSoon = () => { clearTimeout(timer); tick(); };
function editNode(n) {
  const name = h('input', { type: 'text', value: n.name, maxlength: 64 });
  const weight = h('input', { type: 'number', min: 0, max: 1000, value: n.weight === undefined ? 1 : n.weight });
  const q = n.quota || {};
  const GB = 1024 * 1024 * 1024;
  const qGB = h('input', { type: 'number', min: 0, step: 'any', placeholder: '留空或 0 = 不限', value: q.limit ? +(q.limit / GB).toFixed(2) : '' });
  const qMode = h('select', null, h('option', { value: 'both' }, '上下行合计'), h('option', { value: 'out' }, '只算上行'), h('option', { value: 'max' }, '取上下行较大值'));
  qMode.value = q.mode || 'both';
  const qDay = h('input', { type: 'number', min: 0, max: 28, value: q.reset_day || 0 });
  const qWarn = h('input', { type: 'number', min: 0, max: 99, value: q.warn_pct === undefined ? 80 : q.warn_pct });
  const qAct = h('select', null, h('option', { value: 'notify' }, '只发 TG 通知'), h('option', { value: 'stop' }, '通知 + 停止接客'));
  qAct.value = q.action || 'notify';
  let doReset = false;
  const used = h('span', { class: 'muted small' }, q.used === undefined ? '' : '本周期已用 ' + fmtBytes(q.used) + '（↓' + fmtBytes(q.in) + ' ↑' + fmtBytes(q.out) + '）');
  const dlg = h('dialog', { class: 'dlg' },
    h('h3', null, '编辑节点「' + n.name + '」'),
    h('label', null, '名称', name),
    h('label', null, '权重', weight),
    h('p', { class: 'muted small' }, '出口组里有多台节点时，入口按权重比例分配新连接（权重 2 约是权重 1 的两倍）；0 = 暂时不接入口来的连接（已有连接不受影响）。只对作为出口的设备组有效。'),
    h('h4', { style: 'margin:14px 0 4px' }, '流量额度'), used,
    h('label', null, '流量上限（GB）', qGB),
    h('label', null, '统计方式', qMode),
    h('label', null, '每月重置日（0 = 不自动重置）', qDay),
    h('label', null, '用到多少 % 提醒一次（0 = 不提醒）', qWarn),
    h('label', null, '用完后', qAct),
    h('p', { class: 'muted small' }, '按这台服务器网卡的实际进出流量统计（和服务商口径接近，包含面板连接等）。默认不限流量。“停止接客”：入口节点停止转发，出口节点不再接入口来的新连接，下个周期重置或调大额度后自动恢复。提醒走面板里配置的 Telegram。'),
    h('button', { class: 'btn sm', onclick: (e) => { doReset = true; e.target.textContent = '保存时清零本周期用量'; e.target.disabled = true; } }, '清零本周期用量'),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => { dlg.close(); dlg.remove(); } }, '取消'),
      h('button', { class: 'btn primary', onclick: async () => {
        try { await api('PUT', '/nodes/' + n.id, { name: name.value.trim(), weight: Number(weight.value), quota_gb: Number(qGB.value) || 0, quota_mode: qMode.value, quota_reset_day: Number(qDay.value) || 0, quota_warn_pct: Number(qWarn.value) || 0, quota_action: qAct.value, reset_usage: doReset }); toast('已保存'); dlg.close(); dlg.remove(); refreshSoon(); } catch (e) { toast(e.message); }
      } }, '保存')));
  document.body.append(dlg); dlg.showModal();
}
function deleteNode(n) {
  const un = h('input', { type: 'checkbox', id: 'uninst', checked: true });
  const dlg = h('dialog', { class: 'dlg' },
    h('h3', null, '删除节点「' + n.name + '」'),
    h('p', null, '删除后，面板会断开它并停止它上面的所有规则。'),
    h('label', { class: 'chk' }, un, ' 同时卸载服务器上的节点程序'),
    h('p', { class: 'muted small' }, n.online ? '勾选后，节点会自己停止并把程序、配置文件从服务器上移除（需要节点是 0.6.2 及以上）。不勾选则只删面板里的记录，服务器上的程序还在，会一直尝试重连。' : '这个节点现在不在线，没法远程卸载。之后请登录那台服务器运行 bash /opt/fwagent.uninstall.sh。'),
    h('div', { class: 'row' },
      h('button', { class: 'btn', onclick: () => { dlg.close(); dlg.remove(); } }, '取消'),
      h('button', { class: 'btn danger', onclick: async () => {
        try { const r = await api('DELETE', '/nodes/' + n.id + (un.checked && n.online ? '?uninstall=1' : '')); toast(r.note || '已删除'); dlg.close(); dlg.remove(); refreshSoon(); } catch (e) { toast(e.message); }
      } }, '确定删除')));
  document.body.append(dlg); dlg.showModal();
}
async function upgradeNodes(ids) {
  try {
    const r = await api('POST', '/nodes/upgrade', { ids });
    toast('已向 ' + r.sent + ' 个节点发出升级指令，它们会下载新版本并自动重启');
    (r.notes || []).forEach((t) => toast(t));
    setTimeout(refreshSoon, 6000);
  } catch (e) { toast(e.message); }
}
function nodeActions(n) {
  return h('div', { class: 'acts' },
    n.online ? h('button', { class: 'btn sm', onclick: () => window.open('/term.html?node=' + n.id, '_blank') }, '终端') : null,
    h('button', { class: 'btn sm', onclick: () => editNode(n) }, '编辑'),
    n.online && n.outdated ? h('button', { class: 'btn sm primary', onclick: () => upgradeNodes([n.id]) }, '升级') : null,
    h('button', { class: 'btn sm danger', onclick: () => deleteNode(n) }, '删除'));
}
function nodeBadges(n) {
  return h('div', { class: 'badges' },
    n.weight === 0 ? h('span', { class: 'chip warn' }, '权重 0 · 暂停接入') : n.weight > 1 ? h('span', { class: 'chip' }, '权重 ' + n.weight) : null,
    n.quota && n.quota.blocked ? h('span', { class: 'chip bad' }, '流量用尽 · 已停止接客') : null,
    n.outdated ? h('span', { class: 'chip warn' }, '可升级') : null,
    n.apply_status === 'error' ? h('span', { class: 'chip bad', title: n.apply_error || '' }, '规则应用失败') : null,
    n.upgrade_msg ? h('span', { class: 'muted small' }, n.upgrade_msg) : null);
}

// ---- 绘制
let TH = { warn: 70, red: 90 }; // 使用率颜色阈值，由面板设置下发
function meter(label, pct, right) {
  const p = Math.max(0, Math.min(100, pct || 0));
  return h('div', { class: 'meter' }, h('div', { class: 'meter-t' }, h('span', null, label), h('span', null, right || p.toFixed(0) + '%')),
    h('div', { class: 'track' }, h('div', { class: 'fill' + (p >= TH.red ? ' hi' : (TH.warn > 0 && p >= TH.warn) ? ' mid' : ''), style: `width:${p}%` })));
}
// IPv4 一行、IPv6 一行（没有 IPv6 就只有一行），每个地址前面是它自己所在地的国旗
const flagImg = (cc) => cc ? h('img', { class: 'flag', src: '/flags/' + cc.toLowerCase() + '.svg', alt: cc, title: cc, loading: 'lazy', onerror: (e) => { e.target.style.display = 'none'; } }) : h('span', { class: 'flag none' });
// 点一下就复制；每 2 秒会重画页面，重画会让手动选中的文字消失，所以提供点击复制
function copyIP(text) {
  const done = () => toast('已复制：' + text);
  if (navigator.clipboard && window.isSecureContext) { navigator.clipboard.writeText(text).then(done, () => fallbackCopy(text, done)); return; }
  fallbackCopy(text, done);
}
function fallbackCopy(text, done) {
  const ta = h('textarea', { style: 'position:fixed;opacity:0' }); ta.value = text; document.body.append(ta); ta.select();
  try { document.execCommand('copy'); done(); } catch { toast('复制失败，请手动选中复制'); }
  ta.remove();
}
function ipBlock(n) {
  const rows = [];
  if (n.ip) rows.push(h('div', { class: 'ipr' }, flagImg(n.country), h('span', { class: 'tag' }, 'IPv4'), h('span', { class: 'mono ipc', title: '点击复制出口 IPv4', onclick: () => copyIP(n.ip) }, n.ip)));
  if (n.ipv6) rows.push(h('div', { class: 'ipr v6' }, flagImg(n.country6 || (n.ip ? '' : n.country)), h('span', { class: 'tag' }, 'IPv6'), h('span', { class: 'mono ipc', title: '点击复制出口 IPv6\n' + n.ipv6, onclick: () => copyIP(n.ipv6) }, n.ipv6)));
  if (!rows.length) return h('span', { class: 'muted' }, '—');
  return h('div', { class: 'ipb' }, rows);
}
// 表格里的“百分比 + 颜色条”
function pbar(p, label) {
  p = Math.max(0, Math.min(100, p || 0));
  const cls = p >= TH.red ? ' hi' : (TH.warn > 0 && p >= TH.warn) ? ' mid' : '';
  return h('div', { class: 'pc' }, h('span', { class: 'pc-t' + cls }, label || p.toFixed(0) + '%'), h('div', { class: 'track' }, h('div', { class: 'fill' + cls, style: `width:${p}%` })));
}
const ARCH = { amd64: 'x86_64 (amd64)', arm64: 'ARM64 (aarch64)', '386': 'x86 (32 位)', arm: 'ARM (32 位)' };
const titleOf = (n) => (prefs.title === 'ip' && n.ip ? n.ip : n.name);
const nodeTip = (n, admin) => admin ? ('节点 ID：' + n.id + '\n组内编号：' + (n._gi === undefined ? '-' : n._gi) + '\n系统：' + (n.os || '未知') + '\n架构：' + (ARCH[n.arch] || n.arch || '未知') + '\n节点程序版本：' + (n.version ? 'v' + n.version : '未知') + (n.outdated ? '（可升级）' : '')) : '';
function nameBlock(n, admin) {
  const tip = nodeTip(n, admin);
  return h('div', { class: 'nmb', title: tip }, h('div', { class: 'nm1' }, titleOf(n)), admin && n.os ? h('div', { class: 'os' }, n.os) : null);
}
// 表格里“百分比 + 具体大小 + 颜色条”
function pbarSized(p, size) {
  p = Math.max(0, Math.min(100, p || 0));
  const cls = p >= TH.red ? ' hi' : (TH.warn > 0 && p >= TH.warn) ? ' mid' : '';
  return h('div', { class: 'pc wide' }, h('div', { class: 'pc-row' }, h('span', { class: 'pc-t' + cls }, p.toFixed(0) + '%'), h('span', { class: 'pc-s' }, size)), h('div', { class: 'track' }, h('div', { class: 'fill' + cls, style: `width:${p}%` })));
}
const memPct = (n) => (n.mem_total ? n.mem_used / n.mem_total * 100 : 0);
const diskPct = (n) => (n.disk_total ? n.disk_used / n.disk_total * 100 : 0);

function nodeCard(n, admin, g) {
  const body = n.online && n.has_stats ? [
    meter('CPU', n.cpu),
    meter('内存', memPct(n), `${memPct(n).toFixed(0)}% · ${fmtBytes(n.mem_used)} / ${fmtBytes(n.mem_total)}`),
    n.disk_total ? meter('存储', diskPct(n), `${diskPct(n).toFixed(0)}% · ${fmtBytes(n.disk_used)} / ${fmtBytes(n.disk_total)}`) : null,
    h('div', { class: 'kv' },
      h('div', null, h('span', null, '下行 '), fmtSpeed(n.net_in_bps)), h('div', null, h('span', null, '上行 '), fmtSpeed(n.net_out_bps)),
      h('div', null, h('span', null, '连接 '), n.conns), h('div', null, h('span', null, '负载 '), n.load1.toFixed(2)),
      h('div', null, h('span', null, '累计↓ '), fmtBytes(n.net_in)), h('div', null, h('span', null, '累计↑ '), fmtBytes(n.net_out)),
      h('div', { class: 'full' }, h('span', null, '已运行 '), fmtUp(n.uptime), admin && n.version ? h('span', null, '　版本 v' + n.version) : null)),
  ] : [h('div', { class: 'muted small' }, n.online ? '等待首次资源上报…' : '离线 · 最后在线：' + ago(n.last_seen))];
  return h('div', { class: 'card' + (n.online ? '' : ' off'), 'data-dn': edit && g ? 'n:' + g.id + ':' + n.id : null },
    h('div', { class: 'card-h' }, h('span', { class: 'dot' + (n.online ? ' on' : '') }), h('span', { class: 'nm', title: n.name + (admin ? '\n' + nodeTip(n, admin) : '') }, titleOf(n)), admin && (n.ip || n.ipv6) ? ipBlock(n) : null, edit && g ? arrows(edit.n[g.id], n.id) : null),
    body,
    admin && n.quota && n.quota.limit ? meter('流量', n.quota.used / n.quota.limit * 100, fmtBytes(n.quota.used) + ' / ' + fmtBytes(n.quota.limit)) : null,
    admin && n.quota && !n.quota.limit && n.quota.used ? h('div', { class: 'muted small' }, '本周期已用 ' + fmtBytes(n.quota.used) + '（不限）') : null,
    admin ? [nodeBadges(n), nodeActions(n)] : null);
}

function groupTable(g, admin) {
  const head = ['服务器', '状态', 'CPU', '内存', '存储', '下行', '上行', '连接', '负载', '已运行'];
  if (admin) head.splice(1, 0, '出口 IP');
  if (admin) head.push('流量', '权重', '版本', '规则应用', '操作');
  return h('div', { class: 'wrap' }, h('table', null, h('thead', null, h('tr', null, head.map((t) => h('th', null, t)))),
    h('tbody', null, sortedNodes(g).map((n) => {
      const ok = n.online && n.has_stats;
      const cells = [h('td', null, edit ? arrows(edit.n[g.id], n.id) : null, nameBlock(n, admin))];
      if (admin) cells.push(h('td', null, ipBlock(n)));
      cells.push(h('td', null, h('span', { class: 'chip ' + (n.online ? 'ok' : 'bad') }, n.online ? '在线' : '离线')));
      cells.push(h('td', { class: 'pcell' }, ok ? pbar(n.cpu) : '—'), h('td', { class: 'pcell' }, ok ? pbarSized(memPct(n), fmtBytes(n.mem_used) + ' / ' + fmtBytes(n.mem_total)) : '—'), h('td', { class: 'pcell' }, ok && n.disk_total ? pbarSized(diskPct(n), fmtBytes(n.disk_used) + ' / ' + fmtBytes(n.disk_total)) : '—'),
        h('td', null, ok ? fmtSpeed(n.net_in_bps) : '—'), h('td', null, ok ? fmtSpeed(n.net_out_bps) : '—'),
        h('td', null, ok ? n.conns : '—'), h('td', null, ok ? n.load1.toFixed(2) : '—'), h('td', null, ok ? fmtUp(n.uptime) : ago(n.last_seen)));
      if (admin) cells.push(h('td', null, n.quota ? (n.quota.limit ? pbar(n.quota.used / n.quota.limit * 100, fmtBytes(n.quota.used) + ' / ' + fmtBytes(n.quota.limit)) : fmtBytes(n.quota.used)) : '—', n.quota && n.quota.blocked ? h('span', { class: 'chip bad', style: 'margin-left:4px' }, '已停') : null), h('td', null, n.weight), h('td', null, n.version ? 'v' + n.version : '—', n.outdated ? h('span', { class: 'chip warn', style: 'margin-left:4px' }, '可升级') : null),
        h('td', null, n.apply_status === 'ok' ? h('span', { class: 'chip ok' }, '已生效') : n.apply_status === 'error' ? h('span', { class: 'chip bad', title: n.apply_error || '' }, '失败') : '—', h('span', { class: 'muted small' }, ' v' + (n.applied_revision || 0))), h('td', null, nodeActions(n)));
      return h('tr', { 'data-dn': edit ? 'n:' + g.id + ':' + n.id : null }, cells);
    }))));
}

const rootEl = document.getElementById('root');
// ---- 本地偏好（只存在这个浏览器里）：排序方式、手动顺序、刷新间隔、标题显示
let prefs = {};
try { prefs = JSON.parse(lsGet('fw_tz_prefs') || '{}') || {}; } catch { prefs = {}; }
prefs.sort = prefs.sort || {}; prefs.order = prefs.order || {}; prefs.gorder = prefs.gorder || [];
const savePrefs = () => lsSet('fw_tz_prefs', JSON.stringify(prefs));
let edit = null; // 手动排序编辑中的临时顺序：{ g: [组id], n: {组id: [节点id]} }
const SORTS = [['default', '默认顺序'], ['manual', '手动顺序'], ['name', '主机名 ↑'], ['ipv4', 'IPv4 地址 ↑'], ['ipv6', 'IPv6 地址 ↑'], ['uptime', '运行时间 ↓']];
const byOrder = (arr, ids, key) => { const pos = new Map((ids || []).map((x, i) => [x, i])); return arr.slice().sort((a, b) => (pos.has(key(a)) ? pos.get(key(a)) : 1e9) - (pos.has(key(b)) ? pos.get(key(b)) : 1e9)); };
const ipNum = (ip) => (ip || '').split('.').reduce((a, x) => a * 256 + (Number(x) || 0), 0) || 1e15;
function sortedNodes(g) {
  if (edit && edit.n[g.id]) return byOrder(g.nodes, edit.n[g.id], (n) => n.id);
  const mode = prefs.sort[g.id] || 'default';
  const a = g.nodes.slice();
  if (mode === 'manual') return byOrder(a, prefs.order[g.id], (n) => n.id);
  if (mode === 'name') return a.sort((x, y) => x.name.localeCompare(y.name));
  if (mode === 'ipv4') return a.sort((x, y) => ipNum(x.ip) - ipNum(y.ip));
  if (mode === 'ipv6') return a.sort((x, y) => (x.ipv6 || '\uffff').localeCompare(y.ipv6 || '\uffff'));
  if (mode === 'uptime') return a.sort((x, y) => (y.uptime || 0) - (x.uptime || 0));
  return a;
}
function sortedGroups(d) {
  if (edit) return byOrder(d.groups, edit.g, (g) => g.id);
  return byOrder(d.groups, prefs.gorder, (g) => g.id);
}
const mv = (arr, id, dir) => { const i = arr.indexOf(id), j = i + dir; if (i < 0 || j < 0 || j >= arr.length) return; [arr[i], arr[j]] = [arr[j], arr[i]]; draw(last); };
const arrows = (arr, id) => h('span', { class: 'mvb' }, h('span', { class: 'dh', title: '按住拖动排序' }, '⠿'), h('button', { class: 'btn sm', title: '上移', onclick: () => mv(arr, id, -1) }, '▲'), h('button', { class: 'btn sm', title: '下移', onclick: () => mv(arr, id, 1) }, '▼'));
let dragInfo = null;
// 手动排序：按住 ⠿ 拖动（电脑），或点 ▲▼（手机也能用）。拖动时不重画页面，否则拖到一半会被刷新打断。
function wireDrag() {
  rootEl.querySelectorAll('[data-dn]').forEach((el) => {
    const [kind, gs, ids] = el.getAttribute('data-dn').split(':'), gid = Number(gs), id = Number(ids);
    const arr = () => (kind === 'g' ? edit.g : edit.n[gid]);
    const handle = el.querySelector('.dh');
    if (!handle) return;
    handle.addEventListener('mousedown', () => { el.draggable = true; });
    el.addEventListener('dragstart', (e) => { if (!el.draggable) return; e.stopPropagation(); dragInfo = { kind, gid, id }; e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', 'x'); setTimeout(() => el.classList.add('dragging'), 0); });
    el.addEventListener('dragend', () => { dragInfo = null; el.draggable = false; rootEl.querySelectorAll('.dragging,.dropt').forEach((x) => x.classList.remove('dragging', 'dropt')); });
    el.addEventListener('dragover', (e) => { if (dragInfo && dragInfo.kind === kind && dragInfo.gid === gid && dragInfo.id !== id) { e.preventDefault(); e.stopPropagation(); el.classList.add('dropt'); } });
    el.addEventListener('dragleave', () => el.classList.remove('dropt'));
    el.addEventListener('drop', (e) => {
      e.preventDefault(); e.stopPropagation();
      if (!dragInfo) return;
      const moved = dragInfo.id, list = arr(), from = list.indexOf(moved), to = list.indexOf(id);
      dragInfo = null;
      if (from < 0 || to < 0) return;
      list.splice(from, 1); list.splice(to, 0, moved);
      draw(last);
    });
  });
}
function startEdit(d) {
  edit = { g: sortedGroups(d).map((g) => g.id), n: {} };
  d.groups.forEach((g) => { edit.n[g.id] = sortedNodes(g).map((n) => n.id); });
  draw(d);
}
function finishEdit(save) {
  if (save && edit) {
    prefs.gorder = edit.g;
    Object.keys(edit.n).forEach((gid) => { prefs.order[gid] = edit.n[gid]; prefs.sort[gid] = 'manual'; });
    savePrefs(); toast('排序已保存（只保存在这个浏览器里）');
  }
  edit = null; draw(last);
}
let pick = lsGet('fw_tz_pick') || 'all';
let last = null;
function draw(d) {
  last = d;
  const sum = h('div', { class: 'sum' },
    h('div', null, h('span', { class: 'muted small' }, '在线服务器'), h('b', null, `${d.online} / ${d.total}`)),
    h('div', null, h('span', { class: 'muted small' }, '总下行'), h('b', null, fmtSpeed(d.net_in_bps))),
    h('div', null, h('span', { class: 'muted small' }, '总上行'), h('b', null, fmtSpeed(d.net_out_bps))),
    h('div', null, h('span', { class: 'muted small' }, '设备组'), h('b', null, d.groups.length)));
  const outdated = d.groups.flatMap((g) => g.nodes).filter((n) => n.online && n.outdated);
  const bar = d.admin ? h('div', { class: 'adm-bar' },
    outdated.length ? h('button', { class: 'btn primary', onclick: () => { if (confirm('把 ' + outdated.length + ' 个在线且版本落后的节点升级到最新节点程序？节点会短暂重启（几秒），已有连接会断开一次。')) upgradeNodes([]); } }, '一键升级落后节点（' + outdated.length + '）') : h('span', { class: 'muted small' }, '所有在线服务器的程序都是最新版'),
    h('span', { class: 'muted small' }, '配置版本 v' + (d.revision || 0))) : null;
  d.groups.forEach((g) => g.nodes.forEach((n, i) => { n._gi = i; }));
  if (pick !== 'all' && !d.groups.some((g) => String(g.id) === pick)) pick = 'all';
  const ordered = sortedGroups(d);
  const tabs = h('div', { class: 'tabs' }, h('span', { class: 'muted small' }, '分组'),
    [['all', '所有']].concat(ordered.map((g) => [String(g.id), g.name])).map(([k, t]) => h('button', { class: 'tab' + (pick === k ? ' on' : ''), onclick: () => { pick = k; lsSet('fw_tz_pick', k); draw(last); } }, t)));
  const shown = pick === 'all' ? ordered : ordered.filter((g) => String(g.id) === pick);
  const groups = shown.length ? shown.map((g) => h('section', { class: 'grp', 'data-dn': edit ? 'g:0:' + g.id : null },
    h('div', { class: 'grp-h' }, h('h2', { class: 'link', title: pick === 'all' ? '只看这一组' : '回到全部', onclick: () => { pick = pick === 'all' ? String(g.id) : 'all'; lsSet('fw_tz_pick', pick); draw(last); } }, g.name), h('span', { class: 'chip', title: '设备组 ID，建规则、导入导出时用得到' }, 'ID: ' + g.id), edit ? arrows(edit.g, g.id) : null, h('span', { class: 'chip' }, TYPE[g.type] || g.type),
      h('span', { class: 'chip ' + (!g.total ? '' : g.online === g.total ? 'ok' : g.online ? '' : 'bad') }, `在线 ${g.online}/${g.total}`),
      d.admin || g.multiplier !== 1 ? h('span', { class: 'muted small' }, '倍率 ×' + g.multiplier) : null,
      h('span', { class: 'muted small' }, `↓ ${fmtSpeed(g.net_in_bps)}　↑ ${fmtSpeed(g.net_out_bps)}　连接 ${g.conns}`),
      g.remark ? h('span', { class: 'muted small' }, g.remark) : null,
      edit ? null : h('select', { class: 'sortsel', title: '这一组的排序方式', onchange: (e) => { prefs.sort[g.id] = e.target.value; savePrefs(); draw(last); } }, SORTS.map(([k, t]) => h('option', { value: k, selected: (prefs.sort[g.id] || 'default') === k }, '排序：' + t)))),
    g.nodes.length ? (view === 'table' ? groupTable(g, d.admin) : h('div', { class: 'cards' }, sortedNodes(g).map((n) => nodeCard(n, d.admin, g)))) : h('p', { class: 'muted small' }, '这个设备组还没有服务器'))) : [h('p', { class: 'muted center' }, '没有可显示的设备组')];
  // 每 2 秒重画一次会让横向滚动条跳回最左边：重画前记下位置，画完再恢复
  const sl = [...rootEl.querySelectorAll('.wrap')].map((w) => w.scrollLeft), sy = window.scrollY;
  const editBar = edit ? h('div', { class: 'adm-bar' }, h('span', null, '手动排序中：用 ▲▼ 调整设备组和服务器的顺序'), h('button', { class: 'btn', onclick: () => finishEdit(false) }, '放弃修改'), h('button', { class: 'btn primary', onclick: () => finishEdit(true) }, '完成')) : null;
  rootEl.replaceChildren(sum, ...(bar ? [bar] : []), ...(editBar ? [editBar] : []), tabs, ...groups);
  if (edit) wireDrag();
  rootEl.querySelectorAll('.wrap').forEach((w, i) => { if (sl[i]) w.scrollLeft = sl[i]; });
  if (sy) window.scrollTo(0, sy);
}
function drawErr(msg) {
  rootEl.replaceChildren(h('div', { class: 'err' }, h('h3', null, '错误'), h('div', { class: 'muted' }, msg)));
}

// ---- 拉取
let connected = false, fails = 0, timer = null;
async function tick() {
  const token = lsGet('fw_token');
  if (!token) { location.replace('/'); return; }
  try {
    const res = await fetch('/api/v1/nodes/status' + (asUser ? '?as=user' : ''), { headers: { Authorization: 'Bearer ' + token }, cache: 'no-store' });
    if (res.status === 401) { location.replace('/'); return; }
    if (!res.ok) throw new Error('面板返回 ' + res.status);
    const d = await res.json();
    if (!d || !Array.isArray(d.groups)) throw new Error('服务端返回了无法识别的节点状态');
    fails = 0;
    if (d.thresholds && d.thresholds.red) TH = d.thresholds;
    roleBtn.hidden = !d.can_switch; // 只有管理员才有“切换视角”；普通用户既看不到按钮，也不会带上 as=user
    if (d.can_switch) roleBtn.querySelector('span:last-child').textContent = asUser ? '切换视角（当前：普通用户）' : '切换视角（当前：管理员）';
    else if (asUser) { asUser = false; lsSet('fw_tz_as', ''); }
    if (!connected) { connected = true; toast('实时连接已建立'); }
    last = d;
    const sel = window.getSelection && String(window.getSelection());
    if (edit) { /* 排序编辑中不重画 */ } else if (!sel || !rootEl.contains(window.getSelection().anchorNode)) draw(d); // 正在选中文字时不重画，免得选中的内容被刷掉
  } catch (e) {
    console.error(e);
    fails++;
    if (connected) { connected = false; toast('连接中断，正在重试…'); }
    if (!last || !rootEl.querySelector('.grp')) drawErr(e.message);
  }
  timer = setTimeout(tick, document.hidden ? 10000 : Math.min((prefs.interval || 2000) * (1 + fails), 30000));
}
// ---- 设置菜单
const setBtn = document.getElementById('settings');
let setPop = null;
setBtn.addEventListener('click', (ev) => {
  ev.stopPropagation();
  if (setPop) { setPop.remove(); setPop = null; return; }
  const iv = h('select', { onchange: (e) => { prefs.interval = Number(e.target.value); savePrefs(); clearTimeout(timer); tick(); } },
    [[2000, '2 秒'], [5000, '5 秒'], [10000, '10 秒'], [30000, '30 秒']].map(([v, t]) => h('option', { value: v, selected: (prefs.interval || 2000) === v }, t)));
  const ti = h('select', { onchange: (e) => { prefs.title = e.target.value; savePrefs(); if (last) draw(last); } },
    [['name', '名称'], ['ip', '出口 IP']].map(([v, t]) => h('option', { value: v, selected: (prefs.title || 'name') === v }, t)));
  setPop = h('div', { class: 'setpop', onclick: (e) => e.stopPropagation() },
    h('button', { class: 'btn', onclick: () => { setPop.remove(); setPop = null; if (last) startEdit(last); } }, '手动排序（调整设备组 / 服务器顺序）'),
    h('label', null, '刷新间隔', iv), h('label', null, '服务器标题优先显示', ti),
    h('button', { class: 'btn danger', onclick: () => { if (confirm('清空这个浏览器里保存的排序、刷新间隔等偏好？')) { prefs = { sort: {}, order: {}, gorder: [] }; savePrefs(); pick = 'all'; lsSet('fw_tz_pick', 'all'); setPop.remove(); setPop = null; if (last) draw(last); toast('已清空'); } } }, '清空本地偏好'));
  document.body.append(setPop);
});
document.addEventListener('click', () => { if (setPop) { setPop.remove(); setPop = null; } });
document.addEventListener('visibilitychange', () => { if (!document.hidden) { clearTimeout(timer); tick(); } });
tick();
})();
