#!/usr/bin/env bash
# 把编译好的面板安装成系统服务（开机自启）。用法：
#   bash install-panel.sh                 只用 IP 测试（监听 0.0.0.0:18888，无 HTTPS）
#   bash install-panel.sh panel.example.com   用域名，自动装 Caddy 并申请 HTTPS 证书
set -euo pipefail
[ "$(id -u)" = 0 ] || { echo "请用 root 运行"; exit 1; }
cd "$(dirname "$0")"
[ -x backend/ocean ] || { echo "没有找到编译好的程序 backend/ocean（预编译包里应当自带）；如果是源码包，请先运行 bash build.sh"; exit 1; }
DOMAIN="${1:-}"
DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%%/*}"
if [ -n "$DOMAIN" ]; then
  if ! echo "$DOMAIN" | grep -Eq '^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$' || echo "$DOMAIN" | grep -Eq '^[0-9.]+$'; then
    echo "域名格式不对：$DOMAIN（必须是域名，不能是 IP，也不要带端口）"; exit 1
  fi
  MYIP=$(curl -fsS4 --max-time 5 https://api.ipify.org 2>/dev/null || true)
  DNSIP=$(getent ahostsv4 "$DOMAIN" 2>/dev/null | awk 'NR==1{print $1}')
  if [ -z "$DNSIP" ]; then
    echo "提示：域名 $DOMAIN 暂时解析不到，请先到域名服务商添加 A 记录指向本服务器 IP${MYIP:+（$MYIP）}，否则证书申请会失败。"
  elif [ -n "$MYIP" ] && [ "$DNSIP" != "$MYIP" ]; then
    echo "提示：域名解析到 $DNSIP，本机公网 IP 是 $MYIP。若没有使用 CDN（如 Cloudflare 橙云），请确认解析正确。"
  fi
fi
DIR=/opt/ocean
# 从旧名字（fwpanel）迁移：停服务、把目录改名，数据库和配置原样保留
if [ -d /opt/fwpanel ] && [ ! -d $DIR ]; then
  systemctl disable --now fwpanel 2>/dev/null || true
  mv /opt/fwpanel $DIR
  mv -f $DIR/fwpanel $DIR/ocean.old 2>/dev/null || true
  rm -f /etc/systemd/system/fwpanel.service
fi
systemctl stop ocean 2>/dev/null || true
mkdir -p $DIR/agent-bin
install -m 755 backend/ocean $DIR/ocean
rm -f $DIR/ocean.old
cp -f backend/agent-bin/* $DIR/agent-bin/
cd $DIR
if [ -n "$DOMAIN" ]; then
  PUB="https://$DOMAIN"; LISTEN="127.0.0.1:18888"
else
  IP=$(curl -fsS4 --max-time 5 https://api.ipify.org 2>/dev/null || hostname -I | awk '{print $1}')
  PUB="http://$IP:18888"; LISTEN="0.0.0.0:18888"
fi
if [ -f config.yml ] && [ -n "$DOMAIN" ]; then # 已有配置：换成域名模式（只改监听地址和对外地址）
  sed -i -e "s|^listen:.*|listen: \"$LISTEN\"|" -e "s|^public-url:.*|public-url: \"$PUB\"|" config.yml
fi
if [ ! -f config.yml ]; then # 已有配置不覆盖
cat > config.yml <<CFG
database-path: "data.db"
listen: "$LISTEN"
public-url: "$PUB"
agent-bin-dir: "agent-bin"
CFG
fi
if [ ! -f data.db ]; then
  MIGRATE=1 ADMIN=admin ./ocean | tee init.log
  chmod 600 init.log
else
  echo "检测到已有数据库，执行升级（保留所有数据）..."
  MIGRATE=1 ./ocean
fi
cat > /etc/systemd/system/ocean.service <<UNIT
[Unit]
Description=ocean
After=network-online.target
[Service]
WorkingDirectory=$DIR
ExecStart=$DIR/ocean
Restart=always
RestartSec=3
[Install]
WantedBy=multi-user.target
UNIT
systemctl daemon-reload
systemctl enable --now ocean
if [ -n "$DOMAIN" ]; then
  if ! command -v caddy >/dev/null; then
    if command -v apt-get >/dev/null; then
      apt-get update -y && apt-get install -y debian-keyring debian-archive-keyring apt-transport-https curl gpg
      curl -1sLf https://dl.cloudsmith.io/public/caddy/stable/gpg.key | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
      curl -1sLf https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt > /etc/apt/sources.list.d/caddy-stable.list
      apt-get update -y && apt-get install -y caddy
    elif command -v dnf >/dev/null; then
      dnf install -y 'dnf-command(copr)' && dnf copr enable -y @caddy/caddy && dnf install -y caddy
    else
      echo "没法自动安装 Caddy（不是 apt / dnf 系统），请手动安装 Caddy 后再运行本脚本"; exit 1
    fi
  fi
  mkdir -p /etc/caddy
  if [ -s /etc/caddy/Caddyfile ] && ! grep -q "ocean-managed" /etc/caddy/Caddyfile; then
    cp -f /etc/caddy/Caddyfile /etc/caddy/Caddyfile.bak.$(date +%s)
    echo "已备份原有 Caddyfile"
  fi
  printf '# ocean-managed\n%s {\n\treverse_proxy 127.0.0.1:18888\n}\n' "$DOMAIN" > /etc/caddy/Caddyfile
  if command -v ufw >/dev/null && ufw status 2>/dev/null | grep -q "Status: active"; then ufw allow 80/tcp >/dev/null; ufw allow 443/tcp >/dev/null; fi
  systemctl enable caddy >/dev/null 2>&1 || true
  systemctl restart caddy
  echo "正在等待 HTTPS 证书（最多约 40 秒）..."
  OK=0
  for i in $(seq 1 10); do
    sleep 4
    if curl -fsS -o /dev/null --max-time 8 "https://$DOMAIN/api/v1/site" 2>/dev/null || curl -sS -o /dev/null --max-time 8 "https://$DOMAIN/" 2>/dev/null; then OK=1; break; fi
  done
  if [ "$OK" = 1 ]; then echo "HTTPS 已生效。"; else
    echo "提示：暂时还打不开 https://$DOMAIN 。请检查：1) 域名 A 记录指向本机；2) 服务商安全组 / 防火墙放行 80 和 443；3) 用了 Cloudflare 的话先关闭橙云或把 SSL 设为“完全”。修好后运行 systemctl restart caddy，再看 journalctl -u caddy -n 30。"
  fi
fi
echo
CURPUB=$(grep -E '^public-url:' config.yml | sed -E 's/^public-url: *"?([^"]*)"?.*/\1/'); CURLISTEN=$(grep -E '^listen:' config.yml | sed -E 's/^listen: *"?([^"]*)"?.*/\1/')
echo "面板已安装并启动：${CURPUB:-$PUB}（监听 ${CURLISTEN:-$LISTEN}）"
echo "管理员账号密码在 $DIR/init.log（首次安装时已显示）"
if [ -z "$DOMAIN" ] && echo "$CURPUB" | grep -Eq "^https?://[0-9.]+(:[0-9]+)?$"; then
  echo "注意：现在是 IP 测试模式。节点对接必须使用域名，正式使用请运行： bash install-panel.sh 你的域名"
fi
